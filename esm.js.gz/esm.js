"use strict";

const __non_webpack_module__ = module;

module.exports =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, {
/******/ 				configurable: false,
/******/ 				enumerable: true,
/******/ 				get: getter
/******/ 			});
/******/ 		}
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = 81);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ (function(module, exports) {

module.exports = require("path");

/***/ }),
/* 1 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
let fastProto = null;

// Creates an object with permanently fast properties in V8.
// See Toon Verwaest's post for more details
// https://medium.com/@tverwaes/setting-up-prototypes-in-v8-ec9c9491dfe2#5f62.
// Use %HasFastProperties(object) and the Node flag
// --allow-natives-syntax to check whether an object has fast properties.
function FastObject() {
  // A prototype object will have "fast properties" enabled once it is checked
  // against the inline property cache of a function, e.g. fastProto.property:
  // https://github.com/v8/v8/blob/6.0.122/test/mjsunit/fast-prototype.js#L48-L63
  if (fastProto !== null && typeof fastProto.property) {
    const result = fastProto;
    fastProto = FastObject.prototype = null;
    return result;
  }
  fastProto = FastObject.prototype = Object.create(null);
  return new FastObject();
}

// Initialize the inline property cache of FastObject.
FastObject();

/* harmony default export */ __webpack_exports__["a"] = (FastObject);

/***/ }),
/* 2 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__defaults_js__ = __webpack_require__(44);


function createOptions(options, defaultOptions) {
  return Object(__WEBPACK_IMPORTED_MODULE_0__defaults_js__["a" /* default */])(Object.create(null), options, defaultOptions);
}

/* harmony default export */ __webpack_exports__["a"] = (createOptions);

/***/ }),
/* 3 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// ## Token types

// The assignment of fine-grained, information-carrying type objects
// allows the tokenizer to store the information it has about a
// token in a way that is very cheap for the parser to look up.

// All token type variables start with an underscore, to make them
// easy to recognize.

// The `beforeExpr` property is used to disambiguate between regular
// expressions and divisions. It is set on all token types that can
// be followed by an expression (thus, a slash after them would be a
// regular expression).
//
// The `startsExpr` property is used to check if the token ends a
// `yield` expression. It is set on all token types that either can
// directly start an expression (like a quotation mark) or can
// continue an expression (like the body of a string).
//
// `isLoop` marks a keyword as starting a loop, which is important
// to know when parsing a label, in order to allow or disallow
// continue jumps to that label.

class TokenType {
  constructor(label) {
    let conf = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

    this.label = label;
    this.keyword = conf.keyword;
    this.beforeExpr = !!conf.beforeExpr;
    this.startsExpr = !!conf.startsExpr;
    this.isLoop = !!conf.isLoop;
    this.isAssign = !!conf.isAssign;
    this.prefix = !!conf.prefix;
    this.postfix = !!conf.postfix;
    this.binop = conf.binop || null;
    this.updateContext = null;
  }
}
/* unused harmony export TokenType */


function binop(name, prec) {
  return new TokenType(name, { beforeExpr: true, binop: prec });
}
const beforeExpr = { beforeExpr: true },
      startsExpr = { startsExpr: true

  // Map keyword names to token types.

};const keywords = {};
/* harmony export (immutable) */ __webpack_exports__["a"] = keywords;


// Succinct definitions of keyword token types
function kw(name) {
  let options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};

  options.keyword = name;
  return keywords[name] = new TokenType(name, options);
}

const types = {
  num: new TokenType("num", startsExpr),
  regexp: new TokenType("regexp", startsExpr),
  string: new TokenType("string", startsExpr),
  name: new TokenType("name", startsExpr),
  eof: new TokenType("eof"),

  // Punctuation token types.
  bracketL: new TokenType("[", { beforeExpr: true, startsExpr: true }),
  bracketR: new TokenType("]"),
  braceL: new TokenType("{", { beforeExpr: true, startsExpr: true }),
  braceR: new TokenType("}"),
  parenL: new TokenType("(", { beforeExpr: true, startsExpr: true }),
  parenR: new TokenType(")"),
  comma: new TokenType(",", beforeExpr),
  semi: new TokenType(";", beforeExpr),
  colon: new TokenType(":", beforeExpr),
  dot: new TokenType("."),
  question: new TokenType("?", beforeExpr),
  arrow: new TokenType("=>", beforeExpr),
  template: new TokenType("template"),
  invalidTemplate: new TokenType("invalidTemplate"),
  ellipsis: new TokenType("...", beforeExpr),
  backQuote: new TokenType("`", startsExpr),
  dollarBraceL: new TokenType("${", { beforeExpr: true, startsExpr: true }),

  // Operators. These carry several kinds of properties to help the
  // parser use them properly (the presence of these properties is
  // what categorizes them as operators).
  //
  // `binop`, when present, specifies that this operator is a binary
  // operator, and will refer to its precedence.
  //
  // `prefix` and `postfix` mark the operator as a prefix or postfix
  // unary operator.
  //
  // `isAssign` marks all of `=`, `+=`, `-=` etcetera, which act as
  // binary operators with a very low precedence, that should result
  // in AssignmentExpression nodes.

  eq: new TokenType("=", { beforeExpr: true, isAssign: true }),
  assign: new TokenType("_=", { beforeExpr: true, isAssign: true }),
  incDec: new TokenType("++/--", { prefix: true, postfix: true, startsExpr: true }),
  prefix: new TokenType("!/~", { beforeExpr: true, prefix: true, startsExpr: true }),
  logicalOR: binop("||", 1),
  logicalAND: binop("&&", 2),
  bitwiseOR: binop("|", 3),
  bitwiseXOR: binop("^", 4),
  bitwiseAND: binop("&", 5),
  equality: binop("==/!=/===/!==", 6),
  relational: binop("</>/<=/>=", 7),
  bitShift: binop("<</>>/>>>", 8),
  plusMin: new TokenType("+/-", { beforeExpr: true, binop: 9, prefix: true, startsExpr: true }),
  modulo: binop("%", 10),
  star: binop("*", 10),
  slash: binop("/", 10),
  starstar: new TokenType("**", { beforeExpr: true }),

  // Keyword token types.
  _break: kw("break"),
  _case: kw("case", beforeExpr),
  _catch: kw("catch"),
  _continue: kw("continue"),
  _debugger: kw("debugger"),
  _default: kw("default", beforeExpr),
  _do: kw("do", { isLoop: true, beforeExpr: true }),
  _else: kw("else", beforeExpr),
  _finally: kw("finally"),
  _for: kw("for", { isLoop: true }),
  _function: kw("function", startsExpr),
  _if: kw("if"),
  _return: kw("return", beforeExpr),
  _switch: kw("switch"),
  _throw: kw("throw", beforeExpr),
  _try: kw("try"),
  _var: kw("var"),
  _const: kw("const"),
  _while: kw("while", { isLoop: true }),
  _with: kw("with"),
  _new: kw("new", { beforeExpr: true, startsExpr: true }),
  _this: kw("this", startsExpr),
  _super: kw("super", startsExpr),
  _class: kw("class", startsExpr),
  _extends: kw("extends", beforeExpr),
  _export: kw("export"),
  _import: kw("import"),
  _null: kw("null", startsExpr),
  _true: kw("true", startsExpr),
  _false: kw("false", startsExpr),
  _in: kw("in", { beforeExpr: true, binop: 7 }),
  _instanceof: kw("instanceof", { beforeExpr: true, binop: 7 }),
  _typeof: kw("typeof", { beforeExpr: true, prefix: true, startsExpr: true }),
  _void: kw("void", { beforeExpr: true, prefix: true, startsExpr: true }),
  _delete: kw("delete", { beforeExpr: true, prefix: true, startsExpr: true })
};
/* harmony export (immutable) */ __webpack_exports__["b"] = types;


/***/ }),
/* 4 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
function isObjectLike(value) {
  const type = typeof value;
  return type === "function" || type === "object" && value !== null;
}

/* harmony default export */ __webpack_exports__["a"] = (isObjectLike);

/***/ }),
/* 5 */
/***/ (function(module, exports) {

module.exports = require("fs");

/***/ }),
/* 6 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__identifier__ = __webpack_require__(41);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__tokentype__ = __webpack_require__(3);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__whitespace__ = __webpack_require__(13);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__options__ = __webpack_require__(112);





// Registered plugins
const plugins = {};
/* unused harmony export plugins */


function keywordRegexp(words) {
  return new RegExp("^(?:" + words.replace(/ /g, "|") + ")$");
}

class Parser {
  constructor(options, input, startPos) {
    this.options = options = Object(__WEBPACK_IMPORTED_MODULE_3__options__["a" /* getOptions */])(options);
    this.sourceFile = options.sourceFile;
    this.keywords = keywordRegexp(__WEBPACK_IMPORTED_MODULE_0__identifier__["c" /* keywords */][options.ecmaVersion >= 6 ? 6 : 5]);
    let reserved = "";
    if (!options.allowReserved) {
      for (let v = options.ecmaVersion;; v--) if (reserved = __WEBPACK_IMPORTED_MODULE_0__identifier__["d" /* reservedWords */][v]) break;
      if (options.sourceType == "module") reserved += " await";
    }
    this.reservedWords = keywordRegexp(reserved);
    let reservedStrict = (reserved ? reserved + " " : "") + __WEBPACK_IMPORTED_MODULE_0__identifier__["d" /* reservedWords */].strict;
    this.reservedWordsStrict = keywordRegexp(reservedStrict);
    this.reservedWordsStrictBind = keywordRegexp(reservedStrict + " " + __WEBPACK_IMPORTED_MODULE_0__identifier__["d" /* reservedWords */].strictBind);
    this.input = String(input);

    // Used to signal to callers of `readWord1` whether the word
    // contained any escape sequences. This is needed because words with
    // escape sequences must not be interpreted as keywords.
    this.containsEsc = false;

    // Load plugins
    this.loadPlugins(options.plugins);

    // Set up token state

    // The current position of the tokenizer in the input.
    if (startPos) {
      this.pos = startPos;
      this.lineStart = this.input.lastIndexOf("\n", startPos - 1) + 1;
      this.curLine = this.input.slice(0, this.lineStart).split(__WEBPACK_IMPORTED_MODULE_2__whitespace__["b" /* lineBreak */]).length;
    } else {
      this.pos = this.lineStart = 0;
      this.curLine = 1;
    }

    // Properties of the current token:
    // Its type
    this.type = __WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].eof;
    // For tokens that include more information than their type, the value
    this.value = null;
    // Its start and end offset
    this.start = this.end = this.pos;
    // And, if locations are used, the {line, column} object
    // corresponding to those offsets
    this.startLoc = this.endLoc = this.curPosition();

    // Position information for the previous token
    this.lastTokEndLoc = this.lastTokStartLoc = null;
    this.lastTokStart = this.lastTokEnd = this.pos;

    // The context stack is used to superficially track syntactic
    // context to predict whether a regular expression is allowed in a
    // given position.
    this.context = this.initialContext();
    this.exprAllowed = true;

    // Figure out if it's a module code.
    this.inModule = options.sourceType === "module";
    this.strict = this.inModule || this.strictDirective(this.pos);

    // Used to signify the start of a potential arrow function
    this.potentialArrowAt = -1;

    // Flags to track whether we are in a function, a generator, an async function.
    this.inFunction = this.inGenerator = this.inAsync = false;
    // Positions to delayed-check that yield/await does not exist in default parameters.
    this.yieldPos = this.awaitPos = 0;
    // Labels in scope.
    this.labels = [];

    // If enabled, skip leading hashbang line.
    if (this.pos === 0 && options.allowHashBang && this.input.slice(0, 2) === "#!") this.skipLineComment(2);

    // Scope tracking for duplicate variable names (see scope.js)
    this.scopeStack = [];
    this.enterFunctionScope();
  }

  // DEPRECATED Kept for backwards compatibility until 3.0 in case a plugin uses them
  isKeyword(word) {
    return this.keywords.test(word);
  }
  isReservedWord(word) {
    return this.reservedWords.test(word);
  }

  extend(name, f) {
    this[name] = f(this[name]);
  }

  loadPlugins(pluginConfigs) {
    for (let name in pluginConfigs) {
      let plugin = plugins[name];
      if (!plugin) throw new Error("Plugin '" + name + "' not found");
      plugin(this, pluginConfigs[name]);
    }
  }

  parse() {
    let node = this.options.program || this.startNode();
    this.nextToken();
    return this.parseTopLevel(node);
  }
}
/* harmony export (immutable) */ __webpack_exports__["a"] = Parser;


/***/ }),
/* 7 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
const hasOwn = Object.prototype.hasOwnProperty;

function has(object, key) {
  return object != null && hasOwn.call(object, key);
}

/* harmony default export */ __webpack_exports__["a"] = (has);

/***/ }),
/* 8 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__fast_object_js__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__util_is_object_like_js__ = __webpack_require__(4);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__util_set_getter_js__ = __webpack_require__(9);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__util_set_property_js__ = __webpack_require__(10);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__util_set_setter_js__ = __webpack_require__(16);







const _binding = process.binding;
const ids = ["config", "fs", "inspector", "natives", "util"];

const binding = ids.reduce(function (binding, id) {
  Object(__WEBPACK_IMPORTED_MODULE_2__util_set_getter_js__["a" /* default */])(binding, id, function () {
    let value;

    try {
      value = _binding.call(process, id);
    } catch (e) {}

    return binding[id] = Object(__WEBPACK_IMPORTED_MODULE_1__util_is_object_like_js__["a" /* default */])(value) ? value : Object.create(null);
  });

  Object(__WEBPACK_IMPORTED_MODULE_4__util_set_setter_js__["a" /* default */])(binding, id, function (value) {
    Object(__WEBPACK_IMPORTED_MODULE_3__util_set_property_js__["a" /* default */])(binding, id, { value });
  });

  return binding;
}, new __WEBPACK_IMPORTED_MODULE_0__fast_object_js__["a" /* default */]());

/* harmony default export */ __webpack_exports__["a"] = (binding);

/***/ }),
/* 9 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
const defineGetter = Object.prototype.__defineGetter__;

function setGetter(object, key, getter) {
  defineGetter.call(object, key, getter);
  return object;
}

/* harmony default export */ __webpack_exports__["a"] = (setGetter);

/***/ }),
/* 10 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__create_options_js__ = __webpack_require__(2);


const defaultDescriptor = Object(__WEBPACK_IMPORTED_MODULE_0__create_options_js__["a" /* default */])({
  configurable: true,
  enumerable: true,
  value: void 0,
  writable: true
});

function setProperty(object, key, descriptor) {
  descriptor = Object(__WEBPACK_IMPORTED_MODULE_0__create_options_js__["a" /* default */])(descriptor, defaultDescriptor);
  return Object.defineProperty(object, key, descriptor);
}

/* harmony default export */ __webpack_exports__["a"] = (setProperty);

/***/ }),
/* 11 */
/***/ (function(module, exports) {

exports = module.exports = SemVer;

// The debug function is excluded entirely from the minified version.
/* nomin */ var debug;
/* nomin */ if (typeof process === 'object' &&
    /* nomin */ process.env &&
    /* nomin */ process.env.NODE_DEBUG &&
    /* nomin */ /\bsemver\b/i.test(process.env.NODE_DEBUG))
  /* nomin */ debug = function() {
    /* nomin */ var args = Array.prototype.slice.call(arguments, 0);
    /* nomin */ args.unshift('SEMVER');
    /* nomin */ console.log.apply(console, args);
    /* nomin */ };
/* nomin */ else
  /* nomin */ debug = function() {};

// Note: this is the semver.org version of the spec that it implements
// Not necessarily the package version of this code.
exports.SEMVER_SPEC_VERSION = '2.0.0';

var MAX_LENGTH = 256;
var MAX_SAFE_INTEGER = Number.MAX_SAFE_INTEGER || 9007199254740991;

// The actual regexps go on exports.re
var re = exports.re = [];
var src = exports.src = [];
var R = 0;

// The following Regular Expressions can be used for tokenizing,
// validating, and parsing SemVer version strings.

// ## Numeric Identifier
// A single `0`, or a non-zero digit followed by zero or more digits.

var NUMERICIDENTIFIER = R++;
src[NUMERICIDENTIFIER] = '0|[1-9]\\d*';
var NUMERICIDENTIFIERLOOSE = R++;
src[NUMERICIDENTIFIERLOOSE] = '[0-9]+';


// ## Non-numeric Identifier
// Zero or more digits, followed by a letter or hyphen, and then zero or
// more letters, digits, or hyphens.

var NONNUMERICIDENTIFIER = R++;
src[NONNUMERICIDENTIFIER] = '\\d*[a-zA-Z-][a-zA-Z0-9-]*';


// ## Main Version
// Three dot-separated numeric identifiers.

var MAINVERSION = R++;
src[MAINVERSION] = '(' + src[NUMERICIDENTIFIER] + ')\\.' +
                   '(' + src[NUMERICIDENTIFIER] + ')\\.' +
                   '(' + src[NUMERICIDENTIFIER] + ')';

var MAINVERSIONLOOSE = R++;
src[MAINVERSIONLOOSE] = '(' + src[NUMERICIDENTIFIERLOOSE] + ')\\.' +
                        '(' + src[NUMERICIDENTIFIERLOOSE] + ')\\.' +
                        '(' + src[NUMERICIDENTIFIERLOOSE] + ')';

// ## Pre-release Version Identifier
// A numeric identifier, or a non-numeric identifier.

var PRERELEASEIDENTIFIER = R++;
src[PRERELEASEIDENTIFIER] = '(?:' + src[NUMERICIDENTIFIER] +
                            '|' + src[NONNUMERICIDENTIFIER] + ')';

var PRERELEASEIDENTIFIERLOOSE = R++;
src[PRERELEASEIDENTIFIERLOOSE] = '(?:' + src[NUMERICIDENTIFIERLOOSE] +
                                 '|' + src[NONNUMERICIDENTIFIER] + ')';


// ## Pre-release Version
// Hyphen, followed by one or more dot-separated pre-release version
// identifiers.

var PRERELEASE = R++;
src[PRERELEASE] = '(?:-(' + src[PRERELEASEIDENTIFIER] +
                  '(?:\\.' + src[PRERELEASEIDENTIFIER] + ')*))';

var PRERELEASELOOSE = R++;
src[PRERELEASELOOSE] = '(?:-?(' + src[PRERELEASEIDENTIFIERLOOSE] +
                       '(?:\\.' + src[PRERELEASEIDENTIFIERLOOSE] + ')*))';

// ## Build Metadata Identifier
// Any combination of digits, letters, or hyphens.

var BUILDIDENTIFIER = R++;
src[BUILDIDENTIFIER] = '[0-9A-Za-z-]+';

// ## Build Metadata
// Plus sign, followed by one or more period-separated build metadata
// identifiers.

var BUILD = R++;
src[BUILD] = '(?:\\+(' + src[BUILDIDENTIFIER] +
             '(?:\\.' + src[BUILDIDENTIFIER] + ')*))';


// ## Full Version String
// A main version, followed optionally by a pre-release version and
// build metadata.

// Note that the only major, minor, patch, and pre-release sections of
// the version string are capturing groups.  The build metadata is not a
// capturing group, because it should not ever be used in version
// comparison.

var FULL = R++;
var FULLPLAIN = 'v?' + src[MAINVERSION] +
                src[PRERELEASE] + '?' +
                src[BUILD] + '?';

src[FULL] = '^' + FULLPLAIN + '$';

// like full, but allows v1.2.3 and =1.2.3, which people do sometimes.
// also, 1.0.0alpha1 (prerelease without the hyphen) which is pretty
// common in the npm registry.
var LOOSEPLAIN = '[v=\\s]*' + src[MAINVERSIONLOOSE] +
                 src[PRERELEASELOOSE] + '?' +
                 src[BUILD] + '?';

var LOOSE = R++;
src[LOOSE] = '^' + LOOSEPLAIN + '$';

var GTLT = R++;
src[GTLT] = '((?:<|>)?=?)';

// Something like "2.*" or "1.2.x".
// Note that "x.x" is a valid xRange identifer, meaning "any version"
// Only the first item is strictly required.
var XRANGEIDENTIFIERLOOSE = R++;
src[XRANGEIDENTIFIERLOOSE] = src[NUMERICIDENTIFIERLOOSE] + '|x|X|\\*';
var XRANGEIDENTIFIER = R++;
src[XRANGEIDENTIFIER] = src[NUMERICIDENTIFIER] + '|x|X|\\*';

var XRANGEPLAIN = R++;
src[XRANGEPLAIN] = '[v=\\s]*(' + src[XRANGEIDENTIFIER] + ')' +
                   '(?:\\.(' + src[XRANGEIDENTIFIER] + ')' +
                   '(?:\\.(' + src[XRANGEIDENTIFIER] + ')' +
                   '(?:' + src[PRERELEASE] + ')?' +
                   src[BUILD] + '?' +
                   ')?)?';

var XRANGEPLAINLOOSE = R++;
src[XRANGEPLAINLOOSE] = '[v=\\s]*(' + src[XRANGEIDENTIFIERLOOSE] + ')' +
                        '(?:\\.(' + src[XRANGEIDENTIFIERLOOSE] + ')' +
                        '(?:\\.(' + src[XRANGEIDENTIFIERLOOSE] + ')' +
                        '(?:' + src[PRERELEASELOOSE] + ')?' +
                        src[BUILD] + '?' +
                        ')?)?';

var XRANGE = R++;
src[XRANGE] = '^' + src[GTLT] + '\\s*' + src[XRANGEPLAIN] + '$';
var XRANGELOOSE = R++;
src[XRANGELOOSE] = '^' + src[GTLT] + '\\s*' + src[XRANGEPLAINLOOSE] + '$';

// Tilde ranges.
// Meaning is "reasonably at or greater than"
var LONETILDE = R++;
src[LONETILDE] = '(?:~>?)';

var TILDETRIM = R++;
src[TILDETRIM] = '(\\s*)' + src[LONETILDE] + '\\s+';
re[TILDETRIM] = new RegExp(src[TILDETRIM], 'g');
var tildeTrimReplace = '$1~';

var TILDE = R++;
src[TILDE] = '^' + src[LONETILDE] + src[XRANGEPLAIN] + '$';
var TILDELOOSE = R++;
src[TILDELOOSE] = '^' + src[LONETILDE] + src[XRANGEPLAINLOOSE] + '$';

// Caret ranges.
// Meaning is "at least and backwards compatible with"
var LONECARET = R++;
src[LONECARET] = '(?:\\^)';

var CARETTRIM = R++;
src[CARETTRIM] = '(\\s*)' + src[LONECARET] + '\\s+';
re[CARETTRIM] = new RegExp(src[CARETTRIM], 'g');
var caretTrimReplace = '$1^';

var CARET = R++;
src[CARET] = '^' + src[LONECARET] + src[XRANGEPLAIN] + '$';
var CARETLOOSE = R++;
src[CARETLOOSE] = '^' + src[LONECARET] + src[XRANGEPLAINLOOSE] + '$';

// A simple gt/lt/eq thing, or just "" to indicate "any version"
var COMPARATORLOOSE = R++;
src[COMPARATORLOOSE] = '^' + src[GTLT] + '\\s*(' + LOOSEPLAIN + ')$|^$';
var COMPARATOR = R++;
src[COMPARATOR] = '^' + src[GTLT] + '\\s*(' + FULLPLAIN + ')$|^$';


// An expression to strip any whitespace between the gtlt and the thing
// it modifies, so that `> 1.2.3` ==> `>1.2.3`
var COMPARATORTRIM = R++;
src[COMPARATORTRIM] = '(\\s*)' + src[GTLT] +
                      '\\s*(' + LOOSEPLAIN + '|' + src[XRANGEPLAIN] + ')';

// this one has to use the /g flag
re[COMPARATORTRIM] = new RegExp(src[COMPARATORTRIM], 'g');
var comparatorTrimReplace = '$1$2$3';


// Something like `1.2.3 - 1.2.4`
// Note that these all use the loose form, because they'll be
// checked against either the strict or loose comparator form
// later.
var HYPHENRANGE = R++;
src[HYPHENRANGE] = '^\\s*(' + src[XRANGEPLAIN] + ')' +
                   '\\s+-\\s+' +
                   '(' + src[XRANGEPLAIN] + ')' +
                   '\\s*$';

var HYPHENRANGELOOSE = R++;
src[HYPHENRANGELOOSE] = '^\\s*(' + src[XRANGEPLAINLOOSE] + ')' +
                        '\\s+-\\s+' +
                        '(' + src[XRANGEPLAINLOOSE] + ')' +
                        '\\s*$';

// Star ranges basically just allow anything at all.
var STAR = R++;
src[STAR] = '(<|>)?=?\\s*\\*';

// Compile to actual regexp objects.
// All are flag-free, unless they were created above with a flag.
for (var i = 0; i < R; i++) {
  debug(i, src[i]);
  if (!re[i])
    re[i] = new RegExp(src[i]);
}

exports.parse = parse;
function parse(version, loose) {
  if (version instanceof SemVer)
    return version;

  if (typeof version !== 'string')
    return null;

  if (version.length > MAX_LENGTH)
    return null;

  var r = loose ? re[LOOSE] : re[FULL];
  if (!r.test(version))
    return null;

  try {
    return new SemVer(version, loose);
  } catch (er) {
    return null;
  }
}

exports.valid = valid;
function valid(version, loose) {
  var v = parse(version, loose);
  return v ? v.version : null;
}


exports.clean = clean;
function clean(version, loose) {
  var s = parse(version.trim().replace(/^[=v]+/, ''), loose);
  return s ? s.version : null;
}

exports.SemVer = SemVer;

function SemVer(version, loose) {
  if (version instanceof SemVer) {
    if (version.loose === loose)
      return version;
    else
      version = version.version;
  } else if (typeof version !== 'string') {
    throw new TypeError('Invalid Version: ' + version);
  }

  if (version.length > MAX_LENGTH)
    throw new TypeError('version is longer than ' + MAX_LENGTH + ' characters')

  if (!(this instanceof SemVer))
    return new SemVer(version, loose);

  debug('SemVer', version, loose);
  this.loose = loose;
  var m = version.trim().match(loose ? re[LOOSE] : re[FULL]);

  if (!m)
    throw new TypeError('Invalid Version: ' + version);

  this.raw = version;

  // these are actually numbers
  this.major = +m[1];
  this.minor = +m[2];
  this.patch = +m[3];

  if (this.major > MAX_SAFE_INTEGER || this.major < 0)
    throw new TypeError('Invalid major version')

  if (this.minor > MAX_SAFE_INTEGER || this.minor < 0)
    throw new TypeError('Invalid minor version')

  if (this.patch > MAX_SAFE_INTEGER || this.patch < 0)
    throw new TypeError('Invalid patch version')

  // numberify any prerelease numeric ids
  if (!m[4])
    this.prerelease = [];
  else
    this.prerelease = m[4].split('.').map(function(id) {
      if (/^[0-9]+$/.test(id)) {
        var num = +id;
        if (num >= 0 && num < MAX_SAFE_INTEGER)
          return num;
      }
      return id;
    });

  this.build = m[5] ? m[5].split('.') : [];
  this.format();
}

SemVer.prototype.format = function() {
  this.version = this.major + '.' + this.minor + '.' + this.patch;
  if (this.prerelease.length)
    this.version += '-' + this.prerelease.join('.');
  return this.version;
};

SemVer.prototype.toString = function() {
  return this.version;
};

SemVer.prototype.compare = function(other) {
  debug('SemVer.compare', this.version, this.loose, other);
  if (!(other instanceof SemVer))
    other = new SemVer(other, this.loose);

  return this.compareMain(other) || this.comparePre(other);
};

SemVer.prototype.compareMain = function(other) {
  if (!(other instanceof SemVer))
    other = new SemVer(other, this.loose);

  return compareIdentifiers(this.major, other.major) ||
         compareIdentifiers(this.minor, other.minor) ||
         compareIdentifiers(this.patch, other.patch);
};

SemVer.prototype.comparePre = function(other) {
  if (!(other instanceof SemVer))
    other = new SemVer(other, this.loose);

  // NOT having a prerelease is > having one
  if (this.prerelease.length && !other.prerelease.length)
    return -1;
  else if (!this.prerelease.length && other.prerelease.length)
    return 1;
  else if (!this.prerelease.length && !other.prerelease.length)
    return 0;

  var i = 0;
  do {
    var a = this.prerelease[i];
    var b = other.prerelease[i];
    debug('prerelease compare', i, a, b);
    if (a === undefined && b === undefined)
      return 0;
    else if (b === undefined)
      return 1;
    else if (a === undefined)
      return -1;
    else if (a === b)
      continue;
    else
      return compareIdentifiers(a, b);
  } while (++i);
};

// preminor will bump the version up to the next minor release, and immediately
// down to pre-release. premajor and prepatch work the same way.
SemVer.prototype.inc = function(release, identifier) {
  switch (release) {
    case 'premajor':
      this.prerelease.length = 0;
      this.patch = 0;
      this.minor = 0;
      this.major++;
      this.inc('pre', identifier);
      break;
    case 'preminor':
      this.prerelease.length = 0;
      this.patch = 0;
      this.minor++;
      this.inc('pre', identifier);
      break;
    case 'prepatch':
      // If this is already a prerelease, it will bump to the next version
      // drop any prereleases that might already exist, since they are not
      // relevant at this point.
      this.prerelease.length = 0;
      this.inc('patch', identifier);
      this.inc('pre', identifier);
      break;
    // If the input is a non-prerelease version, this acts the same as
    // prepatch.
    case 'prerelease':
      if (this.prerelease.length === 0)
        this.inc('patch', identifier);
      this.inc('pre', identifier);
      break;

    case 'major':
      // If this is a pre-major version, bump up to the same major version.
      // Otherwise increment major.
      // 1.0.0-5 bumps to 1.0.0
      // 1.1.0 bumps to 2.0.0
      if (this.minor !== 0 || this.patch !== 0 || this.prerelease.length === 0)
        this.major++;
      this.minor = 0;
      this.patch = 0;
      this.prerelease = [];
      break;
    case 'minor':
      // If this is a pre-minor version, bump up to the same minor version.
      // Otherwise increment minor.
      // 1.2.0-5 bumps to 1.2.0
      // 1.2.1 bumps to 1.3.0
      if (this.patch !== 0 || this.prerelease.length === 0)
        this.minor++;
      this.patch = 0;
      this.prerelease = [];
      break;
    case 'patch':
      // If this is not a pre-release version, it will increment the patch.
      // If it is a pre-release it will bump up to the same patch version.
      // 1.2.0-5 patches to 1.2.0
      // 1.2.0 patches to 1.2.1
      if (this.prerelease.length === 0)
        this.patch++;
      this.prerelease = [];
      break;
    // This probably shouldn't be used publicly.
    // 1.0.0 "pre" would become 1.0.0-0 which is the wrong direction.
    case 'pre':
      if (this.prerelease.length === 0)
        this.prerelease = [0];
      else {
        var i = this.prerelease.length;
        while (--i >= 0) {
          if (typeof this.prerelease[i] === 'number') {
            this.prerelease[i]++;
            i = -2;
          }
        }
        if (i === -1) // didn't increment anything
          this.prerelease.push(0);
      }
      if (identifier) {
        // 1.2.0-beta.1 bumps to 1.2.0-beta.2,
        // 1.2.0-beta.fooblz or 1.2.0-beta bumps to 1.2.0-beta.0
        if (this.prerelease[0] === identifier) {
          if (isNaN(this.prerelease[1]))
            this.prerelease = [identifier, 0];
        } else
          this.prerelease = [identifier, 0];
      }
      break;

    default:
      throw new Error('invalid increment argument: ' + release);
  }
  this.format();
  this.raw = this.version;
  return this;
};

exports.inc = inc;
function inc(version, release, loose, identifier) {
  if (typeof(loose) === 'string') {
    identifier = loose;
    loose = undefined;
  }

  try {
    return new SemVer(version, loose).inc(release, identifier).version;
  } catch (er) {
    return null;
  }
}

exports.diff = diff;
function diff(version1, version2) {
  if (eq(version1, version2)) {
    return null;
  } else {
    var v1 = parse(version1);
    var v2 = parse(version2);
    if (v1.prerelease.length || v2.prerelease.length) {
      for (var key in v1) {
        if (key === 'major' || key === 'minor' || key === 'patch') {
          if (v1[key] !== v2[key]) {
            return 'pre'+key;
          }
        }
      }
      return 'prerelease';
    }
    for (var key in v1) {
      if (key === 'major' || key === 'minor' || key === 'patch') {
        if (v1[key] !== v2[key]) {
          return key;
        }
      }
    }
  }
}

exports.compareIdentifiers = compareIdentifiers;

var numeric = /^[0-9]+$/;
function compareIdentifiers(a, b) {
  var anum = numeric.test(a);
  var bnum = numeric.test(b);

  if (anum && bnum) {
    a = +a;
    b = +b;
  }

  return (anum && !bnum) ? -1 :
         (bnum && !anum) ? 1 :
         a < b ? -1 :
         a > b ? 1 :
         0;
}

exports.rcompareIdentifiers = rcompareIdentifiers;
function rcompareIdentifiers(a, b) {
  return compareIdentifiers(b, a);
}

exports.major = major;
function major(a, loose) {
  return new SemVer(a, loose).major;
}

exports.minor = minor;
function minor(a, loose) {
  return new SemVer(a, loose).minor;
}

exports.patch = patch;
function patch(a, loose) {
  return new SemVer(a, loose).patch;
}

exports.compare = compare;
function compare(a, b, loose) {
  return new SemVer(a, loose).compare(new SemVer(b, loose));
}

exports.compareLoose = compareLoose;
function compareLoose(a, b) {
  return compare(a, b, true);
}

exports.rcompare = rcompare;
function rcompare(a, b, loose) {
  return compare(b, a, loose);
}

exports.sort = sort;
function sort(list, loose) {
  return list.sort(function(a, b) {
    return exports.compare(a, b, loose);
  });
}

exports.rsort = rsort;
function rsort(list, loose) {
  return list.sort(function(a, b) {
    return exports.rcompare(a, b, loose);
  });
}

exports.gt = gt;
function gt(a, b, loose) {
  return compare(a, b, loose) > 0;
}

exports.lt = lt;
function lt(a, b, loose) {
  return compare(a, b, loose) < 0;
}

exports.eq = eq;
function eq(a, b, loose) {
  return compare(a, b, loose) === 0;
}

exports.neq = neq;
function neq(a, b, loose) {
  return compare(a, b, loose) !== 0;
}

exports.gte = gte;
function gte(a, b, loose) {
  return compare(a, b, loose) >= 0;
}

exports.lte = lte;
function lte(a, b, loose) {
  return compare(a, b, loose) <= 0;
}

exports.cmp = cmp;
function cmp(a, op, b, loose) {
  var ret;
  switch (op) {
    case '===':
      if (typeof a === 'object') a = a.version;
      if (typeof b === 'object') b = b.version;
      ret = a === b;
      break;
    case '!==':
      if (typeof a === 'object') a = a.version;
      if (typeof b === 'object') b = b.version;
      ret = a !== b;
      break;
    case '': case '=': case '==': ret = eq(a, b, loose); break;
    case '!=': ret = neq(a, b, loose); break;
    case '>': ret = gt(a, b, loose); break;
    case '>=': ret = gte(a, b, loose); break;
    case '<': ret = lt(a, b, loose); break;
    case '<=': ret = lte(a, b, loose); break;
    default: throw new TypeError('Invalid operator: ' + op);
  }
  return ret;
}

exports.Comparator = Comparator;
function Comparator(comp, loose) {
  if (comp instanceof Comparator) {
    if (comp.loose === loose)
      return comp;
    else
      comp = comp.value;
  }

  if (!(this instanceof Comparator))
    return new Comparator(comp, loose);

  debug('comparator', comp, loose);
  this.loose = loose;
  this.parse(comp);

  if (this.semver === ANY)
    this.value = '';
  else
    this.value = this.operator + this.semver.version;

  debug('comp', this);
}

var ANY = {};
Comparator.prototype.parse = function(comp) {
  var r = this.loose ? re[COMPARATORLOOSE] : re[COMPARATOR];
  var m = comp.match(r);

  if (!m)
    throw new TypeError('Invalid comparator: ' + comp);

  this.operator = m[1];
  if (this.operator === '=')
    this.operator = '';

  // if it literally is just '>' or '' then allow anything.
  if (!m[2])
    this.semver = ANY;
  else
    this.semver = new SemVer(m[2], this.loose);
};

Comparator.prototype.toString = function() {
  return this.value;
};

Comparator.prototype.test = function(version) {
  debug('Comparator.test', version, this.loose);

  if (this.semver === ANY)
    return true;

  if (typeof version === 'string')
    version = new SemVer(version, this.loose);

  return cmp(version, this.operator, this.semver, this.loose);
};

Comparator.prototype.intersects = function(comp, loose) {
  if (!(comp instanceof Comparator)) {
    throw new TypeError('a Comparator is required');
  }

  var rangeTmp;

  if (this.operator === '') {
    rangeTmp = new Range(comp.value, loose);
    return satisfies(this.value, rangeTmp, loose);
  } else if (comp.operator === '') {
    rangeTmp = new Range(this.value, loose);
    return satisfies(comp.semver, rangeTmp, loose);
  }

  var sameDirectionIncreasing =
    (this.operator === '>=' || this.operator === '>') &&
    (comp.operator === '>=' || comp.operator === '>');
  var sameDirectionDecreasing =
    (this.operator === '<=' || this.operator === '<') &&
    (comp.operator === '<=' || comp.operator === '<');
  var sameSemVer = this.semver.version === comp.semver.version;
  var differentDirectionsInclusive =
    (this.operator === '>=' || this.operator === '<=') &&
    (comp.operator === '>=' || comp.operator === '<=');
  var oppositeDirectionsLessThan =
    cmp(this.semver, '<', comp.semver, loose) &&
    ((this.operator === '>=' || this.operator === '>') &&
    (comp.operator === '<=' || comp.operator === '<'));
  var oppositeDirectionsGreaterThan =
    cmp(this.semver, '>', comp.semver, loose) &&
    ((this.operator === '<=' || this.operator === '<') &&
    (comp.operator === '>=' || comp.operator === '>'));

  return sameDirectionIncreasing || sameDirectionDecreasing ||
    (sameSemVer && differentDirectionsInclusive) ||
    oppositeDirectionsLessThan || oppositeDirectionsGreaterThan;
};


exports.Range = Range;
function Range(range, loose) {
  if (range instanceof Range) {
    if (range.loose === loose) {
      return range;
    } else {
      return new Range(range.raw, loose);
    }
  }

  if (range instanceof Comparator) {
    return new Range(range.value, loose);
  }

  if (!(this instanceof Range))
    return new Range(range, loose);

  this.loose = loose;

  // First, split based on boolean or ||
  this.raw = range;
  this.set = range.split(/\s*\|\|\s*/).map(function(range) {
    return this.parseRange(range.trim());
  }, this).filter(function(c) {
    // throw out any that are not relevant for whatever reason
    return c.length;
  });

  if (!this.set.length) {
    throw new TypeError('Invalid SemVer Range: ' + range);
  }

  this.format();
}

Range.prototype.format = function() {
  this.range = this.set.map(function(comps) {
    return comps.join(' ').trim();
  }).join('||').trim();
  return this.range;
};

Range.prototype.toString = function() {
  return this.range;
};

Range.prototype.parseRange = function(range) {
  var loose = this.loose;
  range = range.trim();
  debug('range', range, loose);
  // `1.2.3 - 1.2.4` => `>=1.2.3 <=1.2.4`
  var hr = loose ? re[HYPHENRANGELOOSE] : re[HYPHENRANGE];
  range = range.replace(hr, hyphenReplace);
  debug('hyphen replace', range);
  // `> 1.2.3 < 1.2.5` => `>1.2.3 <1.2.5`
  range = range.replace(re[COMPARATORTRIM], comparatorTrimReplace);
  debug('comparator trim', range, re[COMPARATORTRIM]);

  // `~ 1.2.3` => `~1.2.3`
  range = range.replace(re[TILDETRIM], tildeTrimReplace);

  // `^ 1.2.3` => `^1.2.3`
  range = range.replace(re[CARETTRIM], caretTrimReplace);

  // normalize spaces
  range = range.split(/\s+/).join(' ');

  // At this point, the range is completely trimmed and
  // ready to be split into comparators.

  var compRe = loose ? re[COMPARATORLOOSE] : re[COMPARATOR];
  var set = range.split(' ').map(function(comp) {
    return parseComparator(comp, loose);
  }).join(' ').split(/\s+/);
  if (this.loose) {
    // in loose mode, throw out any that are not valid comparators
    set = set.filter(function(comp) {
      return !!comp.match(compRe);
    });
  }
  set = set.map(function(comp) {
    return new Comparator(comp, loose);
  });

  return set;
};

Range.prototype.intersects = function(range, loose) {
  if (!(range instanceof Range)) {
    throw new TypeError('a Range is required');
  }

  return this.set.some(function(thisComparators) {
    return thisComparators.every(function(thisComparator) {
      return range.set.some(function(rangeComparators) {
        return rangeComparators.every(function(rangeComparator) {
          return thisComparator.intersects(rangeComparator, loose);
        });
      });
    });
  });
};

// Mostly just for testing and legacy API reasons
exports.toComparators = toComparators;
function toComparators(range, loose) {
  return new Range(range, loose).set.map(function(comp) {
    return comp.map(function(c) {
      return c.value;
    }).join(' ').trim().split(' ');
  });
}

// comprised of xranges, tildes, stars, and gtlt's at this point.
// already replaced the hyphen ranges
// turn into a set of JUST comparators.
function parseComparator(comp, loose) {
  debug('comp', comp);
  comp = replaceCarets(comp, loose);
  debug('caret', comp);
  comp = replaceTildes(comp, loose);
  debug('tildes', comp);
  comp = replaceXRanges(comp, loose);
  debug('xrange', comp);
  comp = replaceStars(comp, loose);
  debug('stars', comp);
  return comp;
}

function isX(id) {
  return !id || id.toLowerCase() === 'x' || id === '*';
}

// ~, ~> --> * (any, kinda silly)
// ~2, ~2.x, ~2.x.x, ~>2, ~>2.x ~>2.x.x --> >=2.0.0 <3.0.0
// ~2.0, ~2.0.x, ~>2.0, ~>2.0.x --> >=2.0.0 <2.1.0
// ~1.2, ~1.2.x, ~>1.2, ~>1.2.x --> >=1.2.0 <1.3.0
// ~1.2.3, ~>1.2.3 --> >=1.2.3 <1.3.0
// ~1.2.0, ~>1.2.0 --> >=1.2.0 <1.3.0
function replaceTildes(comp, loose) {
  return comp.trim().split(/\s+/).map(function(comp) {
    return replaceTilde(comp, loose);
  }).join(' ');
}

function replaceTilde(comp, loose) {
  var r = loose ? re[TILDELOOSE] : re[TILDE];
  return comp.replace(r, function(_, M, m, p, pr) {
    debug('tilde', comp, _, M, m, p, pr);
    var ret;

    if (isX(M))
      ret = '';
    else if (isX(m))
      ret = '>=' + M + '.0.0 <' + (+M + 1) + '.0.0';
    else if (isX(p))
      // ~1.2 == >=1.2.0 <1.3.0
      ret = '>=' + M + '.' + m + '.0 <' + M + '.' + (+m + 1) + '.0';
    else if (pr) {
      debug('replaceTilde pr', pr);
      if (pr.charAt(0) !== '-')
        pr = '-' + pr;
      ret = '>=' + M + '.' + m + '.' + p + pr +
            ' <' + M + '.' + (+m + 1) + '.0';
    } else
      // ~1.2.3 == >=1.2.3 <1.3.0
      ret = '>=' + M + '.' + m + '.' + p +
            ' <' + M + '.' + (+m + 1) + '.0';

    debug('tilde return', ret);
    return ret;
  });
}

// ^ --> * (any, kinda silly)
// ^2, ^2.x, ^2.x.x --> >=2.0.0 <3.0.0
// ^2.0, ^2.0.x --> >=2.0.0 <3.0.0
// ^1.2, ^1.2.x --> >=1.2.0 <2.0.0
// ^1.2.3 --> >=1.2.3 <2.0.0
// ^1.2.0 --> >=1.2.0 <2.0.0
function replaceCarets(comp, loose) {
  return comp.trim().split(/\s+/).map(function(comp) {
    return replaceCaret(comp, loose);
  }).join(' ');
}

function replaceCaret(comp, loose) {
  debug('caret', comp, loose);
  var r = loose ? re[CARETLOOSE] : re[CARET];
  return comp.replace(r, function(_, M, m, p, pr) {
    debug('caret', comp, _, M, m, p, pr);
    var ret;

    if (isX(M))
      ret = '';
    else if (isX(m))
      ret = '>=' + M + '.0.0 <' + (+M + 1) + '.0.0';
    else if (isX(p)) {
      if (M === '0')
        ret = '>=' + M + '.' + m + '.0 <' + M + '.' + (+m + 1) + '.0';
      else
        ret = '>=' + M + '.' + m + '.0 <' + (+M + 1) + '.0.0';
    } else if (pr) {
      debug('replaceCaret pr', pr);
      if (pr.charAt(0) !== '-')
        pr = '-' + pr;
      if (M === '0') {
        if (m === '0')
          ret = '>=' + M + '.' + m + '.' + p + pr +
                ' <' + M + '.' + m + '.' + (+p + 1);
        else
          ret = '>=' + M + '.' + m + '.' + p + pr +
                ' <' + M + '.' + (+m + 1) + '.0';
      } else
        ret = '>=' + M + '.' + m + '.' + p + pr +
              ' <' + (+M + 1) + '.0.0';
    } else {
      debug('no pr');
      if (M === '0') {
        if (m === '0')
          ret = '>=' + M + '.' + m + '.' + p +
                ' <' + M + '.' + m + '.' + (+p + 1);
        else
          ret = '>=' + M + '.' + m + '.' + p +
                ' <' + M + '.' + (+m + 1) + '.0';
      } else
        ret = '>=' + M + '.' + m + '.' + p +
              ' <' + (+M + 1) + '.0.0';
    }

    debug('caret return', ret);
    return ret;
  });
}

function replaceXRanges(comp, loose) {
  debug('replaceXRanges', comp, loose);
  return comp.split(/\s+/).map(function(comp) {
    return replaceXRange(comp, loose);
  }).join(' ');
}

function replaceXRange(comp, loose) {
  comp = comp.trim();
  var r = loose ? re[XRANGELOOSE] : re[XRANGE];
  return comp.replace(r, function(ret, gtlt, M, m, p, pr) {
    debug('xRange', comp, ret, gtlt, M, m, p, pr);
    var xM = isX(M);
    var xm = xM || isX(m);
    var xp = xm || isX(p);
    var anyX = xp;

    if (gtlt === '=' && anyX)
      gtlt = '';

    if (xM) {
      if (gtlt === '>' || gtlt === '<') {
        // nothing is allowed
        ret = '<0.0.0';
      } else {
        // nothing is forbidden
        ret = '*';
      }
    } else if (gtlt && anyX) {
      // replace X with 0
      if (xm)
        m = 0;
      if (xp)
        p = 0;

      if (gtlt === '>') {
        // >1 => >=2.0.0
        // >1.2 => >=1.3.0
        // >1.2.3 => >= 1.2.4
        gtlt = '>=';
        if (xm) {
          M = +M + 1;
          m = 0;
          p = 0;
        } else if (xp) {
          m = +m + 1;
          p = 0;
        }
      } else if (gtlt === '<=') {
        // <=0.7.x is actually <0.8.0, since any 0.7.x should
        // pass.  Similarly, <=7.x is actually <8.0.0, etc.
        gtlt = '<';
        if (xm)
          M = +M + 1;
        else
          m = +m + 1;
      }

      ret = gtlt + M + '.' + m + '.' + p;
    } else if (xm) {
      ret = '>=' + M + '.0.0 <' + (+M + 1) + '.0.0';
    } else if (xp) {
      ret = '>=' + M + '.' + m + '.0 <' + M + '.' + (+m + 1) + '.0';
    }

    debug('xRange return', ret);

    return ret;
  });
}

// Because * is AND-ed with everything else in the comparator,
// and '' means "any version", just remove the *s entirely.
function replaceStars(comp, loose) {
  debug('replaceStars', comp, loose);
  // Looseness is ignored here.  star is always as loose as it gets!
  return comp.trim().replace(re[STAR], '');
}

// This function is passed to string.replace(re[HYPHENRANGE])
// M, m, patch, prerelease, build
// 1.2 - 3.4.5 => >=1.2.0 <=3.4.5
// 1.2.3 - 3.4 => >=1.2.0 <3.5.0 Any 3.4.x will do
// 1.2 - 3.4 => >=1.2.0 <3.5.0
function hyphenReplace($0,
                       from, fM, fm, fp, fpr, fb,
                       to, tM, tm, tp, tpr, tb) {

  if (isX(fM))
    from = '';
  else if (isX(fm))
    from = '>=' + fM + '.0.0';
  else if (isX(fp))
    from = '>=' + fM + '.' + fm + '.0';
  else
    from = '>=' + from;

  if (isX(tM))
    to = '';
  else if (isX(tm))
    to = '<' + (+tM + 1) + '.0.0';
  else if (isX(tp))
    to = '<' + tM + '.' + (+tm + 1) + '.0';
  else if (tpr)
    to = '<=' + tM + '.' + tm + '.' + tp + '-' + tpr;
  else
    to = '<=' + to;

  return (from + ' ' + to).trim();
}


// if ANY of the sets match ALL of its comparators, then pass
Range.prototype.test = function(version) {
  if (!version)
    return false;

  if (typeof version === 'string')
    version = new SemVer(version, this.loose);

  for (var i = 0; i < this.set.length; i++) {
    if (testSet(this.set[i], version))
      return true;
  }
  return false;
};

function testSet(set, version) {
  for (var i = 0; i < set.length; i++) {
    if (!set[i].test(version))
      return false;
  }

  if (version.prerelease.length) {
    // Find the set of versions that are allowed to have prereleases
    // For example, ^1.2.3-pr.1 desugars to >=1.2.3-pr.1 <2.0.0
    // That should allow `1.2.3-pr.2` to pass.
    // However, `1.2.4-alpha.notready` should NOT be allowed,
    // even though it's within the range set by the comparators.
    for (var i = 0; i < set.length; i++) {
      debug(set[i].semver);
      if (set[i].semver === ANY)
        continue;

      if (set[i].semver.prerelease.length > 0) {
        var allowed = set[i].semver;
        if (allowed.major === version.major &&
            allowed.minor === version.minor &&
            allowed.patch === version.patch)
          return true;
      }
    }

    // Version has a -pre, but it's not one of the ones we like.
    return false;
  }

  return true;
}

exports.satisfies = satisfies;
function satisfies(version, range, loose) {
  try {
    range = new Range(range, loose);
  } catch (er) {
    return false;
  }
  return range.test(version);
}

exports.maxSatisfying = maxSatisfying;
function maxSatisfying(versions, range, loose) {
  var max = null;
  var maxSV = null;
  try {
    var rangeObj = new Range(range, loose);
  } catch (er) {
    return null;
  }
  versions.forEach(function (v) {
    if (rangeObj.test(v)) { // satisfies(v, range, loose)
      if (!max || maxSV.compare(v) === -1) { // compare(max, v, true)
        max = v;
        maxSV = new SemVer(max, loose);
      }
    }
  })
  return max;
}

exports.minSatisfying = minSatisfying;
function minSatisfying(versions, range, loose) {
  var min = null;
  var minSV = null;
  try {
    var rangeObj = new Range(range, loose);
  } catch (er) {
    return null;
  }
  versions.forEach(function (v) {
    if (rangeObj.test(v)) { // satisfies(v, range, loose)
      if (!min || minSV.compare(v) === 1) { // compare(min, v, true)
        min = v;
        minSV = new SemVer(min, loose);
      }
    }
  })
  return min;
}

exports.validRange = validRange;
function validRange(range, loose) {
  try {
    // Return '*' instead of '' so that truthiness works.
    // This will throw if it's invalid anyway
    return new Range(range, loose).range || '*';
  } catch (er) {
    return null;
  }
}

// Determine if version is less than all the versions possible in the range
exports.ltr = ltr;
function ltr(version, range, loose) {
  return outside(version, range, '<', loose);
}

// Determine if version is greater than all the versions possible in the range.
exports.gtr = gtr;
function gtr(version, range, loose) {
  return outside(version, range, '>', loose);
}

exports.outside = outside;
function outside(version, range, hilo, loose) {
  version = new SemVer(version, loose);
  range = new Range(range, loose);

  var gtfn, ltefn, ltfn, comp, ecomp;
  switch (hilo) {
    case '>':
      gtfn = gt;
      ltefn = lte;
      ltfn = lt;
      comp = '>';
      ecomp = '>=';
      break;
    case '<':
      gtfn = lt;
      ltefn = gte;
      ltfn = gt;
      comp = '<';
      ecomp = '<=';
      break;
    default:
      throw new TypeError('Must provide a hilo val of "<" or ">"');
  }

  // If it satisifes the range it is not outside
  if (satisfies(version, range, loose)) {
    return false;
  }

  // From now on, variable terms are as if we're in "gtr" mode.
  // but note that everything is flipped for the "ltr" function.

  for (var i = 0; i < range.set.length; ++i) {
    var comparators = range.set[i];

    var high = null;
    var low = null;

    comparators.forEach(function(comparator) {
      if (comparator.semver === ANY) {
        comparator = new Comparator('>=0.0.0')
      }
      high = high || comparator;
      low = low || comparator;
      if (gtfn(comparator.semver, high.semver, loose)) {
        high = comparator;
      } else if (ltfn(comparator.semver, low.semver, loose)) {
        low = comparator;
      }
    });

    // If the edge version comparator has a operator then our version
    // isn't outside it
    if (high.operator === comp || high.operator === ecomp) {
      return false;
    }

    // If the lowest version comparator has an operator and our version
    // is less than it then it isn't higher than the range
    if ((!low.operator || low.operator === comp) &&
        ltefn(version, low.semver)) {
      return false;
    } else if (low.operator === ecomp && ltfn(version, low.semver)) {
      return false;
    }
  }
  return true;
}

exports.prerelease = prerelease;
function prerelease(version, loose) {
  var parsed = parse(version, loose);
  return (parsed && parsed.prerelease.length) ? parsed.prerelease : null;
}

exports.intersects = intersects;
function intersects(r1, r2, loose) {
  r1 = new Range(r1, loose)
  r2 = new Range(r2, loose)
  return r1.intersects(r2)
}


/***/ }),
/* 12 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__fast_object_js__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__extensions_js__ = __webpack_require__(86);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__init_paths_js__ = __webpack_require__(53);





const state = new __WEBPACK_IMPORTED_MODULE_0__fast_object_js__["a" /* default */]();
state.cache = Object.create(null);
state.extensions = __WEBPACK_IMPORTED_MODULE_1__extensions_js__["a" /* default */];
state.globalPaths = Object(__WEBPACK_IMPORTED_MODULE_2__init_paths_js__["a" /* default */])();
state.requireDepth = 0;

/* harmony default export */ __webpack_exports__["a"] = (state);

/***/ }),
/* 13 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = isNewLine;
// Matches a whole line break (where CRLF is considered a single
// line break). Used to count lines.

const lineBreak = /\r\n?|\n|\u2028|\u2029/;
/* harmony export (immutable) */ __webpack_exports__["b"] = lineBreak;

const lineBreakG = new RegExp(lineBreak.source, "g");
/* harmony export (immutable) */ __webpack_exports__["c"] = lineBreakG;


function isNewLine(code) {
  return code === 10 || code === 13 || code === 0x2028 || code === 0x2029;
}

const nonASCIIwhitespace = /[\u1680\u180e\u2000-\u200a\u202f\u205f\u3000\ufeff]/;
/* harmony export (immutable) */ __webpack_exports__["d"] = nonASCIIwhitespace;


const skipWhiteSpace = /(?:\s|\/\/.*|\/\*[^]*?\*\/)*/g;
/* harmony export (immutable) */ __webpack_exports__["e"] = skipWhiteSpace;


/***/ }),
/* 14 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
function wrap(func, wrapper) {
  return function () {
    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
      args[_key] = arguments[_key];
    }

    return wrapper.call(this, func, args);
  };
}

/* harmony default export */ __webpack_exports__["a"] = (wrap);

/***/ }),
/* 15 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_path__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_path___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_path__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__fast_object_js__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__util_create_options_js__ = __webpack_require__(2);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__util_has_js__ = __webpack_require__(7);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__fs_read_json_js__ = __webpack_require__(82);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__fs_readdir_js__ = __webpack_require__(84);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6_semver__ = __webpack_require__(11);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6_semver___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_6_semver__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__version_js__ = __webpack_require__(34);











const defaultOptions = Object(__WEBPACK_IMPORTED_MODULE_2__util_create_options_js__["a" /* default */])({
  cache: ".esm-cache",
  cjs: false,
  debug: false,
  esm: "mjs",
  ext: false
});

const infoCache = new __WEBPACK_IMPORTED_MODULE_1__fast_object_js__["a" /* default */]();

class PkgInfo {
  constructor(dirPath, range, options) {
    options = typeof options === "string" ? { esm: options } : options;
    options = Object(__WEBPACK_IMPORTED_MODULE_2__util_create_options_js__["a" /* default */])(options, defaultOptions);

    if (!options.esm) {
      options.esm = "mjs";
    }

    const cache = Object.create(null);
    const cacheDir = options.cache;
    const cachePath = typeof cacheDir === "string" ? Object(__WEBPACK_IMPORTED_MODULE_0_path__["join"])(dirPath, cacheDir) : null;
    const cacheFileNames = cachePath === null ? null : Object(__WEBPACK_IMPORTED_MODULE_5__fs_readdir_js__["a" /* default */])(cachePath);

    let i = -1;
    const nameCount = cacheFileNames === null ? 0 : cacheFileNames.length;

    while (++i < nameCount) {
      // Later, in the ".js" or ".mjs" compiler, we'll change the cached value
      // to its associated mocked compiler result, but for now we merely register
      // that a cache file exists.
      cache[cacheFileNames[i]] = true;
    }

    this.cache = cache;
    this.cachePath = cachePath;
    this.dirPath = dirPath;
    this.options = options;
    this.range = range;
  }

  static get(dirPath) {
    if (dirPath in infoCache) {
      return infoCache[dirPath];
    }

    infoCache[dirPath] = null;

    if (Object(__WEBPACK_IMPORTED_MODULE_0_path__["basename"])(dirPath) === "node_modules") {
      return null;
    }

    let pkgInfo = PkgInfo.read(dirPath);

    if (pkgInfo === null) {
      const parentPath = Object(__WEBPACK_IMPORTED_MODULE_0_path__["dirname"])(dirPath);
      pkgInfo = parentPath === dirPath ? null : PkgInfo.get(parentPath);
    }

    return infoCache[dirPath] = pkgInfo;
  }

  static read(dirPath, force) {
    const pkgPath = Object(__WEBPACK_IMPORTED_MODULE_0_path__["join"])(dirPath, "package.json");
    let pkgJSON = Object(__WEBPACK_IMPORTED_MODULE_4__fs_read_json_js__["a" /* default */])(pkgPath);

    if (pkgJSON === null) {
      if (force) {
        pkgJSON = Object.create(null);
      } else {
        return null;
      }
    }

    let options = null;
    if (Object(__WEBPACK_IMPORTED_MODULE_3__util_has_js__["a" /* default */])(pkgJSON, "@std/esm")) {
      options = pkgJSON["@std/esm"];
    } else if (Object(__WEBPACK_IMPORTED_MODULE_3__util_has_js__["a" /* default */])(pkgJSON, "@std") && Object(__WEBPACK_IMPORTED_MODULE_3__util_has_js__["a" /* default */])(pkgJSON["@std"], "esm")) {
      options = pkgJSON["@std"].esm;
    }

    if (!force && options === false) {
      // An explicit "@std/esm": false property in package.json disables esm
      // loading even if "@std/esm" is listed as a dependency.
      return null;
    }

    // Use case: a package.json file may have "@std/esm" in its "devDependencies"
    // object because it expects another package or application to enable esm
    // loading in production, but needs its own copy of the "@std/esm" package
    // during development. Disabling esm loading in production when it was
    // enabled in development would be undesired in this case.
    let range = getRange(pkgJSON, "dependencies") || getRange(pkgJSON, "peerDependencies") || getRange(pkgJSON, "devDependencies");

    if (range === null) {
      if (options || force) {
        range = "*";
      } else {
        return null;
      }
    }

    const pkgInfo = new PkgInfo(dirPath, range, options);

    if (force && options === false) {
      pkgInfo.options = null;
    }

    return pkgInfo;
  }

  static set(dirPath, pkgInfo) {
    infoCache[dirPath] = pkgInfo;
  }
}

PkgInfo.defaultOptions = defaultOptions;
function getRange(json, name) {
  const entry = json[name];
  return Object(__WEBPACK_IMPORTED_MODULE_3__util_has_js__["a" /* default */])(entry, "@std/esm") ? Object(__WEBPACK_IMPORTED_MODULE_6_semver__["validRange"])(entry["@std/esm"]) : null;
}

Object.setPrototypeOf(PkgInfo.prototype, null);

// Enable in-memory caching when compiling without a file path.
infoCache[""] = new PkgInfo("", __WEBPACK_IMPORTED_MODULE_7__version_js__["a" /* version */], {
  cache: false,
  cjs: true,
  gz: true
});

/* harmony default export */ __webpack_exports__["a"] = (PkgInfo);

/***/ }),
/* 16 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
const defineSetter = Object.prototype.__defineSetter__;

function setSetter(object, key, setter) {
  defineSetter.call(object, key, setter);
  return object;
}

/* harmony default export */ __webpack_exports__["a"] = (setSetter);

/***/ }),
/* 17 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__is_object_like_js__ = __webpack_require__(4);


const _keys = Object.keys;

function keys(object) {
  return Object(__WEBPACK_IMPORTED_MODULE_0__is_object_like_js__["a" /* default */])(object) ? _keys(object) : [];
}

/* harmony default export */ __webpack_exports__["a"] = (keys);

/***/ }),
/* 18 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__fast_object_js__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__module_js__ = __webpack_require__(22);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__binding_js__ = __webpack_require__(8);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__util_set_getter_js__ = __webpack_require__(9);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__util_set_property_js__ = __webpack_require__(10);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__util_set_setter_js__ = __webpack_require__(16);








const ids = ["assert", "buffer", "child_process", "cluster", "console", "crypto", "dgram", "dns", "events", "fs", "http", "https", "module", "net", "os", "path", "querystring", "readline", "repl", "stream", "string_decoder", "timers", "tls", "tty", "url", "util", "vm", "zlib"];

const nativeIds = Object.keys(__WEBPACK_IMPORTED_MODULE_2__binding_js__["a" /* default */].natives).filter(function (id) {
  return !id.startsWith("internal/");
});

const builtinModules = ids.concat(nativeIds).reduce(function (object, id) {
  if (id in object) {
    return object;
  }

  Object(__WEBPACK_IMPORTED_MODULE_3__util_set_getter_js__["a" /* default */])(object, id, function () {
    const mod = new __WEBPACK_IMPORTED_MODULE_1__module_js__["a" /* default */](id, null);
    mod.exports = mod.require(id);
    mod.loaded = true;
    return object[id] = mod;
  });

  Object(__WEBPACK_IMPORTED_MODULE_5__util_set_setter_js__["a" /* default */])(object, id, function (value) {
    Object(__WEBPACK_IMPORTED_MODULE_4__util_set_property_js__["a" /* default */])(object, id, { value });
  });

  return object;
}, new __WEBPACK_IMPORTED_MODULE_0__fast_object_js__["a" /* default */]());

/* harmony default export */ __webpack_exports__["a"] = (builtinModules);

/***/ }),
/* 19 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
function isObject(value) {
  return typeof value === "object" && value !== null;
}

/* harmony default export */ __webpack_exports__["a"] = (isObject);

/***/ }),
/* 20 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
const toString = Object.prototype.toString;


function isError(value) {
  return value instanceof Error || toString.call(value) === "[object Error]";
}

/* harmony default export */ __webpack_exports__["a"] = (isError);

/***/ }),
/* 21 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__fast_object_js__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_util__ = __webpack_require__(87);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_util___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_util__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__util_to_string_literal_js__ = __webpack_require__(54);





const codeSym = Symbol.for("@std/esm:errorCode");
const supers = [Error, TypeError];

const errors = new __WEBPACK_IMPORTED_MODULE_0__fast_object_js__["a" /* default */]();
supers.forEach(function (Super) {
  return errors[Super.name] = createClass(Super);
});

const messages = new __WEBPACK_IMPORTED_MODULE_0__fast_object_js__["a" /* default */]();
messages["ERR_INVALID_ARG_TYPE"] = invalidArgType;
messages["ERR_INVALID_PROTOCOL"] = invalidProtocol;
messages["ERR_MISSING_MODULE"] = "Cannot find module %s";
messages["ERR_MODULE_RESOLUTION_DEPRECATED"] = "%s not found by import in %s. Deprecated behavior in require would have found it at %s";
messages["ERR_REQUIRE_ESM"] = "Must use import to load ES Module: %s";

function createClass(Super) {
  class NodeError extends Super {
    constructor(key) {
      for (var _len = arguments.length, args = Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
        args[_key - 1] = arguments[_key];
      }

      super(getMessage(key, args));
      this[codeSym] = key;
    }

    get name() {
      return Super.name + " [" + this[codeSym] + "]";
    }

    get code() {
      return this[codeSym];
    }
  }

  Object.setPrototypeOf(NodeError.prototype, null);
  return NodeError;
}

function getMessage(key, args) {
  const message = messages[key];

  if (typeof message == "function") {
    return message.apply(undefined, args);
  }

  args.unshift(message);
  return __WEBPACK_IMPORTED_MODULE_1_util__["format"].apply(undefined, args);
}

function invalidArgType(name, expected) {
  return "The " + quote(name) + " argument must be " + expected;
}

function invalidProtocol(protocol, expected) {
  return "Protocol " + quote(protocol) + " not supported. Expected " + quote(expected);
}

function quote(value) {
  return Object(__WEBPACK_IMPORTED_MODULE_2__util_to_string_literal_js__["a" /* default */])(value, "'");
}

/* harmony default export */ __webpack_exports__["a"] = (errors);

/***/ }),
/* 22 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_path__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_path___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_path__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__module_compile_js__ = __webpack_require__(88);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__util_defaults_js__ = __webpack_require__(44);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__module_find_path_js__ = __webpack_require__(89);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__module_init_paths_js__ = __webpack_require__(53);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__module_load_js__ = __webpack_require__(90);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__module_state_js__ = __webpack_require__(12);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__module_node_module_paths_js__ = __webpack_require__(27);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__module_resolve_filename_js__ = __webpack_require__(25);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__module_resolve_lookup_paths_js__ = __webpack_require__(91);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__module_wrap_js__ = __webpack_require__(92);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__module_wrapper_js__ = __webpack_require__(58);














const BuiltinModule = __non_webpack_module__.constructor;

class Module extends BuiltinModule {
  constructor(id, parent) {
    super(id, parent);
  }

  _compile(content, filePath) {
    return Object(__WEBPACK_IMPORTED_MODULE_1__module_compile_js__["a" /* default */])(this, content, filePath);
  }

  load(filePath) {
    if (this.loaded) {
      throw new Error("Module already loaded: " + this.id);
    }

    const _extensions = this.constructor._extensions;

    let ext = Object(__WEBPACK_IMPORTED_MODULE_0_path__["extname"])(filePath);

    if (!ext || typeof _extensions[ext] !== "function") {
      ext = ".js";
    }

    this.filename = filePath;
    this.paths = Object(__WEBPACK_IMPORTED_MODULE_7__module_node_module_paths_js__["a" /* default */])(Object(__WEBPACK_IMPORTED_MODULE_0_path__["dirname"])(filePath));
    _extensions[ext](this, filePath);
    this.loaded = true;
  }

}

Module._cache = __WEBPACK_IMPORTED_MODULE_6__module_state_js__["a" /* default */].cache;
Module._extensions = __WEBPACK_IMPORTED_MODULE_6__module_state_js__["a" /* default */].extensions;
Module._findPath = __WEBPACK_IMPORTED_MODULE_3__module_find_path_js__["a" /* default */];
Module._initPaths = __WEBPACK_IMPORTED_MODULE_4__module_init_paths_js__["a" /* default */];
Module._load = __WEBPACK_IMPORTED_MODULE_5__module_load_js__["a" /* default */];
Module._nodeModulePaths = __WEBPACK_IMPORTED_MODULE_7__module_node_module_paths_js__["a" /* default */];
Module._resolveFilename = __WEBPACK_IMPORTED_MODULE_8__module_resolve_filename_js__["a" /* default */];
Module._resolveLookupPaths = __WEBPACK_IMPORTED_MODULE_9__module_resolve_lookup_paths_js__["a" /* default */];
Module._wrapper = __WEBPACK_IMPORTED_MODULE_11__module_wrapper_js__["a" /* default */];
Module.globalPaths = __WEBPACK_IMPORTED_MODULE_6__module_state_js__["a" /* default */].globalPaths;
Module.wrap = __WEBPACK_IMPORTED_MODULE_10__module_wrap_js__["a" /* default */];
Object(__WEBPACK_IMPORTED_MODULE_2__util_defaults_js__["a" /* default */])(Module, BuiltinModule);

/* harmony default export */ __webpack_exports__["a"] = (Module);

/***/ }),
/* 23 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__binding_js__ = __webpack_require__(8);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__util_is_file_js__ = __webpack_require__(83);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__util_is_object_like_js__ = __webpack_require__(4);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_fs__ = __webpack_require__(5);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_fs___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_fs__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__util_strip_bom_js__ = __webpack_require__(45);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__path_to_namespaced_path_js__ = __webpack_require__(33);







const fsBinding = __WEBPACK_IMPORTED_MODULE_0__binding_js__["a" /* default */].fs;
const internalModuleReadFile = fsBinding.internalModuleReadFile;

let useReadFileFastPath = typeof internalModuleReadFile === "function";

function readFile(filePath, options) {
  const encoding = Object(__WEBPACK_IMPORTED_MODULE_2__util_is_object_like_js__["a" /* default */])(options) ? options.encoding : options;
  const isUTF8 = encoding === "utf8";

  if (useReadFileFastPath && isUTF8) {
    try {
      return fastPathReadFile(filePath);
    } catch (e) {
      useReadFileFastPath = false;
    }
  }

  const content = fallbackReadFile(filePath, options);
  return isUTF8 && content !== null ? Object(__WEBPACK_IMPORTED_MODULE_4__util_strip_bom_js__["a" /* default */])(content) : content;
}

function fallbackReadFile(filePath, options) {
  if (Object(__WEBPACK_IMPORTED_MODULE_1__util_is_file_js__["a" /* default */])(filePath)) {
    try {
      return Object(__WEBPACK_IMPORTED_MODULE_3_fs__["readFileSync"])(filePath, options);
    } catch (e) {}
  }

  return null;
}

function fastPathReadFile(filePath) {
  // Used to speed up reading. Returns the contents of the file as a string
  // or undefined when the file cannot be opened. The speedup comes from not
  // creating Error objects on failure.
  const content = internalModuleReadFile.call(fsBinding, Object(__WEBPACK_IMPORTED_MODULE_5__path_to_namespaced_path_js__["a" /* default */])(filePath));
  return content === void 0 ? null : content;
}

/* harmony default export */ __webpack_exports__["a"] = (readFile);

/***/ }),
/* 24 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_fs__ = __webpack_require__(5);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_fs___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_fs__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__binding_js__ = __webpack_require__(8);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__path_to_namespaced_path_js__ = __webpack_require__(33);





const fsBinding = __WEBPACK_IMPORTED_MODULE_1__binding_js__["a" /* default */].fs;
const internalModuleStat = fsBinding.internalModuleStat;
const isFile = __WEBPACK_IMPORTED_MODULE_0_fs__["Stats"].prototype.isFile;


let useStatFastPath = typeof internalModuleStat === "function";

function stat(filePath) {
  const cache = stat.cache;


  if (cache !== null && filePath in cache) {
    return cache[filePath];
  }

  const result = baseStat(filePath);

  if (cache !== null) {
    cache[filePath] = result;
  }

  return result;
}

function baseStat(filePath) {
  if (useStatFastPath) {
    try {
      return fastPathStat(filePath);
    } catch (e) {
      useStatFastPath = false;
    }
  }

  return fallbackStat(filePath);
}

function fallbackStat(filePath) {
  try {
    return isFile.call(Object(__WEBPACK_IMPORTED_MODULE_0_fs__["statSync"])(filePath)) ? 0 : 1;
  } catch (e) {}
  return -1;
}

function fastPathStat(filePath) {
  // Used to speed up loading. Returns 0 if the path refers to a file,
  // 1 when it's a directory or -1 on error (usually ENOENT). The speedup
  // comes from not creating thousands of Stat and Error objects.
  return internalModuleStat.call(fsBinding, Object(__WEBPACK_IMPORTED_MODULE_2__path_to_namespaced_path_js__["a" /* default */])(filePath));
}

stat.cache = null;

/* harmony default export */ __webpack_exports__["a"] = (stat);

/***/ }),
/* 25 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__cjs_resolve_filename_js__ = __webpack_require__(48);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__builtin_modules_js__ = __webpack_require__(18);
// Based on Node's `Module._resolveFilename` method.
// Copyright Node.js contributors. Released under MIT license:
// https://github.com/nodejs/node/blob/master/lib/module.js




function resolveFilename(id, parent, isMain) {
  return id in __WEBPACK_IMPORTED_MODULE_1__builtin_modules_js__["a" /* default */] ? id : Object(__WEBPACK_IMPORTED_MODULE_0__cjs_resolve_filename_js__["a" /* default */])(id, parent, isMain);
}

/* harmony default export */ __webpack_exports__["a"] = (resolveFilename);

/***/ }),
/* 26 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__has_js__ = __webpack_require__(7);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__is_object_like_js__ = __webpack_require__(4);



function assign(object) {
  if (!Object(__WEBPACK_IMPORTED_MODULE_1__is_object_like_js__["a" /* default */])(object)) {
    return object;
  }

  let i = 0;
  const argCount = arguments.length;

  while (++i < argCount) {
    const source = arguments[i];

    if (!Object(__WEBPACK_IMPORTED_MODULE_1__is_object_like_js__["a" /* default */])(source)) {
      continue;
    }

    for (const key in source) {
      if (Object(__WEBPACK_IMPORTED_MODULE_0__has_js__["a" /* default */])(source, key)) {
        object[key] = source[key];
      }
    }
  }

  return object;
}

/* harmony default export */ __webpack_exports__["a"] = (assign);

/***/ }),
/* 27 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_path__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_path___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_path__);
// Based on Node's `Module._nodeModulePaths` method.
// Copyright Node.js contributors. Released under MIT license:
// https://github.com/nodejs/node/blob/master/lib/module.js



const codeOfBackslash = "\\".charCodeAt(0);
const codeOfColon = ":".charCodeAt(0);
const codeOfSlash = "/".charCodeAt(0);

const map = Array.prototype.map;

const nmChars = map.call("node_modules", function (char) {
  return char.charCodeAt(0);
}).reverse();
const nmLength = nmChars.length;

function posixNodeModulePaths(dirPath) {
  dirPath = Object(__WEBPACK_IMPORTED_MODULE_0_path__["resolve"])(dirPath);

  // Return early not only to avoid unnecessary work, but to avoid returning
  // an array of two items for a root path: ["//node_modules", "/node_modules"]
  if (dirPath === "/") {
    return ["/node_modules"];
  }

  // This approach only works when the path is guaranteed to be absolute.
  // Doing a fully-edge-case-correct `path.split()` that works on both Windows
  // and Posix is non-trivial.
  let length = dirPath.length;
  let last = length;
  let nmCount = 0;

  const paths = [];

  while (length--) {
    const code = dirPath.charCodeAt(length);

    if (code === codeOfSlash) {
      if (nmCount !== nmLength) {
        paths.push(dirPath.slice(0, last) + "/node_modules");
      }

      last = length;
      nmCount = 0;
    } else if (nmCount !== -1) {
      if (nmChars[nmCount] === code) {
        ++nmCount;
      } else {
        nmCount = -1;
      }
    }
  }

  // Append "/node_modules" to handle root paths.
  paths.push("/node_modules");

  return paths;
}

function win32NodeModulePaths(dirPath) {
  dirPath = Object(__WEBPACK_IMPORTED_MODULE_0_path__["resolve"])(dirPath);

  // Return root node_modules when path is "D:\\".
  if (dirPath.charCodeAt(dirPath.length - 1) === codeOfBackslash && dirPath.charCodeAt(dirPath.length - 2) === codeOfColon) {
    return [dirPath + "node_modules"];
  }

  let length = dirPath.length;
  let last = length;
  let nmCount = 0;

  const paths = [];

  while (length--) {
    const code = dirPath.charCodeAt(length);

    // The path segment separator check ("\" and "/") was used to get
    // node_modules path for every path segment. Use colon as an extra
    // condition since we can get node_modules path for drive root like
    // "C:\node_modules" and don"t need to parse drive name.
    if (code === codeOfBackslash || code === codeOfSlash || code === codeOfColon) {
      if (nmCount !== nmLength) {
        paths.push(dirPath.slice(0, last) + "\\node_modules");
      }

      last = length;
      nmCount = 0;
    } else if (nmCount !== -1) {
      if (nmChars[nmCount] === code) {
        ++nmCount;
      } else {
        nmCount = -1;
      }
    }
  }

  return paths;
}

/* harmony default export */ __webpack_exports__["a"] = (process.platform === "win32" ? win32NodeModulePaths : posixNodeModulePaths);

/***/ }),
/* 28 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_path__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_path___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_path__);


function extname(filePath) {
  const ext = Object(__WEBPACK_IMPORTED_MODULE_0_path__["extname"])(filePath);
  const prefix = ext === ".gz" ? Object(__WEBPACK_IMPORTED_MODULE_0_path__["extname"])(Object(__WEBPACK_IMPORTED_MODULE_0_path__["basename"])(filePath, ext)) : "";
  return prefix + ext;
}

/* harmony default export */ __webpack_exports__["a"] = (extname);

/***/ }),
/* 29 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = has;
var _Object$prototype = Object.prototype;
const hasOwnProperty = _Object$prototype.hasOwnProperty,
      toString = _Object$prototype.toString;

// Checks if an object has a property.

function has(obj, propName) {
  return hasOwnProperty.call(obj, propName);
}

const isArray = Array.isArray || function (obj) {
  return toString.call(obj) === "[object Array]";
};
/* harmony export (immutable) */ __webpack_exports__["b"] = isArray;


/***/ }),
/* 30 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["c"] = getLineInfo;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__whitespace__ = __webpack_require__(13);


// These are used when `options.locations` is on, for the
// `startLoc` and `endLoc` properties.

class Position {
  constructor(line, col) {
    this.line = line;
    this.column = col;
  }

  offset(n) {
    return new Position(this.line, this.column + n);
  }
}
/* harmony export (immutable) */ __webpack_exports__["a"] = Position;


class SourceLocation {
  constructor(p, start, end) {
    this.start = start;
    this.end = end;
    if (p.sourceFile !== null) this.source = p.sourceFile;
  }
}
/* harmony export (immutable) */ __webpack_exports__["b"] = SourceLocation;


// The `getLineInfo` function is mostly useful when the
// `locations` option is off (for performance reasons) and you
// want to find the line/column position for a given character
// offset. `input` should be the code string that the offset refers
// into.

function getLineInfo(input, offset) {
  for (let line = 1, cur = 0;;) {
    __WEBPACK_IMPORTED_MODULE_0__whitespace__["c" /* lineBreakG */].lastIndex = cur;
    let match = __WEBPACK_IMPORTED_MODULE_0__whitespace__["c" /* lineBreakG */].exec(input);
    if (match && match.index < offset) {
      ++line;
      cur = match.index + match[0].length;
    } else {
      return new Position(line, offset - cur);
    }
  }
}

/***/ }),
/* 31 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__raise_js__ = __webpack_require__(32);


function unexpected(parser, pos) {
  if (typeof pos !== "number") {
    pos = parser.start;
  }
  Object(__WEBPACK_IMPORTED_MODULE_0__raise_js__["a" /* default */])(parser, pos, "Unexpected token");
}

/* harmony default export */ __webpack_exports__["a"] = (unexpected);

/***/ }),
/* 32 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__acorn_parser_js__ = __webpack_require__(40);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__util_assign_js__ = __webpack_require__(26);




const acornRaise = __WEBPACK_IMPORTED_MODULE_0__acorn_parser_js__["a" /* default */].prototype.raise;

function raise(parser, pos, message, ErrorCtor) {
  if (typeof ErrorCtor !== "function") {
    acornRaise.call(parser, pos, message);
  }

  try {
    acornRaise.call(parser, pos, message);
  } catch (e) {
    throw Object(__WEBPACK_IMPORTED_MODULE_1__util_assign_js__["a" /* default */])(new ErrorCtor(e.message), e);
  }
}

/* harmony default export */ __webpack_exports__["a"] = (raise);

/***/ }),
/* 33 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_path__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_path___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_path__);
// Based on Node's `path._makeLong` method.
// Copyright Node.js contributors. Released under MIT license:
// https://github.com/nodejs/node/blob/master/lib/path.js



const codeOfBackslash = "\\".charCodeAt(0);
const codeOfColon = ":".charCodeAt(0);
const codeOfDot = ".".charCodeAt(0);
const codeOfQMark = "?".charCodeAt(0);

function posixToNamespacedPath(thePath) {
  return thePath;
}

function win32ToNamespacedPath(thePath) {
  if (typeof thePath !== "string" || !thePath.length) {
    return thePath;
  }

  const resolvedPath = Object(__WEBPACK_IMPORTED_MODULE_0_path__["resolve"])(thePath);

  if (resolvedPath.length < 3) {
    return thePath;
  }

  const code0 = resolvedPath.charCodeAt(0);
  const code1 = resolvedPath.charCodeAt(1);

  if (code0 === codeOfBackslash) {
    // Convert the network path if it's not already a long UNC path or a named pipe.
    // https://msdn.microsoft.com/library/windows/desktop/aa365783(v=vs.85).aspx
    if (resolvedPath.charCodeAt(1) === codeOfBackslash) {
      const code2 = resolvedPath.charCodeAt(2);

      if (code2 !== codeOfQMark && code2 !== codeOfDot) {
        return "\\\\?\\UNC\\" + resolvedPath.slice(2);
      }
    }

    return thePath;
  }

  // Detect drive letter, i.e. `[A-Za-z]:\\`
  if (code1 === codeOfColon && (code0 > 64 && code0 < 91 || code0 > 96 && code0 < 123) && resolvedPath.charCodeAt(2) === codeOfBackslash) {
    return "\\\\?\\" + resolvedPath;
  }

  return thePath;
}

/* harmony default export */ __webpack_exports__["a"] = (process.platform === "win32" ? win32ToNamespacedPath : posixToNamespacedPath);

/***/ }),
/* 34 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* unused harmony export major */
/* unused harmony export minor */
/* unused harmony export patch */
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return version; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_semver__ = __webpack_require__(11);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_semver___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_semver__);


const semver = new __WEBPACK_IMPORTED_MODULE_0_semver___default.a("0.7.1");
const major = semver.major,
      minor = semver.minor,
      patch = semver.patch,
      version = semver.version;



/* unused harmony default export */ var _unused_webpack_default_export = (semver);

/***/ }),
/* 35 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__errors_js__ = __webpack_require__(21);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__state_js__ = __webpack_require__(12);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__resolve_filename_js__ = __webpack_require__(25);
// Based on Node's `internalModule.makeRequireFunction` method.
// Copyright Node.js contributors. Released under MIT license:
// https://github.com/nodejs/node/blob/master/lib/internal/module.js





function makeRequireFunction(mod) {
  let requirer = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : mod.require;

  function req(id) {
    __WEBPACK_IMPORTED_MODULE_1__state_js__["a" /* default */].requireDepth += 1;

    try {
      if (typeof id !== "string") {
        throw new __WEBPACK_IMPORTED_MODULE_0__errors_js__["a" /* default */].TypeError("ERR_INVALID_ARG_TYPE", "id", "string");
      }

      return requirer.call(mod, id);
    } finally {
      __WEBPACK_IMPORTED_MODULE_1__state_js__["a" /* default */].requireDepth -= 1;
    }
  }

  function resolve(id) {
    return Object(__WEBPACK_IMPORTED_MODULE_2__resolve_filename_js__["a" /* default */])(id, mod);
  }

  req.cache = require.cache;
  req.extensions = require.extensions;
  req.main = process.mainModule;
  req.resolve = resolve;

  return req;
}

/* harmony default export */ __webpack_exports__["a"] = (makeRequireFunction);

/***/ }),
/* 36 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__module_js__ = __webpack_require__(22);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__state_js__ = __webpack_require__(12);
// Based on Node's `Module._load` method.
// Copyright Node.js contributors. Released under MIT license:
// https://github.com/nodejs/node/blob/master/lib/module.js





function load(filePath, parent, isMain, state, loader) {
  let child = state ? state.cache[filePath] : __WEBPACK_IMPORTED_MODULE_1__state_js__["a" /* default */].cache[filePath] || require.cache[filePath];

  if (child) {
    const children = parent && parent.children;

    if (children && children.indexOf(child) === -1) {
      children.push(child);
    }

    return child;
  }

  const Parent = parent ? parent.constructor : __WEBPACK_IMPORTED_MODULE_0__module_js__["a" /* default */];
  child = new Parent(filePath, parent);

  if (isMain) {
    process.mainModule = child;
    child.id = ".";
  }

  tryLoad(child, filePath, state, loader);
  return child;
}

function tryLoad(mod, filePath, state) {
  let loader = arguments.length > 3 && arguments[3] !== undefined ? arguments[3] : mod.load;

  if (state) {
    state.cache[filePath] = mod;
  } else {
    __WEBPACK_IMPORTED_MODULE_1__state_js__["a" /* default */].cache[filePath] = require.cache[filePath] = mod;
  }

  let threw = true;

  try {
    loader.call(mod, filePath);
    threw = false;
  } finally {
    if (threw) {
      if (state) {
        delete state.cache[filePath];
      } else {
        delete __WEBPACK_IMPORTED_MODULE_1__state_js__["a" /* default */].cache[filePath];
        delete require.cache[filePath];
      }
    }
  }
}

/* harmony default export */ __webpack_exports__["a"] = (load);

/***/ }),
/* 37 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_path__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_path___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_path__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__load_js__ = __webpack_require__(36);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__path_extname_js__ = __webpack_require__(28);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__util_get_getter_js__ = __webpack_require__(60);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__util_is_object_js__ = __webpack_require__(19);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__state_js__ = __webpack_require__(12);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__node_module_paths_js__ = __webpack_require__(27);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__resolve_filename_js__ = __webpack_require__(38);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__util_set_getter_js__ = __webpack_require__(9);











const queryHashRegExp = /[?#].*$/;

function load(id, parent, isMain, options) {
  const filePath = Object(__WEBPACK_IMPORTED_MODULE_7__resolve_filename_js__["a" /* default */])(id, parent, isMain, options);

  let child;
  let oldChildA;
  let oldChildB;
  let state;
  let cacheId = filePath;
  let queryHash = queryHashRegExp.exec(id);

  if (Object(__WEBPACK_IMPORTED_MODULE_0_path__["extname"])(filePath) === ".mjs") {
    state = __WEBPACK_IMPORTED_MODULE_5__state_js__["a" /* default */];
  }

  if (queryHash !== null) {
    // Each id with a query+hash is given a new cache entry.
    cacheId = filePath + queryHash[0];

    child = state ? state.cache[cacheId] : __WEBPACK_IMPORTED_MODULE_5__state_js__["a" /* default */].cache[cacheId] || require.cache[cacheId];

    if (child) {
      return child;
    }

    // Backup existing cache entries because Node uses the child module's file
    // path, without query+hash, as its cache id.
    if (state) {
      oldChildA = pluck(state.cache, filePath);
    } else {
      oldChildA = pluck(__WEBPACK_IMPORTED_MODULE_5__state_js__["a" /* default */].cache, filePath);
      oldChildB = pluck(require.cache, filePath);
    }
  }

  let error;
  let threw = true;

  try {
    child = Object(__WEBPACK_IMPORTED_MODULE_1__load_js__["a" /* default */])(filePath, parent, isMain, state, loader);
    threw = false;
  } catch (e) {
    error = e;
  }

  if (queryHash !== null) {
    if (state) {
      state.cache[cacheId] = child;
    } else {
      __WEBPACK_IMPORTED_MODULE_5__state_js__["a" /* default */].cache[cacheId] = require.cache[cacheId] = child;
    }

    if (state) {
      restore(state.cache, filePath, oldChildA);
    } else {
      restore(require.cache, filePath, oldChildA);
      restore(require.cache, filePath, oldChildB);
    }
  }

  if (!threw) {
    return child;
  }

  try {
    throw error;
  } finally {
    // Unlike CJS, ESM errors are preserved for subsequent loads.
    Object(__WEBPACK_IMPORTED_MODULE_8__util_set_getter_js__["a" /* default */])(__WEBPACK_IMPORTED_MODULE_5__state_js__["a" /* default */].cache, cacheId, function () {
      throw error;
    });

    delete require.cache[cacheId];
  }
}

function loader(filePath) {
  let ext = Object(__WEBPACK_IMPORTED_MODULE_2__path_extname_js__["a" /* default */])(filePath);
  const extensions = __WEBPACK_IMPORTED_MODULE_5__state_js__["a" /* default */].extensions;


  if (!ext || typeof extensions[ext] !== "function") {
    ext = ".js";
  }

  const extCompiler = extensions[ext];
  const mod = this;

  if (typeof extCompiler !== "function") {
    mod.load(filePath);
    return;
  }

  mod.filename = filePath;
  mod.paths = Object(__WEBPACK_IMPORTED_MODULE_6__node_module_paths_js__["a" /* default */])(Object(__WEBPACK_IMPORTED_MODULE_0_path__["dirname"])(filePath));

  extCompiler.call(extensions, mod, filePath);
  mod.loaded = true;
}

function pluck(object, key) {
  let value;

  if (key in object) {
    value = Object(__WEBPACK_IMPORTED_MODULE_3__util_get_getter_js__["a" /* default */])(object, key);

    if (typeof value !== "function") {
      value = object[key];

      if (!Object(__WEBPACK_IMPORTED_MODULE_4__util_is_object_js__["a" /* default */])(value)) {
        value = void 0;
      }
    }

    delete object[key];
  }

  return value;
}

function restore(object, key, value) {
  if (value === void 0) {
    delete object[key];
    return;
  }

  if (typeof value === "function") {
    Object(__WEBPACK_IMPORTED_MODULE_8__util_set_getter_js__["a" /* default */])(object, key, value);
  } else {
    object[key] = value;
  }
}

/* harmony default export */ __webpack_exports__["a"] = (load);

/***/ }),
/* 38 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__resolve_filename_js__ = __webpack_require__(49);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__util_decode_uri_component_js__ = __webpack_require__(61);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_path__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_path___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_path__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__util_encoded_slash_js__ = __webpack_require__(62);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__errors_js__ = __webpack_require__(21);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__util_is_path_js__ = __webpack_require__(46);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__util_parse_url_js__ = __webpack_require__(63);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__util_url_to_path_js__ = __webpack_require__(96);









const codeOfSlash = "/".charCodeAt(0);

const pathMode = process.platform === "win32" ? "win32" : "posix";
const searchExts = [".mjs", ".js", ".json", ".node"];

const localhostRegExp = /^\/\/localhost\b/;
const queryHashRegExp = /[?#].*$/;

function resolveFilename(id, parent, isMain, options) {
  if (typeof id !== "string") {
    throw new __WEBPACK_IMPORTED_MODULE_4__errors_js__["a" /* default */].TypeError("ERR_INVALID_ARG_TYPE", "id", "string");
  }

  const filename = parent && typeof parent.filename === "string" ? parent.filename : ".";

  const fromPath = Object(__WEBPACK_IMPORTED_MODULE_2_path__["dirname"])(filename);
  let skipWarnings = false;

  if (!Object(__WEBPACK_IMPORTED_MODULE_3__util_encoded_slash_js__["a" /* default */])(id, pathMode)) {
    if (!Object(__WEBPACK_IMPORTED_MODULE_5__util_is_path_js__["a" /* default */])(id) && (id.charCodeAt(0) === codeOfSlash || id.includes(":"))) {
      const parsed = Object(__WEBPACK_IMPORTED_MODULE_6__util_parse_url_js__["a" /* default */])(id);
      let foundPath = Object(__WEBPACK_IMPORTED_MODULE_7__util_url_to_path_js__["a" /* default */])(parsed, pathMode);

      if (!foundPath && parsed.protocol !== "file:" && !localhostRegExp.test(id)) {
        throw new __WEBPACK_IMPORTED_MODULE_4__errors_js__["a" /* default */].Error("ERR_INVALID_PROTOCOL", parsed.protocol, "file:");
      }

      if (foundPath) {
        foundPath = Object(__WEBPACK_IMPORTED_MODULE_0__resolve_filename_js__["a" /* default */])(foundPath, parent, isMain);
      }

      if (foundPath) {
        return foundPath;
      }
    } else {
      // Prevent resolving non-local dependencies:
      // https://github.com/bmeck/node-eps/blob/rewrite-esm/002-es-modules.md#432-removal-of-non-local-dependencies
      const skipGlobalPaths = !(options && options.cjs);
      const decodedId = Object(__WEBPACK_IMPORTED_MODULE_1__util_decode_uri_component_js__["a" /* default */])(id.replace(queryHashRegExp, ""));
      const foundPath = Object(__WEBPACK_IMPORTED_MODULE_0__resolve_filename_js__["a" /* default */])(decodedId, parent, isMain, skipWarnings, skipGlobalPaths, searchExts);

      if (foundPath) {
        return foundPath;
      }
    }
  }

  skipWarnings = true;
  const foundPath = Object(__WEBPACK_IMPORTED_MODULE_0__resolve_filename_js__["a" /* default */])(id, parent, isMain, skipWarnings);

  if (foundPath) {
    throw new __WEBPACK_IMPORTED_MODULE_4__errors_js__["a" /* default */].Error("ERR_MODULE_RESOLUTION_DEPRECATED", id, fromPath, foundPath);
  }

  throw new __WEBPACK_IMPORTED_MODULE_4__errors_js__["a" /* default */].Error("ERR_MISSING_MODULE", id);
}

/* harmony default export */ __webpack_exports__["a"] = (resolveFilename);

/***/ }),
/* 39 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__fast_object_js__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__util_has_js__ = __webpack_require__(7);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__util_max_satisfying_js__ = __webpack_require__(105);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__version_js__ = __webpack_require__(34);
// This module is critical for @std/esm versioning support and should be changed
// as little as possible. Please ensure any changes are backwards compatible.







const wrapSym = Symbol.for("@std/esm:wrapper");

class Wrapper {
  static find(object, key, range) {
    const map = getMap(object, key);
    if (map !== null) {
      const version = Object(__WEBPACK_IMPORTED_MODULE_2__util_max_satisfying_js__["a" /* default */])(map.versions, range);
      if (version !== null) {
        return map.wrappers[version];
      }
    }
    return null;
  }

  static manage(object, key, wrapper) {
    const raw = Wrapper.unwrap(object, key);
    const manager = function () {
      for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
      }

      return wrapper.call(this, manager, raw, args);
    };

    manager[wrapSym] = raw;
    object[key] = manager;
  }

  static unwrap(object, key) {
    const func = object[key];
    return Object(__WEBPACK_IMPORTED_MODULE_1__util_has_js__["a" /* default */])(func, wrapSym) ? func[wrapSym] : func;
  }

  static wrap(object, key, wrapper) {
    const map = getOrCreateMap(object, key);

    if (typeof map.wrappers[__WEBPACK_IMPORTED_MODULE_3__version_js__["a" /* version */]] !== "function") {
      map.versions.push(__WEBPACK_IMPORTED_MODULE_3__version_js__["a" /* version */]);
      map.wrappers[__WEBPACK_IMPORTED_MODULE_3__version_js__["a" /* version */]] = wrapper;
    }
  }
}

function createMap(object, key) {
  const map = new __WEBPACK_IMPORTED_MODULE_0__fast_object_js__["a" /* default */]();
  map.raw = Wrapper.unwrap(object, key);
  map.versions = [];
  map.wrappers = new __WEBPACK_IMPORTED_MODULE_0__fast_object_js__["a" /* default */]();

  // Store the wrapper map as object[wrapSym][key] rather than on the
  // function, so that other code can modify the same property  without
  // interfering with our wrapper logic.
  return getOrCreateStore(object)[key] = map;
}

function createStore(object) {
  return object[wrapSym] = new __WEBPACK_IMPORTED_MODULE_0__fast_object_js__["a" /* default */]();
}

function getMap(object, key) {
  const store = getStore(object);
  return store !== null && key in store ? store[key] : null;
}

function getOrCreateMap(object, key) {
  const map = getMap(object, key);
  return map === null ? createMap(object, key) : map;
}

function getOrCreateStore(object) {
  const store = getStore(object);
  return store === null ? createStore(object) : store;
}

function getStore(object) {
  return Object(__WEBPACK_IMPORTED_MODULE_1__util_has_js__["a" /* default */])(object, wrapSym) ? object[wrapSym] : null;
}

Object.setPrototypeOf(Wrapper.prototype, null);

/* harmony default export */ __webpack_exports__["a"] = (Wrapper);

/***/ }),
/* 40 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__vendor_acorn_src_expression_js__ = __webpack_require__(111);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__vendor_acorn_src_location_js__ = __webpack_require__(113);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__vendor_acorn_src_lval_js__ = __webpack_require__(114);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__vendor_acorn_src_node_js__ = __webpack_require__(115);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__vendor_acorn_src_scope_js__ = __webpack_require__(116);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__vendor_acorn_src_statement_js__ = __webpack_require__(117);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__vendor_acorn_src_tokencontext_js__ = __webpack_require__(118);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__vendor_acorn_src_tokenize_js__ = __webpack_require__(119);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__vendor_acorn_src_state_js__ = __webpack_require__(6);










/* harmony default export */ __webpack_exports__["a"] = (__WEBPACK_IMPORTED_MODULE_8__vendor_acorn_src_state_js__["a" /* Parser */]);

/***/ }),
/* 41 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["b"] = isIdentifierStart;
/* harmony export (immutable) */ __webpack_exports__["a"] = isIdentifierChar;
// Reserved word lists for various dialects of the language

const reservedWords = {
  3: "abstract boolean byte char class double enum export extends final float goto implements import int interface long native package private protected public short static super synchronized throws transient volatile",
  5: "class enum extends super const export import",
  6: "enum",
  strict: "implements interface let package private protected public static yield",
  strictBind: "eval arguments"

  // And the keywords

};
/* harmony export (immutable) */ __webpack_exports__["d"] = reservedWords;
const ecma5AndLessKeywords = "break case catch continue debugger default do else finally for function if return switch throw try var while with null true false instanceof typeof void delete new in this";

const keywords = {
  5: ecma5AndLessKeywords,
  6: ecma5AndLessKeywords + " const class extends export import super"

  // ## Character categories

  // Big ugly regular expressions that match characters in the
  // whitespace, identifier, and identifier-start categories. These
  // are only applied when a character is found to actually have a
  // code point above 128.
  // Generated by `bin/generate-identifier-regex.js`.

};
/* harmony export (immutable) */ __webpack_exports__["c"] = keywords;
let nonASCIIidentifierStartChars = "\xaa\xb5\xba\xc0-\xd6\xd8-\xf6\xf8-\u02c1\u02c6-\u02d1\u02e0-\u02e4\u02ec\u02ee\u0370-\u0374\u0376\u0377\u037a-\u037d\u037f\u0386\u0388-\u038a\u038c\u038e-\u03a1\u03a3-\u03f5\u03f7-\u0481\u048a-\u052f\u0531-\u0556\u0559\u0561-\u0587\u05d0-\u05ea\u05f0-\u05f2\u0620-\u064a\u066e\u066f\u0671-\u06d3\u06d5\u06e5\u06e6\u06ee\u06ef\u06fa-\u06fc\u06ff\u0710\u0712-\u072f\u074d-\u07a5\u07b1\u07ca-\u07ea\u07f4\u07f5\u07fa\u0800-\u0815\u081a\u0824\u0828\u0840-\u0858\u08a0-\u08b4\u08b6-\u08bd\u0904-\u0939\u093d\u0950\u0958-\u0961\u0971-\u0980\u0985-\u098c\u098f\u0990\u0993-\u09a8\u09aa-\u09b0\u09b2\u09b6-\u09b9\u09bd\u09ce\u09dc\u09dd\u09df-\u09e1\u09f0\u09f1\u0a05-\u0a0a\u0a0f\u0a10\u0a13-\u0a28\u0a2a-\u0a30\u0a32\u0a33\u0a35\u0a36\u0a38\u0a39\u0a59-\u0a5c\u0a5e\u0a72-\u0a74\u0a85-\u0a8d\u0a8f-\u0a91\u0a93-\u0aa8\u0aaa-\u0ab0\u0ab2\u0ab3\u0ab5-\u0ab9\u0abd\u0ad0\u0ae0\u0ae1\u0af9\u0b05-\u0b0c\u0b0f\u0b10\u0b13-\u0b28\u0b2a-\u0b30\u0b32\u0b33\u0b35-\u0b39\u0b3d\u0b5c\u0b5d\u0b5f-\u0b61\u0b71\u0b83\u0b85-\u0b8a\u0b8e-\u0b90\u0b92-\u0b95\u0b99\u0b9a\u0b9c\u0b9e\u0b9f\u0ba3\u0ba4\u0ba8-\u0baa\u0bae-\u0bb9\u0bd0\u0c05-\u0c0c\u0c0e-\u0c10\u0c12-\u0c28\u0c2a-\u0c39\u0c3d\u0c58-\u0c5a\u0c60\u0c61\u0c80\u0c85-\u0c8c\u0c8e-\u0c90\u0c92-\u0ca8\u0caa-\u0cb3\u0cb5-\u0cb9\u0cbd\u0cde\u0ce0\u0ce1\u0cf1\u0cf2\u0d05-\u0d0c\u0d0e-\u0d10\u0d12-\u0d3a\u0d3d\u0d4e\u0d54-\u0d56\u0d5f-\u0d61\u0d7a-\u0d7f\u0d85-\u0d96\u0d9a-\u0db1\u0db3-\u0dbb\u0dbd\u0dc0-\u0dc6\u0e01-\u0e30\u0e32\u0e33\u0e40-\u0e46\u0e81\u0e82\u0e84\u0e87\u0e88\u0e8a\u0e8d\u0e94-\u0e97\u0e99-\u0e9f\u0ea1-\u0ea3\u0ea5\u0ea7\u0eaa\u0eab\u0ead-\u0eb0\u0eb2\u0eb3\u0ebd\u0ec0-\u0ec4\u0ec6\u0edc-\u0edf\u0f00\u0f40-\u0f47\u0f49-\u0f6c\u0f88-\u0f8c\u1000-\u102a\u103f\u1050-\u1055\u105a-\u105d\u1061\u1065\u1066\u106e-\u1070\u1075-\u1081\u108e\u10a0-\u10c5\u10c7\u10cd\u10d0-\u10fa\u10fc-\u1248\u124a-\u124d\u1250-\u1256\u1258\u125a-\u125d\u1260-\u1288\u128a-\u128d\u1290-\u12b0\u12b2-\u12b5\u12b8-\u12be\u12c0\u12c2-\u12c5\u12c8-\u12d6\u12d8-\u1310\u1312-\u1315\u1318-\u135a\u1380-\u138f\u13a0-\u13f5\u13f8-\u13fd\u1401-\u166c\u166f-\u167f\u1681-\u169a\u16a0-\u16ea\u16ee-\u16f8\u1700-\u170c\u170e-\u1711\u1720-\u1731\u1740-\u1751\u1760-\u176c\u176e-\u1770\u1780-\u17b3\u17d7\u17dc\u1820-\u1877\u1880-\u18a8\u18aa\u18b0-\u18f5\u1900-\u191e\u1950-\u196d\u1970-\u1974\u1980-\u19ab\u19b0-\u19c9\u1a00-\u1a16\u1a20-\u1a54\u1aa7\u1b05-\u1b33\u1b45-\u1b4b\u1b83-\u1ba0\u1bae\u1baf\u1bba-\u1be5\u1c00-\u1c23\u1c4d-\u1c4f\u1c5a-\u1c7d\u1c80-\u1c88\u1ce9-\u1cec\u1cee-\u1cf1\u1cf5\u1cf6\u1d00-\u1dbf\u1e00-\u1f15\u1f18-\u1f1d\u1f20-\u1f45\u1f48-\u1f4d\u1f50-\u1f57\u1f59\u1f5b\u1f5d\u1f5f-\u1f7d\u1f80-\u1fb4\u1fb6-\u1fbc\u1fbe\u1fc2-\u1fc4\u1fc6-\u1fcc\u1fd0-\u1fd3\u1fd6-\u1fdb\u1fe0-\u1fec\u1ff2-\u1ff4\u1ff6-\u1ffc\u2071\u207f\u2090-\u209c\u2102\u2107\u210a-\u2113\u2115\u2118-\u211d\u2124\u2126\u2128\u212a-\u2139\u213c-\u213f\u2145-\u2149\u214e\u2160-\u2188\u2c00-\u2c2e\u2c30-\u2c5e\u2c60-\u2ce4\u2ceb-\u2cee\u2cf2\u2cf3\u2d00-\u2d25\u2d27\u2d2d\u2d30-\u2d67\u2d6f\u2d80-\u2d96\u2da0-\u2da6\u2da8-\u2dae\u2db0-\u2db6\u2db8-\u2dbe\u2dc0-\u2dc6\u2dc8-\u2dce\u2dd0-\u2dd6\u2dd8-\u2dde\u3005-\u3007\u3021-\u3029\u3031-\u3035\u3038-\u303c\u3041-\u3096\u309b-\u309f\u30a1-\u30fa\u30fc-\u30ff\u3105-\u312d\u3131-\u318e\u31a0-\u31ba\u31f0-\u31ff\u3400-\u4db5\u4e00-\u9fd5\ua000-\ua48c\ua4d0-\ua4fd\ua500-\ua60c\ua610-\ua61f\ua62a\ua62b\ua640-\ua66e\ua67f-\ua69d\ua6a0-\ua6ef\ua717-\ua71f\ua722-\ua788\ua78b-\ua7ae\ua7b0-\ua7b7\ua7f7-\ua801\ua803-\ua805\ua807-\ua80a\ua80c-\ua822\ua840-\ua873\ua882-\ua8b3\ua8f2-\ua8f7\ua8fb\ua8fd\ua90a-\ua925\ua930-\ua946\ua960-\ua97c\ua984-\ua9b2\ua9cf\ua9e0-\ua9e4\ua9e6-\ua9ef\ua9fa-\ua9fe\uaa00-\uaa28\uaa40-\uaa42\uaa44-\uaa4b\uaa60-\uaa76\uaa7a\uaa7e-\uaaaf\uaab1\uaab5\uaab6\uaab9-\uaabd\uaac0\uaac2\uaadb-\uaadd\uaae0-\uaaea\uaaf2-\uaaf4\uab01-\uab06\uab09-\uab0e\uab11-\uab16\uab20-\uab26\uab28-\uab2e\uab30-\uab5a\uab5c-\uab65\uab70-\uabe2\uac00-\ud7a3\ud7b0-\ud7c6\ud7cb-\ud7fb\uf900-\ufa6d\ufa70-\ufad9\ufb00-\ufb06\ufb13-\ufb17\ufb1d\ufb1f-\ufb28\ufb2a-\ufb36\ufb38-\ufb3c\ufb3e\ufb40\ufb41\ufb43\ufb44\ufb46-\ufbb1\ufbd3-\ufd3d\ufd50-\ufd8f\ufd92-\ufdc7\ufdf0-\ufdfb\ufe70-\ufe74\ufe76-\ufefc\uff21-\uff3a\uff41-\uff5a\uff66-\uffbe\uffc2-\uffc7\uffca-\uffcf\uffd2-\uffd7\uffda-\uffdc";
let nonASCIIidentifierChars = "\u200c\u200d\xb7\u0300-\u036f\u0387\u0483-\u0487\u0591-\u05bd\u05bf\u05c1\u05c2\u05c4\u05c5\u05c7\u0610-\u061a\u064b-\u0669\u0670\u06d6-\u06dc\u06df-\u06e4\u06e7\u06e8\u06ea-\u06ed\u06f0-\u06f9\u0711\u0730-\u074a\u07a6-\u07b0\u07c0-\u07c9\u07eb-\u07f3\u0816-\u0819\u081b-\u0823\u0825-\u0827\u0829-\u082d\u0859-\u085b\u08d4-\u08e1\u08e3-\u0903\u093a-\u093c\u093e-\u094f\u0951-\u0957\u0962\u0963\u0966-\u096f\u0981-\u0983\u09bc\u09be-\u09c4\u09c7\u09c8\u09cb-\u09cd\u09d7\u09e2\u09e3\u09e6-\u09ef\u0a01-\u0a03\u0a3c\u0a3e-\u0a42\u0a47\u0a48\u0a4b-\u0a4d\u0a51\u0a66-\u0a71\u0a75\u0a81-\u0a83\u0abc\u0abe-\u0ac5\u0ac7-\u0ac9\u0acb-\u0acd\u0ae2\u0ae3\u0ae6-\u0aef\u0b01-\u0b03\u0b3c\u0b3e-\u0b44\u0b47\u0b48\u0b4b-\u0b4d\u0b56\u0b57\u0b62\u0b63\u0b66-\u0b6f\u0b82\u0bbe-\u0bc2\u0bc6-\u0bc8\u0bca-\u0bcd\u0bd7\u0be6-\u0bef\u0c00-\u0c03\u0c3e-\u0c44\u0c46-\u0c48\u0c4a-\u0c4d\u0c55\u0c56\u0c62\u0c63\u0c66-\u0c6f\u0c81-\u0c83\u0cbc\u0cbe-\u0cc4\u0cc6-\u0cc8\u0cca-\u0ccd\u0cd5\u0cd6\u0ce2\u0ce3\u0ce6-\u0cef\u0d01-\u0d03\u0d3e-\u0d44\u0d46-\u0d48\u0d4a-\u0d4d\u0d57\u0d62\u0d63\u0d66-\u0d6f\u0d82\u0d83\u0dca\u0dcf-\u0dd4\u0dd6\u0dd8-\u0ddf\u0de6-\u0def\u0df2\u0df3\u0e31\u0e34-\u0e3a\u0e47-\u0e4e\u0e50-\u0e59\u0eb1\u0eb4-\u0eb9\u0ebb\u0ebc\u0ec8-\u0ecd\u0ed0-\u0ed9\u0f18\u0f19\u0f20-\u0f29\u0f35\u0f37\u0f39\u0f3e\u0f3f\u0f71-\u0f84\u0f86\u0f87\u0f8d-\u0f97\u0f99-\u0fbc\u0fc6\u102b-\u103e\u1040-\u1049\u1056-\u1059\u105e-\u1060\u1062-\u1064\u1067-\u106d\u1071-\u1074\u1082-\u108d\u108f-\u109d\u135d-\u135f\u1369-\u1371\u1712-\u1714\u1732-\u1734\u1752\u1753\u1772\u1773\u17b4-\u17d3\u17dd\u17e0-\u17e9\u180b-\u180d\u1810-\u1819\u18a9\u1920-\u192b\u1930-\u193b\u1946-\u194f\u19d0-\u19da\u1a17-\u1a1b\u1a55-\u1a5e\u1a60-\u1a7c\u1a7f-\u1a89\u1a90-\u1a99\u1ab0-\u1abd\u1b00-\u1b04\u1b34-\u1b44\u1b50-\u1b59\u1b6b-\u1b73\u1b80-\u1b82\u1ba1-\u1bad\u1bb0-\u1bb9\u1be6-\u1bf3\u1c24-\u1c37\u1c40-\u1c49\u1c50-\u1c59\u1cd0-\u1cd2\u1cd4-\u1ce8\u1ced\u1cf2-\u1cf4\u1cf8\u1cf9\u1dc0-\u1df5\u1dfb-\u1dff\u203f\u2040\u2054\u20d0-\u20dc\u20e1\u20e5-\u20f0\u2cef-\u2cf1\u2d7f\u2de0-\u2dff\u302a-\u302f\u3099\u309a\ua620-\ua629\ua66f\ua674-\ua67d\ua69e\ua69f\ua6f0\ua6f1\ua802\ua806\ua80b\ua823-\ua827\ua880\ua881\ua8b4-\ua8c5\ua8d0-\ua8d9\ua8e0-\ua8f1\ua900-\ua909\ua926-\ua92d\ua947-\ua953\ua980-\ua983\ua9b3-\ua9c0\ua9d0-\ua9d9\ua9e5\ua9f0-\ua9f9\uaa29-\uaa36\uaa43\uaa4c\uaa4d\uaa50-\uaa59\uaa7b-\uaa7d\uaab0\uaab2-\uaab4\uaab7\uaab8\uaabe\uaabf\uaac1\uaaeb-\uaaef\uaaf5\uaaf6\uabe3-\uabea\uabec\uabed\uabf0-\uabf9\ufb1e\ufe00-\ufe0f\ufe20-\ufe2f\ufe33\ufe34\ufe4d-\ufe4f\uff10-\uff19\uff3f";

const nonASCIIidentifierStart = new RegExp("[" + nonASCIIidentifierStartChars + "]");
const nonASCIIidentifier = new RegExp("[" + nonASCIIidentifierStartChars + nonASCIIidentifierChars + "]");

nonASCIIidentifierStartChars = nonASCIIidentifierChars = null;

// These are a run-length and offset encoded representation of the
// >0xffff code points that are a valid part of identifiers. The
// offset starts at 0x10000, and each pair of numbers represents an
// offset to the next range, and then a size of the range. They were
// generated by bin/generate-identifier-regex.js

// eslint-disable-next-line comma-spacing
const astralIdentifierStartCodes = [0, 11, 2, 25, 2, 18, 2, 1, 2, 14, 3, 13, 35, 122, 70, 52, 268, 28, 4, 48, 48, 31, 17, 26, 6, 37, 11, 29, 3, 35, 5, 7, 2, 4, 43, 157, 19, 35, 5, 35, 5, 39, 9, 51, 157, 310, 10, 21, 11, 7, 153, 5, 3, 0, 2, 43, 2, 1, 4, 0, 3, 22, 11, 22, 10, 30, 66, 18, 2, 1, 11, 21, 11, 25, 71, 55, 7, 1, 65, 0, 16, 3, 2, 2, 2, 26, 45, 28, 4, 28, 36, 7, 2, 27, 28, 53, 11, 21, 11, 18, 14, 17, 111, 72, 56, 50, 14, 50, 785, 52, 76, 44, 33, 24, 27, 35, 42, 34, 4, 0, 13, 47, 15, 3, 22, 0, 2, 0, 36, 17, 2, 24, 85, 6, 2, 0, 2, 3, 2, 14, 2, 9, 8, 46, 39, 7, 3, 1, 3, 21, 2, 6, 2, 1, 2, 4, 4, 0, 19, 0, 13, 4, 159, 52, 19, 3, 54, 47, 21, 1, 2, 0, 185, 46, 42, 3, 37, 47, 21, 0, 60, 42, 86, 25, 391, 63, 32, 0, 449, 56, 264, 8, 2, 36, 18, 0, 50, 29, 881, 921, 103, 110, 18, 195, 2749, 1070, 4050, 582, 8634, 568, 8, 30, 114, 29, 19, 47, 17, 3, 32, 20, 6, 18, 881, 68, 12, 0, 67, 12, 65, 0, 32, 6124, 20, 754, 9486, 1, 3071, 106, 6, 12, 4, 8, 8, 9, 5991, 84, 2, 70, 2, 1, 3, 0, 3, 1, 3, 3, 2, 11, 2, 0, 2, 6, 2, 64, 2, 3, 3, 7, 2, 6, 2, 27, 2, 3, 2, 4, 2, 0, 4, 6, 2, 339, 3, 24, 2, 24, 2, 30, 2, 24, 2, 30, 2, 24, 2, 30, 2, 24, 2, 30, 2, 24, 2, 7, 4149, 196, 60, 67, 1213, 3, 2, 26, 2, 1, 2, 0, 3, 0, 2, 9, 2, 3, 2, 0, 2, 0, 7, 0, 5, 0, 2, 0, 2, 0, 2, 2, 2, 1, 2, 0, 3, 0, 2, 0, 2, 0, 2, 0, 2, 0, 2, 1, 2, 0, 3, 3, 2, 6, 2, 3, 2, 3, 2, 0, 2, 9, 2, 16, 6, 2, 2, 4, 2, 16, 4421, 42710, 42, 4148, 12, 221, 3, 5761, 10591, 541];

// eslint-disable-next-line comma-spacing
const astralIdentifierCodes = [509, 0, 227, 0, 150, 4, 294, 9, 1368, 2, 2, 1, 6, 3, 41, 2, 5, 0, 166, 1, 1306, 2, 54, 14, 32, 9, 16, 3, 46, 10, 54, 9, 7, 2, 37, 13, 2, 9, 52, 0, 13, 2, 49, 13, 10, 2, 4, 9, 83, 11, 7, 0, 161, 11, 6, 9, 7, 3, 57, 0, 2, 6, 3, 1, 3, 2, 10, 0, 11, 1, 3, 6, 4, 4, 193, 17, 10, 9, 87, 19, 13, 9, 214, 6, 3, 8, 28, 1, 83, 16, 16, 9, 82, 12, 9, 9, 84, 14, 5, 9, 423, 9, 838, 7, 2, 7, 17, 9, 57, 21, 2, 13, 19882, 9, 135, 4, 60, 6, 26, 9, 1016, 45, 17, 3, 19723, 1, 5319, 4, 4, 5, 9, 7, 3, 6, 31, 3, 149, 2, 1418, 49, 513, 54, 5, 49, 9, 0, 15, 0, 23, 4, 2, 14, 1361, 6, 2, 16, 3, 6, 2, 1, 2, 4, 2214, 6, 110, 6, 6, 9, 792487, 239];

// This has a complexity linear to the value of the code. The
// assumption is that looking up astral identifier characters is
// rare.
function isInAstralSet(code, set) {
  let pos = 0x10000;
  for (let i = 0; i < set.length; i += 2) {
    pos += set[i];
    if (pos > code) return false;
    pos += set[i + 1];
    if (pos >= code) return true;
  }
}

// Test whether a given character code starts an identifier.

function isIdentifierStart(code, astral) {
  if (code < 65) return code === 36;
  if (code < 91) return true;
  if (code < 97) return code === 95;
  if (code < 123) return true;
  if (code <= 0xffff) return code >= 0xaa && nonASCIIidentifierStart.test(String.fromCharCode(code));
  if (astral === false) return false;
  return isInAstralSet(code, astralIdentifierStartCodes);
}

// Test whether a given character is part of an identifier.

function isIdentifierChar(code, astral) {
  if (code < 48) return code === 36;
  if (code < 58) return true;
  if (code < 65) return false;
  if (code < 91) return true;
  if (code < 97) return code === 95;
  if (code < 123) return true;
  if (code <= 0xffff) return code >= 0xaa && nonASCIIidentifier.test(String.fromCharCode(code));
  if (astral === false) return false;
  return isInAstralSet(code, astralIdentifierStartCodes) || isInAstralSet(code, astralIdentifierCodes);
}

/***/ }),
/* 42 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__util_create_options_js__ = __webpack_require__(2);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__util_is_object_js__ = __webpack_require__(19);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__util_keys_js__ = __webpack_require__(17);
// Based on a similar API provided by ast-types.
// Copyright Ben Newman. Released under MIT license:
// https://github.com/benjamn/ast-types/blob/master/lib/path-visitor.js





const childNamesMap = new WeakMap();

const childrenToVisit = Object(__WEBPACK_IMPORTED_MODULE_0__util_create_options_js__["a" /* default */])({
  alternate: true,
  argument: true,
  arguments: true,
  block: true,
  body: true,
  callee: true,
  cases: true,
  consequent: true,
  declaration: true,
  declarations: true,
  elements: true,
  expression: true,
  init: true,
  left: true,
  object: true,
  right: true,
  value: true
});

class Visitor {
  visit(path) {
    this.reset.apply(this, arguments);
    this.visitWithoutReset(path);
  }

  visitWithoutReset(path) {
    const value = path.getValue();

    if (!Object(__WEBPACK_IMPORTED_MODULE_1__util_is_object_js__["a" /* default */])(value)) {
      return;
    }

    if (Array.isArray(value)) {
      path.each(this, "visitWithoutReset");
      return;
    }

    // The method must call this.visitChildren(path) to continue traversing.
    let methodName = "visit" + value.type;

    if (typeof this[methodName] !== "function") {
      methodName = "visitChildren";
    }

    this[methodName](path);
  }

  visitChildren(path) {
    const value = path.getValue();
    const names = getChildNames(value);

    for (let _i = 0; _i < names.length; _i++) {
      const name = names[_i];
      path.call(this, "visitWithoutReset", name);
    }
  }
}

function getChildNames(value) {
  let childNames = childNamesMap.get(value);

  if (childNames) {
    return childNames;
  }

  const names = Object(__WEBPACK_IMPORTED_MODULE_2__util_keys_js__["a" /* default */])(value);
  childNames = [];

  for (let _i2 = 0; _i2 < names.length; _i2++) {
    const name = names[_i2];
    if (name in childrenToVisit && Object(__WEBPACK_IMPORTED_MODULE_1__util_is_object_js__["a" /* default */])(value[name])) {
      childNames.push(name);
    }
  }

  childNamesMap.set(value, childNames);
  return childNames;
}

Object.setPrototypeOf(Visitor.prototype, null);

/* harmony default export */ __webpack_exports__["a"] = (Visitor);

/***/ }),
/* 43 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__fast_object_js__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__pkg_info_js__ = __webpack_require__(15);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__util_is_path_js__ = __webpack_require__(46);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__fs_realpath_js__ = __webpack_require__(47);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_path__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4_path___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_4_path__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__module_resolve_filename_js__ = __webpack_require__(25);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__root_module_js__ = __webpack_require__(59);









const codeOfDash = "-".charCodeAt(0);

var _process = process;
const _preloadModules = _process._preloadModules,
      argv = _process.argv;

const esmPath = __non_webpack_module__.filename;
const params = argv.slice(2);

const nmIndex = params.length ? argv[1].replace(/\\/g, "/").lastIndexOf("/node_modules/") : -1;

const preloading = hasLoaderModule(_preloadModules) || __WEBPACK_IMPORTED_MODULE_6__root_module_js__["a" /* default */].id === "internal/preload" && hasLoaderModule(__WEBPACK_IMPORTED_MODULE_6__root_module_js__["a" /* default */].children);

function hasLoaderModule(modules) {
  return Array.isArray(modules) && modules.some(function (_ref) {
    let filename = _ref.filename;
    return filename === esmPath;
  });
}

function hasLoaderParam(params) {
  for (let _i = 0; _i < params.length; _i++) {
    const param = params[_i];
    if (Object(__WEBPACK_IMPORTED_MODULE_2__util_is_path_js__["a" /* default */])(param)) {
      if (Object(__WEBPACK_IMPORTED_MODULE_3__fs_realpath_js__["a" /* default */])(Object(__WEBPACK_IMPORTED_MODULE_4_path__["resolve"])(param)) === esmPath) {
        return true;
      }
    } else if (param.charCodeAt(0) !== codeOfDash && Object(__WEBPACK_IMPORTED_MODULE_5__module_resolve_filename_js__["a" /* default */])(param, __WEBPACK_IMPORTED_MODULE_6__root_module_js__["a" /* default */]) === esmPath) {
      return true;
    }
  }

  return false;
}

const env = new __WEBPACK_IMPORTED_MODULE_0__fast_object_js__["a" /* default */]();

env.preload = preloading && argv.length > 1;

env.repl = preloading && argv.length < 2 || __WEBPACK_IMPORTED_MODULE_6__root_module_js__["a" /* default */].filename === null && __WEBPACK_IMPORTED_MODULE_6__root_module_js__["a" /* default */].id === "<repl>" && __WEBPACK_IMPORTED_MODULE_6__root_module_js__["a" /* default */].loaded === false && __WEBPACK_IMPORTED_MODULE_6__root_module_js__["a" /* default */].parent === void 0 && hasLoaderModule(__WEBPACK_IMPORTED_MODULE_6__root_module_js__["a" /* default */].children);

env.cli = !env.preload && !env.repl && nmIndex !== -1 && hasLoaderParam(params) && __WEBPACK_IMPORTED_MODULE_1__pkg_info_js__["a" /* default */].get(Object(__WEBPACK_IMPORTED_MODULE_3__fs_realpath_js__["a" /* default */])(argv[1].slice(0, nmIndex + 1))) !== null;

/* harmony default export */ __webpack_exports__["a"] = (env);

/***/ }),
/* 44 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__has_js__ = __webpack_require__(7);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__is_object_like_js__ = __webpack_require__(4);



function defaults(object) {
  if (!Object(__WEBPACK_IMPORTED_MODULE_1__is_object_like_js__["a" /* default */])(object)) {
    return object;
  }

  let i = 0;
  const argCount = arguments.length;

  while (++i < argCount) {
    const source = arguments[i];

    if (!Object(__WEBPACK_IMPORTED_MODULE_1__is_object_like_js__["a" /* default */])(source)) {
      continue;
    }

    for (const key in source) {
      if (Object(__WEBPACK_IMPORTED_MODULE_0__has_js__["a" /* default */])(source, key) && (object[key] === void 0 || !Object(__WEBPACK_IMPORTED_MODULE_0__has_js__["a" /* default */])(object, key))) {
        object[key] = source[key];
      }
    }
  }

  return object;
}

/* harmony default export */ __webpack_exports__["a"] = (defaults);

/***/ }),
/* 45 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// Based on Node's `internalModule.stripBOM` method.
// Copyright Node.js contributors. Released under MIT license:
// https://github.com/nodejs/node/blob/master/lib/internal/module.js

const codeOfBOM = "\ufeff".charCodeAt(0);

function stripBOM(string) {
  if (typeof string !== "string") {
    return "";
  }

  if (string.charCodeAt(0) === codeOfBOM) {
    return string.slice(1);
  }

  return string;
}

/* harmony default export */ __webpack_exports__["a"] = (stripBOM);

/***/ }),
/* 46 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
const codeOfBackslash = "\\".charCodeAt(0);
const codeOfColon = ":".charCodeAt(0);
const codeOfDot = ".".charCodeAt(0);
const codeOfSlash = "/".charCodeAt(0);

const isWin = process.platform === "win32";

function isPath(value) {
  if (typeof value !== "string") {
    return false;
  }

  const code0 = value.charCodeAt(0);
  const code1 = value.charCodeAt(1);

  if (code0 === codeOfDot) {
    return code1 === codeOfSlash || code1 === codeOfDot && value.charCodeAt(2) === codeOfSlash;
  }

  if (isWin) {
    // Detect drive letter, i.e. `[A-Za-z]:\\`
    return code1 === codeOfColon && (code0 > 64 && code0 < 91 || code0 > 96 && code0 < 123) && value.charCodeAt(2) === codeOfBackslash;
  }

  return code0 === codeOfSlash && code1 !== codeOfSlash;
}

/* harmony default export */ __webpack_exports__["a"] = (isPath);

/***/ }),
/* 47 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_fs__ = __webpack_require__(5);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_fs___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_fs__);


function realpath(thePath) {
  try {
    return Object(__WEBPACK_IMPORTED_MODULE_0_fs__["realpathSync"])(thePath);
  } catch (e) {}
  return "";
}

/* harmony default export */ __webpack_exports__["a"] = (realpath);

/***/ }),
/* 48 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__resolve_filename_js__ = __webpack_require__(49);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__errors_js__ = __webpack_require__(21);



function resolveFilename(id, parent, isMain, options) {
  const filePath = Object(__WEBPACK_IMPORTED_MODULE_0__resolve_filename_js__["a" /* default */])(id, parent, isMain, options);

  if (filePath) {
    return filePath;
  }

  throw new __WEBPACK_IMPORTED_MODULE_1__errors_js__["a" /* default */].Error("ERR_MISSING_MODULE", id);
}

/* harmony default export */ __webpack_exports__["a"] = (resolveFilename);

/***/ }),
/* 49 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__find_path_js__ = __webpack_require__(50);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__resolve_lookup_paths_js__ = __webpack_require__(52);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__errors_js__ = __webpack_require__(21);
// Based on Node's `Module._resolveFilename` method.
// Copyright Node.js contributors. Released under MIT license:
// https://github.com/nodejs/node/blob/master/lib/module.js





function resolveFilename(id, parent, isMain, skipWarnings, skipGlobalPaths, searchExts) {
  if (typeof id !== "string") {
    throw new __WEBPACK_IMPORTED_MODULE_2__errors_js__["a" /* default */].TypeError("ERR_INVALID_ARG_TYPE", "id", "string");
  }

  const paths = Object(__WEBPACK_IMPORTED_MODULE_1__resolve_lookup_paths_js__["a" /* default */])(id, parent, skipGlobalPaths);
  return Object(__WEBPACK_IMPORTED_MODULE_0__find_path_js__["a" /* default */])(id, paths, isMain, skipWarnings, skipGlobalPaths, searchExts);
}

/* harmony default export */ __webpack_exports__["a"] = (resolveFilename);

/***/ }),
/* 50 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_path__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_path___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_path__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__binding_js__ = __webpack_require__(8);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__error_emit_deprecation_warning_js__ = __webpack_require__(85);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__util_keys_js__ = __webpack_require__(17);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__fs_read_file_js__ = __webpack_require__(23);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__fs_realpath_js__ = __webpack_require__(47);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6_semver__ = __webpack_require__(11);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6_semver___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_6_semver__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__fs_stat_js__ = __webpack_require__(24);
// Based on Node's `Module._findPath` method.
// Copyright Node.js contributors. Released under MIT license:
// https://github.com/nodejs/node/blob/master/lib/module.js











const codeOfSlash = "/".charCodeAt(0);

const parse = JSON.parse;
const preserveSymlinks = __WEBPACK_IMPORTED_MODULE_1__binding_js__["a" /* default */].config.preserveSymlinks;


const packageCache = Object.create(null);
const pathCache = Object.create(null);

const skipOutsideDot = Object(__WEBPACK_IMPORTED_MODULE_6_semver__["satisfies"])(process.version, ">=9");
let warned = false;

function _findPath(id, paths, isMain, skipWarnings, skipGlobalPaths, searchExts) {
  var _non_webpack_require = require;
  const extensions = _non_webpack_require.extensions;


  if (Object(__WEBPACK_IMPORTED_MODULE_0_path__["isAbsolute"])(id)) {
    paths = [""];
  } else if (!paths || !paths.length) {
    return "";
  }

  const cacheKey = id + "\0" + (paths.length === 1 ? paths[0] : paths.join("\0"));

  if (cacheKey in pathCache) {
    return pathCache[cacheKey];
  }

  const trailingSlash = id.length > 0 && id.charCodeAt(id.length - 1) === codeOfSlash;

  let i = -1;
  const pathsCount = paths.length;

  while (++i < pathsCount) {
    const curPath = paths[i];

    if (curPath && Object(__WEBPACK_IMPORTED_MODULE_7__fs_stat_js__["a" /* default */])(curPath) !== 1) {
      continue;
    }

    let filePath;
    const basePath = Object(__WEBPACK_IMPORTED_MODULE_0_path__["resolve"])(curPath, id);
    const rc = Object(__WEBPACK_IMPORTED_MODULE_7__fs_stat_js__["a" /* default */])(basePath);
    const isFile = rc === 0;
    const isDir = rc === 1;

    if (!trailingSlash) {
      if (isFile) {
        if (preserveSymlinks && !isMain) {
          filePath = Object(__WEBPACK_IMPORTED_MODULE_0_path__["resolve"])(basePath);
        } else {
          filePath = Object(__WEBPACK_IMPORTED_MODULE_5__fs_realpath_js__["a" /* default */])(basePath);
        }
      } else if (isDir) {
        if (searchExts === void 0) {
          searchExts = Object(__WEBPACK_IMPORTED_MODULE_3__util_keys_js__["a" /* default */])(extensions);
        }

        filePath = tryPackage(basePath, searchExts, isMain);
      }

      if (!filePath) {
        if (searchExts === void 0) {
          searchExts = Object(__WEBPACK_IMPORTED_MODULE_3__util_keys_js__["a" /* default */])(extensions);
        }

        filePath = tryExtensions(basePath, searchExts, isMain);
      }
    }

    if (isDir && !filePath) {
      if (searchExts === void 0) {
        searchExts = Object(__WEBPACK_IMPORTED_MODULE_3__util_keys_js__["a" /* default */])(extensions);
      }

      filePath = tryPackage(basePath, searchExts, isMain);
    }

    if (isDir && !filePath) {
      if (searchExts === void 0) {
        searchExts = Object(__WEBPACK_IMPORTED_MODULE_3__util_keys_js__["a" /* default */])(extensions);
      }

      filePath = tryExtensions(Object(__WEBPACK_IMPORTED_MODULE_0_path__["resolve"])(basePath, "index"), searchExts, isMain);
    }

    if (filePath) {
      // Warn once if "." resolved outside the module directory.
      if (id === "." && i > 0 && !warned && !skipGlobalPaths && !skipOutsideDot && !skipWarnings) {
        warned = true;

        Object(__WEBPACK_IMPORTED_MODULE_2__error_emit_deprecation_warning_js__["a" /* default */])("require('.') resolved outside the package directory. " + "This functionality is deprecated and will be removed soon.", "DEP0019");
      }

      return pathCache[cacheKey] = filePath;
    }
  }

  return "";
}

function readPackage(thePath) {
  if (thePath in packageCache) {
    return packageCache[thePath];
  }

  const jsonPath = Object(__WEBPACK_IMPORTED_MODULE_0_path__["resolve"])(thePath, "package.json");
  const json = Object(__WEBPACK_IMPORTED_MODULE_4__fs_read_file_js__["a" /* default */])(jsonPath, "utf8");

  if (json === null) {
    return "";
  }

  let main;

  try {
    var _parse = parse(json);

    main = _parse.main;
  } catch (e) {
    e.path = jsonPath;
    e.message = "Error parsing " + jsonPath + ": " + e.message;
    throw e;
  }

  return typeof main === "string" ? packageCache[thePath] = main : "";
}

function tryExtensions(thePath, exts, isMain) {
  let filePath = "";

  for (let _i = 0; _i < exts.length; _i++) {
    const ext = exts[_i];
    filePath = tryFile(thePath + ext, isMain);

    if (filePath) {
      return filePath;
    }
  }

  return filePath;
}

function tryFile(thePath, isMain) {
  const isFile = Object(__WEBPACK_IMPORTED_MODULE_7__fs_stat_js__["a" /* default */])(thePath) === 0;

  return preserveSymlinks && !isMain ? isFile && Object(__WEBPACK_IMPORTED_MODULE_0_path__["resolve"])(thePath) : isFile && Object(__WEBPACK_IMPORTED_MODULE_5__fs_realpath_js__["a" /* default */])(thePath);
}

function tryPackage(thePath, exts, isMain) {
  const mainPath = readPackage(thePath);

  if (!mainPath) {
    return mainPath;
  }

  const filePath = Object(__WEBPACK_IMPORTED_MODULE_0_path__["resolve"])(thePath, mainPath);

  return tryFile(filePath, isMain) || tryExtensions(filePath, exts, isMain) || tryExtensions(Object(__WEBPACK_IMPORTED_MODULE_0_path__["resolve"])(filePath, "index"), exts, isMain);
}

/* harmony default export */ __webpack_exports__["a"] = (_findPath);

/***/ }),
/* 51 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__util_is_error_js__ = __webpack_require__(20);


const errorCaptureStackTrace = Error.captureStackTrace;

function captureStackTrace(error, beforeFunc) {
  return Object(__WEBPACK_IMPORTED_MODULE_0__util_is_error_js__["a" /* default */])(error) ? errorCaptureStackTrace(error, beforeFunc) : error;
}

/* harmony default export */ __webpack_exports__["a"] = (captureStackTrace);

/***/ }),
/* 52 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_path__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_path___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_path__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__state_js__ = __webpack_require__(12);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__node_module_paths_js__ = __webpack_require__(27);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_semver__ = __webpack_require__(11);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_semver___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_semver__);
// Based on Node's `Module._resolveLookupPaths` method.
// Copyright Node.js contributors. Released under MIT license:
// https://github.com/nodejs/node/blob/master/lib/module.js







const codeOfDot = ".".charCodeAt(0);
const codeOfSlash = "/".charCodeAt(0);

const skipOutsideDot = Object(__WEBPACK_IMPORTED_MODULE_3_semver__["satisfies"])(process.version, ">=9");
const slice = Array.prototype.slice;


function _resolveLookupPaths(id, parent, skipGlobalPaths) {
  let lookOutside;

  if (skipOutsideDot) {
    lookOutside = id.charCodeAt(0) !== codeOfDot && id.charCodeAt(1) !== codeOfDot && id.charCodeAt(1) !== codeOfSlash;
  } else {
    lookOutside = id.length < 2 || id.charCodeAt(0) !== codeOfDot || id.charCodeAt(1) !== codeOfDot && id.charCodeAt(1) !== codeOfSlash;
  }

  const parentFilename = parent && parent.filename;

  if (lookOutside) {
    const parentPaths = parent && parent.paths;
    const paths = parentPaths ? slice.call(parentPaths) : [];

    // Maintain backwards compat with certain broken uses of `require(".")`
    // by putting the module's directory in front of the lookup paths.
    if (id === ".") {
      paths.unshift(parentFilename ? Object(__WEBPACK_IMPORTED_MODULE_0_path__["dirname"])(parentFilename) : Object(__WEBPACK_IMPORTED_MODULE_0_path__["resolve"])(id));
    }

    if (parentPaths && !skipGlobalPaths) {
      paths.push.apply(paths, __WEBPACK_IMPORTED_MODULE_1__state_js__["a" /* default */].globalPaths);
    }

    return paths.length ? paths : null;
  }

  // With --eval, `parent.id` is not set and `parent.filename` is `null`.
  if (!parent || !parent.id || !parentFilename) {
    // Normally, the path is taken from `realpath(__filename)`,
    // but with --eval there is no `__filename`.
    const paths = Object(__WEBPACK_IMPORTED_MODULE_2__node_module_paths_js__["a" /* default */])(".");
    paths.unshift(".");
    return paths;
  }

  return [Object(__WEBPACK_IMPORTED_MODULE_0_path__["dirname"])(parent.filename)];
}

/* harmony default export */ __webpack_exports__["a"] = (_resolveLookupPaths);

/***/ }),
/* 53 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_path__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_path___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_path__);
// Based on Node"s `Module._initPaths` method.
// Copyright Node.js contributors. Released under MIT license:
// https://github.com/nodejs/node/blob/master/lib/module.js



function initPaths() {
  const isWin = process.platform === "win32";
  const homeDir = isWin ? process.env.USERPROFILE : process.env.HOME;

  // The executable path, `$PREFIX\node.exe` on Windows or `$PREFIX/lib/node`
  // everywhere else, where `$PREFIX` is the root of the Node.js installation.
  const prefixDir = Object(__WEBPACK_IMPORTED_MODULE_0_path__["resolve"])(process.execPath, "..", isWin ? "" : "..");
  const paths = [Object(__WEBPACK_IMPORTED_MODULE_0_path__["resolve"])(prefixDir, "lib", "node")];

  if (homeDir) {
    paths.unshift(Object(__WEBPACK_IMPORTED_MODULE_0_path__["resolve"])(homeDir, ".node_libraries"));
    paths.unshift(Object(__WEBPACK_IMPORTED_MODULE_0_path__["resolve"])(homeDir, ".node_modules"));
  }

  const NODE_PATH = process.env.NODE_PATH;


  return typeof NODE_PATH === "string" ? NODE_PATH.split(__WEBPACK_IMPORTED_MODULE_0_path__["delimiter"]).filter(Boolean).concat(paths) : paths;
}

/* harmony default export */ __webpack_exports__["a"] = (initPaths);

/***/ }),
/* 54 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__to_string_js__ = __webpack_require__(55);


const codeOfDoubleQuote = '"'.charCodeAt(0);

const stringify = JSON.stringify;


const escapedDoubleQuoteRegExp = /\\"/g;

const escapeRegExpMap = {
  "'": /\\?'/g,
  "`": /\\?`/g
};

const quoteMap = {
  '"': '"',
  "'": "'",
  "`": "`",
  "back": "`",
  "double": '"',
  "single": "'"
};

function toStringLiteral(value) {
  let style = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : '"';

  const quote = quoteMap[style] || '"';
  const string = stringify(Object(__WEBPACK_IMPORTED_MODULE_0__to_string_js__["a" /* default */])(value));

  if (quote === '"' && string.charCodeAt(0) === codeOfDoubleQuote) {
    return string;
  }

  const unquoted = string.slice(1, -1).replace(escapedDoubleQuoteRegExp, '"');
  return quote + unquoted.replace(escapeRegExpMap[quote], "\\" + quote) + quote;
}

/* harmony default export */ __webpack_exports__["a"] = (toStringLiteral);

/***/ }),
/* 55 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
function toString(value) {
  if (typeof value === "string") {
    return value;
  }
  return value == null ? "" : String(value);
}

/* harmony default export */ __webpack_exports__["a"] = (toString);

/***/ }),
/* 56 */
/***/ (function(module, exports) {

module.exports = require("vm");

/***/ }),
/* 57 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
const codeOfPound = "#".charCodeAt(0);

const shebangRegExp = /^#!.*/;

function stripShebang(string) {
  if (typeof string !== "string") {
    return "";
  }

  if (string.charCodeAt(0) === codeOfPound) {
    return string.replace(shebangRegExp, "");
  }

  return string;
}

/* harmony default export */ __webpack_exports__["a"] = (stripShebang);

/***/ }),
/* 58 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// Based on Node's `NativeModule.wrapper` method.
// Copyright Node.js contributors. Released under MIT license:
// https://github.com/nodejs/node/blob/master/lib/internal/bootstrap_node.js

const wrapper = ["(function(exports,require,module,__filename,__dirname){", "\n})"];

/* harmony default export */ __webpack_exports__["a"] = (wrapper);

/***/ }),
/* 59 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
let rootModule = __non_webpack_module__;

while (rootModule.parent != null) {
  rootModule = rootModule.parent;
}

/* harmony default export */ __webpack_exports__["a"] = (rootModule);

/***/ }),
/* 60 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__has_js__ = __webpack_require__(7);


const lookupGetter = Object.prototype.__lookupGetter__;

function getGetter(object, key) {
  return Object(__WEBPACK_IMPORTED_MODULE_0__has_js__["a" /* default */])(object, key) ? lookupGetter.call(object, key) : void 0;
}

/* harmony default export */ __webpack_exports__["a"] = (getGetter);

/***/ }),
/* 61 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
const globalDecodeURIComponent = global.decodeURIComponent;

function decodeURIComponent(string) {
  return typeof string === "string" ? globalDecodeURIComponent(string) : "";
}

/* harmony default export */ __webpack_exports__["a"] = (decodeURIComponent);

/***/ }),
/* 62 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
const API = {
  posix: {
    encodedSlashRegExp: /%2f/i
  },
  win32: {
    encodedSlashRegExp: /%5c|%2f/i
  }
};

function encodedSlash(string) {
  let mode = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : "posix";
  const encodedSlashRegExp = API[mode].encodedSlashRegExp;

  return typeof string === "string" && encodedSlashRegExp.test(string);
}

/* harmony default export */ __webpack_exports__["a"] = (encodedSlash);

/***/ }),
/* 63 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_url__ = __webpack_require__(95);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_url___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_url__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__fast_object_js__ = __webpack_require__(1);




const parseCache = new __WEBPACK_IMPORTED_MODULE_1__fast_object_js__["a" /* default */]();

function parseURL(url) {
  if (url instanceof __WEBPACK_IMPORTED_MODULE_0_url__["Url"]) {
    return url;
  }

  if (url in parseCache) {
    return parseCache[url];
  }

  return parseCache[url] = Object(__WEBPACK_IMPORTED_MODULE_0_url__["parse"])(url);
}

/* harmony default export */ __webpack_exports__["a"] = (parseURL);

/***/ }),
/* 64 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_path__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_path___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_path__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__entry_js__ = __webpack_require__(65);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__util_assign_js__ = __webpack_require__(26);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__builtin_entries_js__ = __webpack_require__(103);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__util_get_source_type_js__ = __webpack_require__(66);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__module_cjs_load_js__ = __webpack_require__(104);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__module_esm_load_js__ = __webpack_require__(37);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__module_make_require_function_js__ = __webpack_require__(35);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__module_state_js__ = __webpack_require__(12);












class Runtime {
  static enable(mod, exported, options) {
    const object = mod.exports;
    const entry = __WEBPACK_IMPORTED_MODULE_1__entry_js__["a" /* default */].get(mod, exported, options);

    object.entry = entry;
    object.module = mod;
    object.options = entry.options;

    object.d = object.default = Rp.default;
    object.e = object.export = Rp.export;
    object.i = object.import = Rp.import;
    object.n = object.nsSetter = Rp.nsSetter;
    object.r = object.run = Rp.run;
    object.u = object.update = Rp.update;
    object.w = object.watch = Rp.watch;
  }

  // Register a getter function that always returns the given value.
  default(value) {
    return this.export([["default", function () {
      return value;
    }]]);
  }

  // Register getter functions for local variables in the scope of an export
  // statement. Pass true as the second argument to indicate that the getter
  // functions always return the same values.
  export(getterPairs) {
    this.entry.addGetters(getterPairs);
  }

  import(id) {
    var _this = this;

    return new Promise(function (resolve, reject) {
      setImmediate(function () {
        try {
          _this.watch(id, [["*", resolve]]);
        } catch (e) {
          reject(e);
        }
      });
    });
  }

  nsSetter() {
    var _this2 = this;

    return function (childNamespace, childEntry) {
      return _this2.entry.addGettersFrom(childEntry);
    };
  }

  run(moduleWrapper) {
    const runner = moduleWrapper.length ? runCJS : runESM;
    runner(this, moduleWrapper);
  }

  // Platform-specific code should find a way to call this method whenever
  // the module system is about to return `module.exports` from `require`.
  // This might happen more than once per module, in case of dependency cycles,
  // so we want `entry.update()` to run each time.
  update(valueToPassThrough) {
    this.entry.update();

    // Returns the `valueToPassThrough` parameter to allow the value of the
    // original expression to pass through. For example,
    //
    //   export let a = 1
    //   console.log(a += 3)
    //
    // becomes
    //
    //   runtime.export("a", () => a)
    //   let a = 1
    //   console.log(runtime.update(a += 3))
    //
    // This ensures `entry.update()` runs immediately after the assignment,
    // and does not interfere with the larger computation.
    return valueToPassThrough;
  }

  watch(id, setterPairs) {
    const entry = this.entry,
          mod = this.module,
          options = this.options;


    __WEBPACK_IMPORTED_MODULE_8__module_state_js__["a" /* default */].requireDepth += 1;

    try {
      const child = importModule(id, mod, __WEBPACK_IMPORTED_MODULE_6__module_esm_load_js__["a" /* default */], options);
      const childEntry = __WEBPACK_IMPORTED_MODULE_1__entry_js__["a" /* default */].get(child);

      entry.children[child.id] = childEntry;

      if (setterPairs) {
        childEntry.addSetters(setterPairs, entry).update();
      }
    } finally {
      __WEBPACK_IMPORTED_MODULE_8__module_state_js__["a" /* default */].requireDepth -= 1;
    }
  }
}

function importModule(id, parent, loader, options) {
  if (id in __WEBPACK_IMPORTED_MODULE_3__builtin_entries_js__["a" /* default */]) {
    return __WEBPACK_IMPORTED_MODULE_3__builtin_entries_js__["a" /* default */][id];
  }

  const child = loader(id, parent, false, options);

  if (Object(__WEBPACK_IMPORTED_MODULE_4__util_get_source_type_js__["a" /* default */])(child.exports) === "module") {
    if (Object(__WEBPACK_IMPORTED_MODULE_0_path__["extname"])(child.filename) !== ".mjs") {
      delete require.cache[child.id];
    }
  } else {
    delete __WEBPACK_IMPORTED_MODULE_8__module_state_js__["a" /* default */].cache[child.id];
  }

  return child;
}

function runCJS(runtime, moduleWrapper) {
  const entry = runtime.entry,
        mod = runtime.module,
        options = runtime.options;
  const filename = mod.filename;

  const exported = mod.exports = entry.exports;
  const loader = options.cjs ? __WEBPACK_IMPORTED_MODULE_6__module_esm_load_js__["a" /* default */] : __WEBPACK_IMPORTED_MODULE_5__module_cjs_load_js__["a" /* default */];
  const requirer = function (id) {
    return importModule(id, mod, loader, options).exports;
  };
  const req = Object(__WEBPACK_IMPORTED_MODULE_7__module_make_require_function_js__["a" /* default */])(mod, requirer);

  moduleWrapper.call(exported, exported, req, mod, filename, Object(__WEBPACK_IMPORTED_MODULE_0_path__["dirname"])(filename));
  mod.loaded = true;

  entry.merge(__WEBPACK_IMPORTED_MODULE_1__entry_js__["a" /* default */].get(mod, mod.exports, options));
  entry.exports = mod.exports;
  entry.sourceType = Object(__WEBPACK_IMPORTED_MODULE_4__util_get_source_type_js__["a" /* default */])(entry.exports);

  __WEBPACK_IMPORTED_MODULE_1__entry_js__["a" /* default */].set(mod.exports, entry);
  entry.update().loaded();
}

function runESM(runtime, moduleWrapper) {
  const entry = runtime.entry,
        mod = runtime.module,
        options = runtime.options;

  const exported = mod.exports = entry.exports;

  moduleWrapper.call(options.cjs ? exported : void 0);
  mod.loaded = true;

  entry.update().loaded();
  Object(__WEBPACK_IMPORTED_MODULE_2__util_assign_js__["a" /* default */])(exported, entry._namespace);
}

const Rp = Object.setPrototypeOf(Runtime.prototype, null);

Rp.d = Rp.default;
Rp.e = Rp.export;
Rp.i = Rp.import;
Rp.n = Rp.nsSetter;
Rp.r = Rp.run;
Rp.u = Rp.update;
Rp.w = Rp.watch;

/* harmony default export */ __webpack_exports__["a"] = (Runtime);

/***/ }),
/* 65 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__util_assign_property_js__ = __webpack_require__(99);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__util_create_options_js__ = __webpack_require__(2);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__util_get_module_name_js__ = __webpack_require__(101);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__util_get_source_type_js__ = __webpack_require__(66);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__util_is_object_like_js__ = __webpack_require__(4);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__util_keys_js__ = __webpack_require__(17);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__util_keys_all_js__ = __webpack_require__(102);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__util_set_getter_js__ = __webpack_require__(9);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__util_set_property_js__ = __webpack_require__(10);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__util_set_setter_js__ = __webpack_require__(16);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__util_to_string_literal_js__ = __webpack_require__(54);












const GETTER_ERROR = {};
const entryMap = new WeakMap();
const sort = Array.prototype.sort;

const useToStringTag = typeof Symbol.toStringTag === "symbol";

const toStringTagDescriptor = {
  configurable: false,
  enumerable: false,
  value: "Module",
  writable: false
};

class Entry {
  constructor(mod, exported, options) {
    /* eslint-disable lines-around-comment */
    // A boolean indicating whether the module namespace has changed.
    this._changed = true;
    // A number indicating the loading state of the module.
    this._loaded = 0;
    // The raw namespace object.
    this._namespace = Object.create(null);
    // The child entries of the module.
    this.children = Object.create(null);
    // The namespace object CJS importers receive.
    this.cjsNamespace = this._namespace;
    // The namespace object ESM importers receive.
    this.esmNamespace = this._namespace;
    // The `module.exports` of the module.
    this.exports = exported;
    // Getters for local variables exported from the module.
    this.getters = Object.create(null);
    // The id of the module.
    this.id = mod.id;
    // The module this entry is managing.
    this.module = mod;
    // The package options for this entry.
    this.options = Object(__WEBPACK_IMPORTED_MODULE_1__util_create_options_js__["a" /* default */])(options);
    // Setters for assigning to local variables in parent modules.
    this.setters = Object.create(null);
    // Set the default source type.
    this.sourceType = Object(__WEBPACK_IMPORTED_MODULE_3__util_get_source_type_js__["a" /* default */])(exported);
    /* eslint-enable lines-around-comment */
  }

  static get(mod, exported, options) {
    if (arguments.length === 1) {
      exported = mod.exports;
    }

    let entry;
    const useExports = Object(__WEBPACK_IMPORTED_MODULE_4__util_is_object_like_js__["a" /* default */])(exported);

    if (useExports) {
      entry = entryMap.get(exported) || entryMap.get(mod);
    } else {
      entry = entryMap.get(mod);
    }

    if (entry === void 0) {
      entry = new Entry(mod, exported, options);
      entryMap.set(mod, entry);

      if (useExports) {
        entryMap.set(exported, entry);
      }
    }

    return entry;
  }

  static set(key, entry) {
    if (Object(__WEBPACK_IMPORTED_MODULE_4__util_is_object_like_js__["a" /* default */])(key)) {
      entryMap.set(key, entry);
    }
  }

  addGetters(getterPairs) {
    for (let _i = 0; _i < getterPairs.length; _i++) {
      var _getterPairs$_i = getterPairs[_i];
      const name = _getterPairs$_i[0],
            getter = _getterPairs$_i[1];

      getter.owner = this.module;
      this.getters[name] = getter;
    }

    return this;
  }

  addGettersFrom(otherEntry) {
    const _namespace = this._namespace,
          getters = this.getters;
    const otherNamespace = otherEntry._namespace,
          otherGetters = otherEntry.getters;

    const isSafe = otherEntry.sourceType !== "script";

    for (const key in otherNamespace) {
      if (key === "default") {
        continue;
      }

      let getter = getters[key];
      const otherGetter = otherGetters[key];

      if (typeof getter !== "function" && typeof otherGetter === "function") {
        getter = otherGetter;
        getters[key] = getter;
      }

      if (typeof getter !== "function" || typeof otherGetter !== "function") {
        continue;
      }

      if (getter.owner.id === otherGetter.owner.id) {
        if (isSafe) {
          _namespace[key] = otherNamespace[key];
        } else {
          Object(__WEBPACK_IMPORTED_MODULE_0__util_assign_property_js__["a" /* default */])(_namespace, otherNamespace, key);
        }
      } else {
        throw new SyntaxError("Identifier '" + key + "' has already been declared");
      }
    }

    return this;
  }

  addSetters(setterPairs, parent) {
    for (let _i2 = 0; _i2 < setterPairs.length; _i2++) {
      var _setterPairs$_i = setterPairs[_i2];
      const name = _setterPairs$_i[0],
            setter = _setterPairs$_i[1];

      let setters = this.setters[name];

      if (setters === void 0) {
        setters = [];
        this.setters[name] = setters;
      }
      setter.last = Object.create(null);
      setter.parent = parent;
      setters.push(setter);
    }

    return this;
  }

  loaded() {
    var _this = this;

    if (this._loaded) {
      return this._loaded;
    }

    this._loaded = -1;

    if (!this.module.loaded) {
      return this._loaded = 0;
    }

    const children = this.children;

    const ids = Object(__WEBPACK_IMPORTED_MODULE_5__util_keys_js__["a" /* default */])(children);

    for (let _i3 = 0; _i3 < ids.length; _i3++) {
      const id = ids[_i3];
      if (!children[id].loaded()) {
        return this._loaded = 0;
      }
    }

    Object(__WEBPACK_IMPORTED_MODULE_7__util_set_getter_js__["a" /* default */])(this, "esmNamespace", function () {
      const isSafe = _this.sourceType !== "script";

      // Section 9.4.6
      // Module namespace objects have a null [[Prototype]].
      // https://tc39.github.io/ecma262/#sec-module-namespace-exotic-objects
      const namespace = Object.create(null);

      // Section 9.4.6.11
      // Step 7: Module namespace objects have sorted properties.
      // https://tc39.github.io/ecma262/#sec-modulenamespacecreate
      const raw = _this._namespace;
      const names = sort.call(Object(__WEBPACK_IMPORTED_MODULE_5__util_keys_js__["a" /* default */])(raw));

      for (let _i4 = 0; _i4 < names.length; _i4++) {
        const name = names[_i4];
        if (isSafe) {
          namespace[name] = raw[name];
        } else {
          Object(__WEBPACK_IMPORTED_MODULE_0__util_assign_property_js__["a" /* default */])(namespace, raw, name);
        }
      }

      // Section 26.3.1
      // Module namespace objects have a @@toStringTag value of "Module".
      // https://tc39.github.io/ecma262/#sec-@@tostringtag


      setNamespaceToStringTag(namespace);

      // Section 9.4.6
      // Module namespace objects are not extensible.
      // https://tc39.github.io/ecma262/#sec-module-namespace-exotic-objects
      return _this.esmNamespace = _this._namespace = Object.seal(namespace);
    });

    Object(__WEBPACK_IMPORTED_MODULE_9__util_set_setter_js__["a" /* default */])(this, "esmNamespace", function (value) {
      Object(__WEBPACK_IMPORTED_MODULE_8__util_set_property_js__["a" /* default */])(_this, "esmNamespace", { value });
    });

    Object(__WEBPACK_IMPORTED_MODULE_7__util_set_getter_js__["a" /* default */])(this, "cjsNamespace", function () {
      const namespace = Object.create(null);

      // Section 4.6
      // Step 4: Create an ESM with `{default:module.exports}` as its namespace
      // https://github.com/bmeck/node-eps/blob/rewrite-esm/002-es-modules.md#46-es-consuming-commonjs
      namespace.default = _this.exports;

      setNamespaceToStringTag(namespace);
      return _this.cjsNamespace = Object.seal(namespace);
    });

    Object(__WEBPACK_IMPORTED_MODULE_9__util_set_setter_js__["a" /* default */])(this, "cjsNamespace", function (value) {
      Object(__WEBPACK_IMPORTED_MODULE_8__util_set_property_js__["a" /* default */])(_this, "cjsNamespace", { value });
    });

    if (this.sourceType === "module") {
      validateSetters(this);
    }

    return this._loaded = 1;
  }

  merge(otherEntry) {
    if (otherEntry !== this) {
      for (const key in otherEntry) {
        Object(__WEBPACK_IMPORTED_MODULE_0__util_assign_property_js__["a" /* default */])(this, otherEntry, key);
      }
    }

    return this;
  }

  update() {
    var _this2 = this;

    // Lazily-initialized mapping of parent module identifiers to parent
    // module objects whose setters we might need to run.
    const parentsMap = Object.create(null);

    forEachSetter(this, function (setter, value) {
      parentsMap[setter.parent.id] = setter.parent;
      setter(value, _this2);
    });

    // If any of the setters updated the bindings of a parent module,
    // or updated local variables that are exported by that parent module,
    // then we must re-run any setters registered by that parent module.
    const ids = Object(__WEBPACK_IMPORTED_MODULE_5__util_keys_js__["a" /* default */])(parentsMap);

    for (let _i5 = 0; _i5 < ids.length; _i5++) {
      const id = ids[_i5];
      // What happens if `parents[parentIDs[id]] === module`, or if
      // longer cycles exist in the parent chain? Thanks to our `setter.last`
      // bookkeeping in `changed()`, the `entry.update()` broadcast will only
      // proceed as far as there are any actual changes to report.
      parentsMap[id].update();
    }

    return this;
  }
}

function assignExportsToNamespace(entry) {
  const _namespace = entry._namespace,
        exported = entry.exports,
        sourceType = entry.sourceType;

  const isSafe = sourceType !== "script";

  if (!isSafe) {
    // Hardcode "default" as `module.exports` for CommonJS scripts.
    _namespace.default = exported;
  }

  const names = isSafe ? Object(__WEBPACK_IMPORTED_MODULE_5__util_keys_js__["a" /* default */])(exported) : Object(__WEBPACK_IMPORTED_MODULE_6__util_keys_all_js__["a" /* default */])(exported);

  for (let _i6 = 0; _i6 < names.length; _i6++) {
    const name = names[_i6];
    if (isSafe) {
      _namespace[name] = exported[name];
    } else if (name !== "default") {
      Object(__WEBPACK_IMPORTED_MODULE_0__util_assign_property_js__["a" /* default */])(_namespace, exported, name);
    }
  }
}

function changed(setter, key, value) {
  if (compare(setter.last, key, value)) {
    return false;
  }

  setter.last[key] = value;
  return true;
}

function compare(object, key, value) {
  return key in object && Object.is(object[key], value);
}

// Invoke the given callback for every setter that needs to be called.
// Note: forEachSetter() does not call setters directly, only the given callback.
function forEachSetter(entry, callback) {
  entry._changed = false;
  runGetters(entry);

  const names = Object(__WEBPACK_IMPORTED_MODULE_5__util_keys_js__["a" /* default */])(entry.setters);

  for (let _i7 = 0; _i7 < names.length; _i7++) {
    const name = names[_i7];
    const setters = entry.setters[name];

    if (!setters.length) {
      continue;
    }

    for (let _i8 = 0; _i8 < setters.length; _i8++) {
      const setter = setters[_i8];
      const value = getExportByName(entry, setter, name);

      if (entry._changed || changed(setter, name, value)) {
        callback(setter, value);
      }
    }
  }

  entry._changed = false;
}

function getExportByName(entry, setter, name) {
  const options = setter.parent.options;
  const _namespace = entry._namespace,
        sourceType = entry.sourceType;


  if (name === "*") {
    if (options.cjs) {
      return entry.esmNamespace;
    }

    return sourceType === "module" ? entry.esmNamespace : entry.cjsNamespace;
  }

  if (sourceType !== "module" && name === "default" && (sourceType === "script" || !options.cjs)) {
    return entry.exports;
  }

  if (entry._loaded && !(name in _namespace) || entry.sourceType !== "module" && !options.cjs) {
    raiseMissingExport(entry, name);
  }

  return _namespace[name];
}

function raiseMissingExport(entry, name) {
  // Remove setter to unblock other imports.
  delete entry.setters[name];

  const moduleName = Object(__WEBPACK_IMPORTED_MODULE_2__util_get_module_name_js__["a" /* default */])(entry.module);
  throw new SyntaxError("Module " + Object(__WEBPACK_IMPORTED_MODULE_10__util_to_string_literal_js__["a" /* default */])(moduleName, "'") + " does not provide an export named '" + name + "'");
}

function runGetter(getter) {
  if (typeof getter === "function") {
    try {
      return getter();
    } catch (e) {}
  }

  return GETTER_ERROR;
}

function runGetters(entry) {
  if (entry.sourceType !== "module") {
    assignExportsToNamespace(entry);
    return;
  }

  const _namespace = entry._namespace;

  const names = Object(__WEBPACK_IMPORTED_MODULE_5__util_keys_js__["a" /* default */])(entry.getters);

  for (let _i9 = 0; _i9 < names.length; _i9++) {
    const name = names[_i9];
    const value = runGetter(entry.getters[name]);

    if (value !== GETTER_ERROR && !compare(_namespace, name, value)) {
      entry._changed = true;
      _namespace[name] = value;
    }
  }
}

function setNamespaceToStringTag(namespace) {
  if (useToStringTag) {
    Object(__WEBPACK_IMPORTED_MODULE_8__util_set_property_js__["a" /* default */])(namespace, Symbol.toStringTag, toStringTagDescriptor);
  }
}

function validateSetters(entry) {
  const getters = entry.getters,
        setters = entry.setters;

  const names = Object(__WEBPACK_IMPORTED_MODULE_5__util_keys_js__["a" /* default */])(setters);

  for (let _i10 = 0; _i10 < names.length; _i10++) {
    const name = names[_i10];
    if (name !== "*" && !(name in getters)) {
      raiseMissingExport(entry, name);
    }
  }
}

Object.setPrototypeOf(Entry.prototype, null);

/* harmony default export */ __webpack_exports__["a"] = (Entry);

/***/ }),
/* 66 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__has_js__ = __webpack_require__(7);


const typeSym = Symbol.for("@std/esm:sourceType");

function getSourceType(exported) {
  if (Object(__WEBPACK_IMPORTED_MODULE_0__has_js__["a" /* default */])(exported, "__esModule") && exported.__esModule === true) {
    return "module-like";
  }

  if (Object(__WEBPACK_IMPORTED_MODULE_0__has_js__["a" /* default */])(exported, typeSym) && typeof exported[typeSym] === "string") {
    return exported[typeSym];
  }

  return "script";
}

/* harmony default export */ __webpack_exports__["a"] = (getSourceType);

/***/ }),
/* 67 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__error_capture_stack_trace_js__ = __webpack_require__(51);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__error_mask_stack_trace_js__ = __webpack_require__(68);



function attempt(callback, beforeFunc, sourceCode) {
  try {
    return callback();
  } catch (e) {
    Object(__WEBPACK_IMPORTED_MODULE_0__error_capture_stack_trace_js__["a" /* default */])(e, beforeFunc);
    throw Object(__WEBPACK_IMPORTED_MODULE_1__error_mask_stack_trace_js__["a" /* default */])(e, sourceCode);
  }
}

/* harmony default export */ __webpack_exports__["a"] = (attempt);

/***/ }),
/* 68 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__decorate_stack_trace_js__ = __webpack_require__(106);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__util_is_error_js__ = __webpack_require__(20);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__util_is_parse_error_js__ = __webpack_require__(107);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__util_set_getter_js__ = __webpack_require__(9);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__util_set_property_js__ = __webpack_require__(10);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__util_set_setter_js__ = __webpack_require__(16);







const esmPath = __non_webpack_module__.filename;

const messageRegExp = /^(.+?: .+?) \((\d+):(\d+)\)$/m;
const removeArrowRegExp = /^.+\n *^$/m;
const removeLineInfoRegExp = /:1:\d+(\)?)$/gm;

function maskStackTrace(error, sourceCode) {
  if (!Object(__WEBPACK_IMPORTED_MODULE_1__util_is_error_js__["a" /* default */])(error)) {
    return error;
  }

  Object(__WEBPACK_IMPORTED_MODULE_0__decorate_stack_trace_js__["a" /* default */])(error);
  const stack = error.stack;

  // Defer any file read operations until `error.stack` is accessed. Ideally,
  // we'd wrap `error` in a proxy to defer the initial `error.stack` access.
  // However, `Error.captureStackTrace()` will throw when receiving a proxy
  // wrapped error object.
  Object(__WEBPACK_IMPORTED_MODULE_3__util_set_getter_js__["a" /* default */])(error, "stack", function () {
    return error.stack = Object(__WEBPACK_IMPORTED_MODULE_2__util_is_parse_error_js__["a" /* default */])(error) ? maskParserStack(stack, sourceCode, error.filename) : maskStack(stack);
  });

  Object(__WEBPACK_IMPORTED_MODULE_5__util_set_setter_js__["a" /* default */])(error, "stack", function (value) {
    Object(__WEBPACK_IMPORTED_MODULE_4__util_set_property_js__["a" /* default */])(error, "stack", { enumerable: false, value });
  });

  return error;
}

// Transform parser stack lines from:
// SyntaxError: <description> (<line>:<column>)
//   ...
// to:
// path/to/file.js:<line>
// <line of code, from the original source, where the error occurred>
// <column indicator arrow>
//
// SyntaxError: <description>
//   ...
function maskParserStack(stack, sourceCode, filePath) {
  stack = scrubStack(stack);
  const parts = messageRegExp.exec(stack);

  if (parts === null) {
    // Exit early if already formatted.
    return stack;
  }

  const desc = parts[1];
  const lineNum = +parts[2];
  const column = +parts[3];
  const spliceArgs = [0, 1];

  if (typeof filePath === "string") {
    spliceArgs.push(filePath + ":" + lineNum);
  }

  if (typeof sourceCode === "string") {
    spliceArgs.push(sourceCode.split("\n")[lineNum - 1] || "", " ".repeat(column) + "^", "");
  }

  spliceArgs.push(desc);

  const stackLines = stack.split("\n");
  stackLines.splice.apply(stackLines, spliceArgs);
  return stackLines.join("\n");
}

function maskStack(stack) {
  stack = scrubStack(stack);
  return stack.includes("\u200d") ? removeArrow(stack) : stack;
}

function removeArrow(stack) {
  return stack.replace(removeArrowRegExp, "");
}

function scrubStack(stack) {
  return stack.split("\n").filter(function (line) {
    return !line.includes(esmPath);
  }).join("\n").replace(removeLineInfoRegExp, "$1");
}

/* harmony default export */ __webpack_exports__["a"] = (maskStackTrace);

/***/ }),
/* 69 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_path__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_path___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_path__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__compiler_js__ = __webpack_require__(108);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__util_create_options_js__ = __webpack_require__(2);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__fs_gzip_js__ = __webpack_require__(131);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__util_keys_js__ = __webpack_require__(17);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__fs_remove_file_js__ = __webpack_require__(139);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__fs_write_file_defer_js__ = __webpack_require__(140);









class Compiler {
  static compile(code, options) {
    options = Object(__WEBPACK_IMPORTED_MODULE_2__util_create_options_js__["a" /* default */])(options);
    return typeof options.filePath === "string" ? compileWithFilename(code, options) : compileAndCache(code, options);
  }
}

function compileWithFilename(code, options) {
  try {
    return compileAndWrite(code, options);
  } catch (e) {
    e.filename = options.filePath;
    throw e;
  }
}

function compileAndCache(code, options) {
  const result = __WEBPACK_IMPORTED_MODULE_1__compiler_js__["a" /* default */].compile(code, toCompileOptions(options));
  options.pkgInfo.cache[options.cacheFileName] = result;
  return result;
}

function compileAndWrite(code, options) {
  const result = compileAndCache(code, options);
  const cachePath = options.cachePath;
  const cacheFileName = options.cacheFileName;
  const cacheFilePath = Object(__WEBPACK_IMPORTED_MODULE_0_path__["join"])(cachePath, cacheFileName);
  const isGzipped = Object(__WEBPACK_IMPORTED_MODULE_0_path__["extname"])(cacheFilePath) === ".gz";

  let output = result.code;

  if (result.type === "script") {
    output = '"use script";' + output;
  }

  const content = function () {
    return isGzipped ? Object(__WEBPACK_IMPORTED_MODULE_3__fs_gzip_js__["a" /* default */])(output) : output;
  };
  const encoding = isGzipped ? null : "utf8";
  var _options$pkgInfo = options.pkgInfo;
  const cache = _options$pkgInfo.cache,
        scopePath = _options$pkgInfo.dirPath;

  const writeOptions = { encoding, scopePath };

  Object(__WEBPACK_IMPORTED_MODULE_6__fs_write_file_defer_js__["a" /* default */])(cacheFilePath, content, writeOptions, function (success) {
    if (success) {
      removeExpired(cache, cachePath, cacheFileName);
    }
  });

  return result;
}

function removeExpired(cache, cachePath, cacheFileName) {
  const shortname = cacheFileName.slice(0, 8);
  Object(__WEBPACK_IMPORTED_MODULE_4__util_keys_js__["a" /* default */])(cache).forEach(function (key) {
    if (key !== cacheFileName && key.startsWith(shortname)) {
      Object(__WEBPACK_IMPORTED_MODULE_5__fs_remove_file_js__["a" /* default */])(Object(__WEBPACK_IMPORTED_MODULE_0_path__["join"])(cachePath, key));
    }
  });
}

function toCompileOptions(options) {
  return {
    cjs: options.pkgInfo.options.cjs,
    ext: false,
    hint: options.hint,
    runtimeAlias: options.runtimeAlias,
    type: options.type,
    var: options.var
  };
}

Object.setPrototypeOf(Compiler.prototype, null);

/* harmony default export */ __webpack_exports__["a"] = (Compiler);

/***/ }),
/* 70 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = DestructuringErrors;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__tokentype__ = __webpack_require__(3);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__state__ = __webpack_require__(6);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__whitespace__ = __webpack_require__(13);




const pp = __WEBPACK_IMPORTED_MODULE_1__state__["a" /* Parser */].prototype;

// ## Parser utilities

const literal = /^(?:'((?:\\.|[^'])*?)'|"((?:\\.|[^"])*?)"|;)/;
pp.strictDirective = function (start) {
  for (;;) {
    __WEBPACK_IMPORTED_MODULE_2__whitespace__["e" /* skipWhiteSpace */].lastIndex = start;
    start += __WEBPACK_IMPORTED_MODULE_2__whitespace__["e" /* skipWhiteSpace */].exec(this.input)[0].length;
    let match = literal.exec(this.input.slice(start));
    if (!match) return false;
    if ((match[1] || match[2]) == "use strict") return true;
    start += match[0].length;
  }
};

// Predicate that tests whether the next token is of the given
// type, and if yes, consumes it as a side effect.

pp.eat = function (type) {
  if (this.type === type) {
    this.next();
    return true;
  } else {
    return false;
  }
};

// Tests whether parsed token is a contextual keyword.

pp.isContextual = function (name) {
  return this.type === __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].name && this.value === name;
};

// Consumes contextual keyword if possible.

pp.eatContextual = function (name) {
  return this.value === name && this.eat(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].name);
};

// Asserts that following token is given contextual keyword.

pp.expectContextual = function (name) {
  if (!this.eatContextual(name)) this.unexpected();
};

// Test whether a semicolon can be inserted at the current position.

pp.canInsertSemicolon = function () {
  return this.type === __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].eof || this.type === __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].braceR || __WEBPACK_IMPORTED_MODULE_2__whitespace__["b" /* lineBreak */].test(this.input.slice(this.lastTokEnd, this.start));
};

pp.insertSemicolon = function () {
  if (this.canInsertSemicolon()) {
    if (this.options.onInsertedSemicolon) this.options.onInsertedSemicolon(this.lastTokEnd, this.lastTokEndLoc);
    return true;
  }
};

// Consume a semicolon, or, failing that, see if we are allowed to
// pretend that there is a semicolon at this position.

pp.semicolon = function () {
  if (!this.eat(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].semi) && !this.insertSemicolon()) this.unexpected();
};

pp.afterTrailingComma = function (tokType, notNext) {
  if (this.type == tokType) {
    if (this.options.onTrailingComma) this.options.onTrailingComma(this.lastTokStart, this.lastTokStartLoc);
    if (!notNext) this.next();
    return true;
  }
};

// Expect a token of a given type. If found, consume it, otherwise,
// raise an unexpected token error.

pp.expect = function (type) {
  this.eat(type) || this.unexpected();
};

// Raise an unexpected token error.

pp.unexpected = function (pos) {
  this.raise(pos != null ? pos : this.start, "Unexpected token");
};

function DestructuringErrors() {
  this.shorthandAssign = this.trailingComma = this.parenthesizedAssign = this.parenthesizedBind = -1;
}

pp.checkPatternErrors = function (refDestructuringErrors, isAssign) {
  if (!refDestructuringErrors) return;
  if (refDestructuringErrors.trailingComma > -1) this.raiseRecoverable(refDestructuringErrors.trailingComma, "Comma is not permitted after the rest element");
  let parens = isAssign ? refDestructuringErrors.parenthesizedAssign : refDestructuringErrors.parenthesizedBind;
  if (parens > -1) this.raiseRecoverable(parens, "Parenthesized pattern");
};

pp.checkExpressionErrors = function (refDestructuringErrors, andThrow) {
  let pos = refDestructuringErrors ? refDestructuringErrors.shorthandAssign : -1;
  if (!andThrow) return pos >= 0;
  if (pos > -1) this.raise(pos, "Shorthand property assignments are valid only in destructuring patterns");
};

pp.checkYieldAwaitInDefaultParams = function () {
  if (this.yieldPos && (!this.awaitPos || this.yieldPos < this.awaitPos)) this.raise(this.yieldPos, "Yield expression cannot be a default value");
  if (this.awaitPos) this.raise(this.awaitPos, "Await expression cannot be a default value");
};

pp.isSimpleAssignTarget = function (expr) {
  if (expr.type === "ParenthesizedExpression") return this.isSimpleAssignTarget(expr.expression);
  return expr.type === "Identifier" || expr.type === "MemberExpression";
};

/***/ }),
/* 71 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__acorn_parser_js__ = __webpack_require__(40);


const acornParser = new __WEBPACK_IMPORTED_MODULE_0__acorn_parser_js__["a" /* default */]();

function lookahead(parser) {
  acornParser.input = parser.input;
  acornParser.pos = parser.pos;
  acornParser.nextToken();
  return acornParser;
}

/* harmony default export */ __webpack_exports__["a"] = (lookahead);

/***/ }),
/* 72 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
function getNamesFromPattern(pattern) {
  let i = -1;
  const names = [];
  const queue = [pattern];

  while (++i < queue.length) {
    const pattern = queue[i];
    if (pattern === null) {
      // The ArrayPattern .elements array can contain null to indicate that
      // the position is a hole.
      continue;
    }

    // Cases are ordered from most to least likely to encounter.
    switch (pattern.type) {
      case "Identifier":
        names.push(pattern.name);
        break;
      case "Property":
      case "ObjectProperty":
        queue.push(pattern.value);
        break;
      case "AssignmentPattern":
        queue.push(pattern.left);
        break;
      case "ObjectPattern":
        queue.push.apply(queue, pattern.properties);
        break;
      case "ArrayPattern":
        queue.push.apply(queue, pattern.elements);
        break;
      case "RestElement":
        queue.push(pattern.argument);
        break;
    }
  }

  return names;
}

/* harmony default export */ __webpack_exports__["a"] = (getNamesFromPattern);

/***/ }),
/* 73 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// Based on Acorn's Parser.prototype.strictDirective parser utility.
// Copyright Marijn Haverbeke. Released under MIT license:
// https://github.com/ternjs/acorn/blob/5.1.1/src/parseutil.js#L9-L19

const literalRegExp = /^(?:'((?:\\.|[^'])*?)'|"((?:\\.|[^"])*?)"|;)/;
const skipWhiteSpaceRegExp = /(?:\s|\/\/.*|\/\*[^]*?\*\/)*/g;

function hasPragma(code, pragma, pos) {
  if (pos == null) {
    pos = 0;
  }

  while (true) {
    skipWhiteSpaceRegExp.lastIndex = pos;
    pos += skipWhiteSpaceRegExp.exec(code)[0].length;

    const match = literalRegExp.exec(code.slice(pos));

    if (match === null) {
      return false;
    }

    if ((match[1] || match[2]) === pragma) {
      return true;
    }

    pos += match[0].length;
  }
}

/* harmony default export */ __webpack_exports__["a"] = (hasPragma);

/***/ }),
/* 74 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";


const assert = __webpack_require__(132)
const Buffer = __webpack_require__(133).Buffer
const binding = process.binding('zlib')

const constants = exports.constants = __webpack_require__(134)
const MiniPass = __webpack_require__(135)

// translation table for return codes.
const codes = new Map([
  [constants.Z_OK, 'Z_OK'],
  [constants.Z_STREAM_END, 'Z_STREAM_END'],
  [constants.Z_NEED_DICT, 'Z_NEED_DICT'],
  [constants.Z_ERRNO, 'Z_ERRNO'],
  [constants.Z_STREAM_ERROR, 'Z_STREAM_ERROR'],
  [constants.Z_DATA_ERROR, 'Z_DATA_ERROR'],
  [constants.Z_MEM_ERROR, 'Z_MEM_ERROR'],
  [constants.Z_BUF_ERROR, 'Z_BUF_ERROR'],
  [constants.Z_VERSION_ERROR, 'Z_VERSION_ERROR']
])

const validFlushFlags = new Set([
  constants.Z_NO_FLUSH,
  constants.Z_PARTIAL_FLUSH,
  constants.Z_SYNC_FLUSH,
  constants.Z_FULL_FLUSH,
  constants.Z_FINISH,
  constants.Z_BLOCK
])

const strategies = new Set([
  constants.Z_FILTERED,
  constants.Z_HUFFMAN_ONLY,
  constants.Z_RLE,
  constants.Z_FIXED,
  constants.Z_DEFAULT_STRATEGY
])

// the Zlib class they all inherit from
// This thing manages the queue of requests, and returns
// true or false if there is anything in the queue when
// you call the .write() method.
const _opts = Symbol('opts')
const _chunkSize = Symbol('chunkSize')
const _flushFlag = Symbol('flushFlag')
const _finishFlush = Symbol('finishFlush')
const _handle = Symbol('handle')
const _hadError = Symbol('hadError')
const _buffer = Symbol('buffer')
const _offset = Symbol('offset')
const _level = Symbol('level')
const _strategy = Symbol('strategy')
const _ended = Symbol('ended')

class Zlib extends MiniPass {
  constructor (opts, mode) {
    super(opts)
    this[_ended] = false
    this[_opts] = opts = opts || {}
    this[_chunkSize] = opts.chunkSize || constants.Z_DEFAULT_CHUNK
    if (opts.flush && !validFlushFlags.has(opts.flush)) {
      throw new Error('Invalid flush flag: ' + opts.flush)
    }
    if (opts.finishFlush && !validFlushFlags.has(opts.finishFlush)) {
      throw new Error('Invalid flush flag: ' + opts.finishFlush)
    }

    this[_flushFlag] = opts.flush || constants.Z_NO_FLUSH
    this[_finishFlush] = typeof opts.finishFlush !== 'undefined' ?
      opts.finishFlush : constants.Z_FINISH

    if (opts.chunkSize) {
      if (opts.chunkSize < constants.Z_MIN_CHUNK) {
        throw new Error('Invalid chunk size: ' + opts.chunkSize)
      }
    }

    if (opts.windowBits) {
      if (opts.windowBits < constants.Z_MIN_WINDOWBITS ||
          opts.windowBits > constants.Z_MAX_WINDOWBITS) {
        throw new Error('Invalid windowBits: ' + opts.windowBits)
      }
    }

    if (opts.level) {
      if (opts.level < constants.Z_MIN_LEVEL ||
          opts.level > constants.Z_MAX_LEVEL) {
        throw new Error('Invalid compression level: ' + opts.level)
      }
    }

    if (opts.memLevel) {
      if (opts.memLevel < constants.Z_MIN_MEMLEVEL ||
          opts.memLevel > constants.Z_MAX_MEMLEVEL) {
        throw new Error('Invalid memLevel: ' + opts.memLevel)
      }
    }

    if (opts.strategy && !(strategies.has(opts.strategy)))
      throw new Error('Invalid strategy: ' + opts.strategy)

    if (opts.dictionary) {
      if (!(opts.dictionary instanceof Buffer)) {
        throw new Error('Invalid dictionary: it should be a Buffer instance')
      }
    }

    this[_handle] = new binding.Zlib(mode)

    this[_hadError] = false
    this[_handle].onerror = (message, errno) => {
      // there is no way to cleanly recover.
      // continuing only obscures problems.
      this.close()
      this[_hadError] = true

      const error = new Error(message)
      error.errno = errno
      error.code = codes.get(errno)
      this.emit('error', error)
    }

    const level = typeof opts.level === 'number' ? opts.level
                : constants.Z_DEFAULT_COMPRESSION

    var strategy = typeof opts.strategy === 'number' ? opts.strategy
                 : constants.Z_DEFAULT_STRATEGY

    this[_handle].init(opts.windowBits || constants.Z_DEFAULT_WINDOWBITS,
                       level,
                       opts.memLevel || constants.Z_DEFAULT_MEMLEVEL,
                       strategy,
                       opts.dictionary)

    this[_buffer] = Buffer.allocUnsafe(this[_chunkSize])
    this[_offset] = 0
    this[_level] = level
    this[_strategy] = strategy

    this.once('end', this.close)
  }

  close () {
    if (this[_handle]) {
      this[_handle].close()
      this[_handle] = null
      this.emit('close')
    }
  }

  params (level, strategy) {
    if (!this[_handle])
      throw new Error('cannot switch params when binding is closed')

    // no way to test this without also not supporting params at all
    /* istanbul ignore if */
    if (!this[_handle].params)
      throw new Error('not supported in this implementation')

    if (level < constants.Z_MIN_LEVEL ||
        level > constants.Z_MAX_LEVEL) {
      throw new RangeError('Invalid compression level: ' + level)
    }

    if (!(strategies.has(strategy)))
      throw new TypeError('Invalid strategy: ' + strategy)

    if (this[_level] !== level || this[_strategy] !== strategy) {
      this.flush(constants.Z_SYNC_FLUSH)
      assert(this[_handle], 'zlib binding closed')
      this[_handle].params(level, strategy)
      /* istanbul ignore else */
      if (!this[_hadError]) {
        this[_level] = level
        this[_strategy] = strategy
      }
    }
  }

  reset () {
    assert(this[_handle], 'zlib binding closed')
    return this[_handle].reset()
  }

  flush (kind) {
    if (kind === undefined)
      kind = constants.Z_FULL_FLUSH

    if (this.ended)
      return

    const flushFlag = this[_flushFlag]
    this[_flushFlag] = kind
    this.write(Buffer.alloc(0))
    this[_flushFlag] = flushFlag
  }

  end (chunk, encoding, cb) {
    if (chunk)
      this.write(chunk, encoding)
    this.flush(this[_finishFlush])
    this[_ended] = true
    return super.end(null, null, cb)
  }

  get ended () {
    return this[_ended]
  }

  write (chunk, encoding, cb) {
    // process the chunk using the sync process
    // then super.write() all the outputted chunks
    if (typeof encoding === 'function')
      cb = encoding, encoding = 'utf8'

    if (typeof chunk === 'string')
      chunk = new Buffer(chunk, encoding)

    let availInBefore = chunk && chunk.length
    let availOutBefore = this[_chunkSize] - this[_offset]
    let inOff = 0 // the offset of the input buffer
    const flushFlag = this[_flushFlag]
    let writeReturn = true

    assert(this[_handle], 'zlib binding closed')
    do {
      let res = this[_handle].writeSync(
        flushFlag,
        chunk, // in
        inOff, // in_off
        availInBefore, // in_len
        this[_buffer], // out
        this[_offset], //out_off
        availOutBefore // out_len
      )
      if (this[_hadError])
        break

      let availInAfter = res[0]
      let availOutAfter = res[1]

      const have = availOutBefore - availOutAfter
      assert(have >= 0, 'have should not go down')

      if (have > 0) {
        const out = this[_buffer].slice(
          this[_offset], this[_offset] + have
        )

        this[_offset] += have
        // serve some output to the consumer.
        writeReturn = super.write(out) && writeReturn
      }

      // exhausted the output buffer, or used all the input create a new one.
      if (availOutAfter === 0 || this[_offset] >= this[_chunkSize]) {
        availOutBefore = this[_chunkSize]
        this[_offset] = 0
        this[_buffer] = Buffer.allocUnsafe(this[_chunkSize])
      }

      if (availOutAfter === 0) {
        // Not actually done.  Need to reprocess.
        // Also, update the availInBefore to the availInAfter value,
        // so that if we have to hit it a third (fourth, etc.) time,
        // it'll have the correct byte counts.
        inOff += (availInBefore - availInAfter)
        availInBefore = availInAfter
        continue
      }
      break
    } while (!this[_hadError])

    if (cb)
      cb()
    return writeReturn
  }
}

// minimal 2-byte header
class Deflate extends Zlib {
  constructor (opts) {
    super(opts, constants.DEFLATE)
  }
}

class Inflate extends Zlib {
  constructor (opts) {
    super(opts, constants.INFLATE)
  }
}

// gzip - bigger header, same deflate compression
class Gzip extends Zlib {
  constructor (opts) {
    super(opts, constants.GZIP)
  }
}

class Gunzip extends Zlib {
  constructor (opts) {
    super(opts, constants.GUNZIP)
  }
}

// raw - no header
class DeflateRaw extends Zlib {
  constructor (opts) {
    super(opts, constants.DEFLATERAW)
  }
}

class InflateRaw extends Zlib {
  constructor (opts) {
    super(opts, constants.INFLATERAW)
  }
}

// auto-detect header.
class Unzip extends Zlib {
  constructor (opts) {
    super(opts, constants.UNZIP)
  }
}

exports.Deflate = Deflate
exports.Inflate = Inflate
exports.Gzip = Gzip
exports.Gunzip = Gunzip
exports.DeflateRaw = DeflateRaw
exports.InflateRaw = InflateRaw
exports.Unzip = Unzip


/***/ }),
/* 75 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

module.exports = Yallist

Yallist.Node = Node
Yallist.create = Yallist

function Yallist (list) {
  var self = this
  if (!(self instanceof Yallist)) {
    self = new Yallist()
  }

  self.tail = null
  self.head = null
  self.length = 0

  if (list && typeof list.forEach === 'function') {
    list.forEach(function (item) {
      self.push(item)
    })
  } else if (arguments.length > 0) {
    for (var i = 0, l = arguments.length; i < l; i++) {
      self.push(arguments[i])
    }
  }

  return self
}

Yallist.prototype.removeNode = function (node) {
  if (node.list !== this) {
    throw new Error('removing node which does not belong to this list')
  }

  var next = node.next
  var prev = node.prev

  if (next) {
    next.prev = prev
  }

  if (prev) {
    prev.next = next
  }

  if (node === this.head) {
    this.head = next
  }
  if (node === this.tail) {
    this.tail = prev
  }

  node.list.length--
  node.next = null
  node.prev = null
  node.list = null
}

Yallist.prototype.unshiftNode = function (node) {
  if (node === this.head) {
    return
  }

  if (node.list) {
    node.list.removeNode(node)
  }

  var head = this.head
  node.list = this
  node.next = head
  if (head) {
    head.prev = node
  }

  this.head = node
  if (!this.tail) {
    this.tail = node
  }
  this.length++
}

Yallist.prototype.pushNode = function (node) {
  if (node === this.tail) {
    return
  }

  if (node.list) {
    node.list.removeNode(node)
  }

  var tail = this.tail
  node.list = this
  node.prev = tail
  if (tail) {
    tail.next = node
  }

  this.tail = node
  if (!this.head) {
    this.head = node
  }
  this.length++
}

Yallist.prototype.push = function () {
  for (var i = 0, l = arguments.length; i < l; i++) {
    push(this, arguments[i])
  }
  return this.length
}

Yallist.prototype.unshift = function () {
  for (var i = 0, l = arguments.length; i < l; i++) {
    unshift(this, arguments[i])
  }
  return this.length
}

Yallist.prototype.pop = function () {
  if (!this.tail) {
    return undefined
  }

  var res = this.tail.value
  this.tail = this.tail.prev
  if (this.tail) {
    this.tail.next = null
  } else {
    this.head = null
  }
  this.length--
  return res
}

Yallist.prototype.shift = function () {
  if (!this.head) {
    return undefined
  }

  var res = this.head.value
  this.head = this.head.next
  if (this.head) {
    this.head.prev = null
  } else {
    this.tail = null
  }
  this.length--
  return res
}

Yallist.prototype.forEach = function (fn, thisp) {
  thisp = thisp || this
  for (var walker = this.head, i = 0; walker !== null; i++) {
    fn.call(thisp, walker.value, i, this)
    walker = walker.next
  }
}

Yallist.prototype.forEachReverse = function (fn, thisp) {
  thisp = thisp || this
  for (var walker = this.tail, i = this.length - 1; walker !== null; i--) {
    fn.call(thisp, walker.value, i, this)
    walker = walker.prev
  }
}

Yallist.prototype.get = function (n) {
  for (var i = 0, walker = this.head; walker !== null && i < n; i++) {
    // abort out of the list early if we hit a cycle
    walker = walker.next
  }
  if (i === n && walker !== null) {
    return walker.value
  }
}

Yallist.prototype.getReverse = function (n) {
  for (var i = 0, walker = this.tail; walker !== null && i < n; i++) {
    // abort out of the list early if we hit a cycle
    walker = walker.prev
  }
  if (i === n && walker !== null) {
    return walker.value
  }
}

Yallist.prototype.map = function (fn, thisp) {
  thisp = thisp || this
  var res = new Yallist()
  for (var walker = this.head; walker !== null;) {
    res.push(fn.call(thisp, walker.value, this))
    walker = walker.next
  }
  return res
}

Yallist.prototype.mapReverse = function (fn, thisp) {
  thisp = thisp || this
  var res = new Yallist()
  for (var walker = this.tail; walker !== null;) {
    res.push(fn.call(thisp, walker.value, this))
    walker = walker.prev
  }
  return res
}

Yallist.prototype.reduce = function (fn, initial) {
  var acc
  var walker = this.head
  if (arguments.length > 1) {
    acc = initial
  } else if (this.head) {
    walker = this.head.next
    acc = this.head.value
  } else {
    throw new TypeError('Reduce of empty list with no initial value')
  }

  for (var i = 0; walker !== null; i++) {
    acc = fn(acc, walker.value, i)
    walker = walker.next
  }

  return acc
}

Yallist.prototype.reduceReverse = function (fn, initial) {
  var acc
  var walker = this.tail
  if (arguments.length > 1) {
    acc = initial
  } else if (this.tail) {
    walker = this.tail.prev
    acc = this.tail.value
  } else {
    throw new TypeError('Reduce of empty list with no initial value')
  }

  for (var i = this.length - 1; walker !== null; i--) {
    acc = fn(acc, walker.value, i)
    walker = walker.prev
  }

  return acc
}

Yallist.prototype.toArray = function () {
  var arr = new Array(this.length)
  for (var i = 0, walker = this.head; walker !== null; i++) {
    arr[i] = walker.value
    walker = walker.next
  }
  return arr
}

Yallist.prototype.toArrayReverse = function () {
  var arr = new Array(this.length)
  for (var i = 0, walker = this.tail; walker !== null; i++) {
    arr[i] = walker.value
    walker = walker.prev
  }
  return arr
}

Yallist.prototype.slice = function (from, to) {
  to = to || this.length
  if (to < 0) {
    to += this.length
  }
  from = from || 0
  if (from < 0) {
    from += this.length
  }
  var ret = new Yallist()
  if (to < from || to < 0) {
    return ret
  }
  if (from < 0) {
    from = 0
  }
  if (to > this.length) {
    to = this.length
  }
  for (var i = 0, walker = this.head; walker !== null && i < from; i++) {
    walker = walker.next
  }
  for (; walker !== null && i < to; i++, walker = walker.next) {
    ret.push(walker.value)
  }
  return ret
}

Yallist.prototype.sliceReverse = function (from, to) {
  to = to || this.length
  if (to < 0) {
    to += this.length
  }
  from = from || 0
  if (from < 0) {
    from += this.length
  }
  var ret = new Yallist()
  if (to < from || to < 0) {
    return ret
  }
  if (from < 0) {
    from = 0
  }
  if (to > this.length) {
    to = this.length
  }
  for (var i = this.length, walker = this.tail; walker !== null && i > to; i--) {
    walker = walker.prev
  }
  for (; walker !== null && i > from; i--, walker = walker.prev) {
    ret.push(walker.value)
  }
  return ret
}

Yallist.prototype.reverse = function () {
  var head = this.head
  var tail = this.tail
  for (var walker = head; walker !== null; walker = walker.prev) {
    var p = walker.prev
    walker.prev = walker.next
    walker.next = p
  }
  this.head = tail
  this.tail = head
  return this
}

function push (self, item) {
  self.tail = new Node(item, self.tail, null, self)
  if (!self.head) {
    self.head = self.tail
  }
  self.length++
}

function unshift (self, item) {
  self.head = new Node(item, null, self.head, self)
  if (!self.tail) {
    self.tail = self.head
  }
  self.length++
}

function Node (value, prev, next, list) {
  if (!(this instanceof Node)) {
    return new Node(value, prev, next, list)
  }

  this.list = list
  this.value = value

  if (prev) {
    prev.next = this
    this.prev = prev
  } else {
    this.prev = null
  }

  if (next) {
    next.prev = this
    this.next = next
  } else {
    this.next = null
  }
}

try {
  // add if support or Symbol.iterator is present
  __webpack_require__(137)
} catch (er) {}


/***/ }),
/* 76 */
/***/ (function(module, exports) {

module.exports = require("zlib");

/***/ }),
/* 77 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
function streamToBuffer(stream, bufferOrString) {
  const result = [];
  stream.on("data", function (chunk) {
    return result.push(chunk);
  }).end(bufferOrString);
  return Buffer.concat(result);
}

/* harmony default export */ __webpack_exports__["a"] = (streamToBuffer);

/***/ }),
/* 78 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
function encodeId(id) {
  return id + "\u200d";
}

/* harmony default export */ __webpack_exports__["a"] = (encodeId);

/***/ }),
/* 79 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__path_extname_js__ = __webpack_require__(28);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__md5_js__ = __webpack_require__(80);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__version_js__ = __webpack_require__(34);




const stringify = JSON.stringify;


function getCacheFileName(filePath, cacheKey, pkgInfo) {
  // While MD5 is not suitable for verification of untrusted data,
  // it is great for revving files. See Sufian Rhazi's post for more details
  // https://blog.risingstack.com/automatic-cache-busting-for-your-css/.
  const pathHash = Object(__WEBPACK_IMPORTED_MODULE_1__md5_js__["a" /* default */])(filePath);
  const stateHash = Object(__WEBPACK_IMPORTED_MODULE_1__md5_js__["a" /* default */])(__WEBPACK_IMPORTED_MODULE_2__version_js__["a" /* version */] + "\0" + stringify(pkgInfo.options) + "\0" + cacheKey);

  const ext = typeof filePath === "string" ? Object(__WEBPACK_IMPORTED_MODULE_0__path_extname_js__["a" /* default */])(filePath) : ".js";
  return pathHash.slice(0, 8) + stateHash.slice(0, 8) + ext;
}

/* harmony default export */ __webpack_exports__["a"] = (getCacheFileName);

/***/ }),
/* 80 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_crypto__ = __webpack_require__(145);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_crypto___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_crypto__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__to_string_js__ = __webpack_require__(55);



function md5(value) {
  return Object(__WEBPACK_IMPORTED_MODULE_0_crypto__["createHash"])("md5").update(Object(__WEBPACK_IMPORTED_MODULE_1__to_string_js__["a" /* default */])(value)).digest("hex");
}

/* harmony default export */ __webpack_exports__["a"] = (md5);

/***/ }),
/* 81 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
Object.defineProperty(__webpack_exports__, "__esModule", { value: true });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__env_js__ = __webpack_require__(43);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__hooks_js__ = __webpack_require__(93);



if (__WEBPACK_IMPORTED_MODULE_0__env_js__["a" /* default */].cli) {
  __WEBPACK_IMPORTED_MODULE_1__hooks_js__["a" /* default */].cli();
} else if (__WEBPACK_IMPORTED_MODULE_0__env_js__["a" /* default */].repl) {
  __WEBPACK_IMPORTED_MODULE_1__hooks_js__["a" /* default */].repl();
} else if (__WEBPACK_IMPORTED_MODULE_0__env_js__["a" /* default */].preload) {
  __WEBPACK_IMPORTED_MODULE_1__hooks_js__["a" /* default */].preload();
}

/* harmony default export */ __webpack_exports__["default"] = (__WEBPACK_IMPORTED_MODULE_1__hooks_js__["a" /* default */].require);

/***/ }),
/* 82 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__read_file_js__ = __webpack_require__(23);


const parse = JSON.parse;


function readJSON(filePath) {
  const content = Object(__WEBPACK_IMPORTED_MODULE_0__read_file_js__["a" /* default */])(filePath, "utf8");
  return content === null ? content : parse(content);
}

/* harmony default export */ __webpack_exports__["a"] = (readJSON);

/***/ }),
/* 83 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__fs_stat_js__ = __webpack_require__(24);


function isFile(thePath) {
  return Object(__WEBPACK_IMPORTED_MODULE_0__fs_stat_js__["a" /* default */])(thePath) === 0;
}

/* harmony default export */ __webpack_exports__["a"] = (isFile);

/***/ }),
/* 84 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_fs__ = __webpack_require__(5);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_fs___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_fs__);


function readdir(dirPath) {
  try {
    return Object(__WEBPACK_IMPORTED_MODULE_0_fs__["readdirSync"])(dirPath);
  } catch (e) {}
  return null;
}

/* harmony default export */ __webpack_exports__["a"] = (readdir);

/***/ }),
/* 85 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__capture_stack_trace_js__ = __webpack_require__(51);


function emitDeprecationWarning(message, code) {
  if (process.noDeprecation) {
    return;
  }

  const warning = new Error(message);

  if (typeof code === "string") {
    warning.code = code;
  }

  warning.name = "DeprecationWarning";
  Object(__WEBPACK_IMPORTED_MODULE_0__capture_stack_trace_js__["a" /* default */])(warning, emitDeprecationWarning);

  if (process.throwDeprecation) {
    throw warning;
  }

  process.nextTick(function () {
    return process.emit("warning", warning);
  });
}

/* harmony default export */ __webpack_exports__["a"] = (emitDeprecationWarning);

/***/ }),
/* 86 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__fast_object_js__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__util_assign_js__ = __webpack_require__(26);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_fs__ = __webpack_require__(5);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_fs___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_fs__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__fs_read_file_js__ = __webpack_require__(23);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__util_strip_bom_js__ = __webpack_require__(45);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__path_to_namespaced_path_js__ = __webpack_require__(33);








const BuiltinModule = __non_webpack_module__.constructor;

var _process = process;
const dlopen = _process.dlopen;
const parse = JSON.parse;

const extensions = Object(__WEBPACK_IMPORTED_MODULE_1__util_assign_js__["a" /* default */])(new __WEBPACK_IMPORTED_MODULE_0__fast_object_js__["a" /* default */](), BuiltinModule._extensions);

extensions[".js"] = function (mod, filePath) {
  const content = __WEBPACK_IMPORTED_MODULE_2_fs___default.a.readFileSync(filePath, "utf8");
  mod._compile(Object(__WEBPACK_IMPORTED_MODULE_4__util_strip_bom_js__["a" /* default */])(content), filePath);
};

extensions[".json"] = function (mod, filePath) {
  const content = Object(__WEBPACK_IMPORTED_MODULE_3__fs_read_file_js__["a" /* default */])(filePath, "utf8");

  try {
    mod.exports = parse(content);
  } catch (error) {
    error.message = filePath + ": " + error.message;
    throw error;
  }
};

extensions[".node"] = function (mod, filePath) {
  return dlopen(mod, Object(__WEBPACK_IMPORTED_MODULE_5__path_to_namespaced_path_js__["a" /* default */])(filePath));
};

/* harmony default export */ __webpack_exports__["a"] = (extensions);

/***/ }),
/* 87 */
/***/ (function(module, exports) {

module.exports = require("util");

/***/ }),
/* 88 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_vm__ = __webpack_require__(56);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_vm___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_vm__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__module_js__ = __webpack_require__(22);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__binding_js__ = __webpack_require__(8);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_path__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_path___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_path__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__make_require_function_js__ = __webpack_require__(35);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__resolve_filename_js__ = __webpack_require__(25);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__util_strip_shebang_js__ = __webpack_require__(57);
// Based on Node's `Module#_compile` method.
// Copyright Node.js contributors. Released under MIT license:
// https://github.com/nodejs/node/blob/master/lib/module.js











// Lazily resolve `process.argv[1]`.
// Needed for setting the breakpoint when called with --inspect-brk.
let resolvedArgv;

const inspectorBinding = __WEBPACK_IMPORTED_MODULE_2__binding_js__["a" /* default */].inspector;
const callAndPauseOnStart = inspectorBinding.callAndPauseOnStart;


function compile(mod, content, filePath) {
  const req = Object(__WEBPACK_IMPORTED_MODULE_4__make_require_function_js__["a" /* default */])(mod);
  const wrapper = __WEBPACK_IMPORTED_MODULE_1__module_js__["a" /* default */].wrap(Object(__WEBPACK_IMPORTED_MODULE_6__util_strip_shebang_js__["a" /* default */])(content));

  const compiledWrapper = Object(__WEBPACK_IMPORTED_MODULE_0_vm__["runInThisContext"])(wrapper, {
    displayErrors: true,
    filename: filePath
  });

  let inspectorWrapper = null;

  if (process._breakFirstLine && process._eval == null) {
    if (resolvedArgv === void 0) {
      // Enter the REPL if not given a file path argument.
      resolvedArgv = process.argv[1] ? Object(__WEBPACK_IMPORTED_MODULE_5__resolve_filename_js__["a" /* default */])(process.argv[1]) : "repl";
    }

    // Set breakpoint on module start.
    if (filePath === resolvedArgv) {
      delete process._breakFirstLine;
      inspectorWrapper = callAndPauseOnStart;

      if (!inspectorWrapper) {
        const Debug = Object(__WEBPACK_IMPORTED_MODULE_0_vm__["runInDebugContext"])("Debug");
        Debug.setBreakPoint(compiledWrapper, 0, 0);
      }
    }
  }

  let result;

  if (inspectorWrapper) {
    result = inspectorWrapper.call(inspectorBinding, compiledWrapper, mod.exports, mod.exports, req, mod, filePath, Object(__WEBPACK_IMPORTED_MODULE_3_path__["dirname"])(filePath));
  } else {
    result = compiledWrapper.call(mod.exports, mod.exports, req, mod, filePath, Object(__WEBPACK_IMPORTED_MODULE_3_path__["dirname"])(filePath));
  }

  return result;
}

/* harmony default export */ __webpack_exports__["a"] = (compile);

/***/ }),
/* 89 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__find_path_js__ = __webpack_require__(50);
// Based on Node's `Module._findPath` method.
// Copyright Node.js contributors. Released under MIT license:
// https://github.com/nodejs/node/blob/master/lib/module.js



function findPath(id, paths, isMain) {
  return Object(__WEBPACK_IMPORTED_MODULE_0__find_path_js__["a" /* default */])(id, paths, isMain) || false;
}

/* harmony default export */ __webpack_exports__["a"] = (findPath);

/***/ }),
/* 90 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__load_js__ = __webpack_require__(36);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__builtin_modules_js__ = __webpack_require__(18);
// Based on Node's `Module._load` method.
// Copyright Node.js contributors. Released under MIT license:
// https://github.com/nodejs/node/blob/master/lib/module.js




function load(id, parent, isMain) {
  return id in __WEBPACK_IMPORTED_MODULE_1__builtin_modules_js__["a" /* default */] ? __WEBPACK_IMPORTED_MODULE_1__builtin_modules_js__["a" /* default */][id].exports : Object(__WEBPACK_IMPORTED_MODULE_0__load_js__["a" /* default */])(id, parent, isMain);
}

/* harmony default export */ __webpack_exports__["a"] = (load);

/***/ }),
/* 91 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__resolve_lookup_paths_js__ = __webpack_require__(52);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__builtin_modules_js__ = __webpack_require__(18);
// Based on Node's `Module._resolveLookupPaths` method.
// Copyright Node.js contributors. Released under MIT license:
// https://github.com/nodejs/node/blob/master/lib/module.js




function resolveLookupPaths(id, parent) {
  return id in __WEBPACK_IMPORTED_MODULE_1__builtin_modules_js__["a" /* default */] ? null : Object(__WEBPACK_IMPORTED_MODULE_0__resolve_lookup_paths_js__["a" /* default */])(id, parent);
}

/* harmony default export */ __webpack_exports__["a"] = (resolveLookupPaths);

/***/ }),
/* 92 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__wrapper_js__ = __webpack_require__(58);
// Based on Node's `NativeModule.wrap` method.
// Copyright Node.js contributors. Released under MIT license:
// https://github.com/nodejs/node/blob/master/lib/internal/bootstrap_node.js



function wrap(script) {
  return __WEBPACK_IMPORTED_MODULE_0__wrapper_js__["a" /* default */][0] + script + __WEBPACK_IMPORTED_MODULE_0__wrapper_js__["a" /* default */][1];
}

/* harmony default export */ __webpack_exports__["a"] = (wrap);

/***/ }),
/* 93 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__fast_object_js__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__module_js__ = __webpack_require__(22);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__pkg_info_js__ = __webpack_require__(15);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_path__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_path___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_path__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__hook_main_js__ = __webpack_require__(94);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__hook_module_js__ = __webpack_require__(98);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__hook_repl_js__ = __webpack_require__(150);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__hook_require_js__ = __webpack_require__(152);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8_vm__ = __webpack_require__(56);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8_vm___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_8_vm__);











const BuiltinModule = __non_webpack_module__.constructor;

const hooks = new __WEBPACK_IMPORTED_MODULE_0__fast_object_js__["a" /* default */]();

hooks.cli = function () {
  Object(__WEBPACK_IMPORTED_MODULE_5__hook_module_js__["a" /* default */])(BuiltinModule);
};

hooks.preload = function () {
  Object(__WEBPACK_IMPORTED_MODULE_4__hook_main_js__["a" /* default */])(BuiltinModule);
  Object(__WEBPACK_IMPORTED_MODULE_5__hook_module_js__["a" /* default */])(__WEBPACK_IMPORTED_MODULE_1__module_js__["a" /* default */]);
};

hooks.repl = function () {
  Object(__WEBPACK_IMPORTED_MODULE_6__hook_repl_js__["a" /* default */])(__WEBPACK_IMPORTED_MODULE_8_vm___default.a);
  Object(__WEBPACK_IMPORTED_MODULE_5__hook_module_js__["a" /* default */])(__WEBPACK_IMPORTED_MODULE_1__module_js__["a" /* default */]);
};

hooks.require = function (mod, options) {
  if (options === true) {
    options = __WEBPACK_IMPORTED_MODULE_2__pkg_info_js__["a" /* default */].get(Object(__WEBPACK_IMPORTED_MODULE_3_path__["dirname"])(mod.filename));
  }

  Object(__WEBPACK_IMPORTED_MODULE_5__hook_module_js__["a" /* default */])(__WEBPACK_IMPORTED_MODULE_1__module_js__["a" /* default */], options);
  return Object(__WEBPACK_IMPORTED_MODULE_7__hook_require_js__["a" /* default */])(mod, options);
};

/* harmony default export */ __webpack_exports__["a"] = (hooks);

/***/ }),
/* 94 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__pkg_info_js__ = __webpack_require__(15);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__builtin_modules_js__ = __webpack_require__(18);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_path__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_path___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_path__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__module_esm_load_js__ = __webpack_require__(37);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__module_esm_resolve_filename_js__ = __webpack_require__(38);







function hook(Module) {
  var _process = process;
  const _tickCallback = _process._tickCallback,
        argv = _process.argv;
  const mainPath = argv[1];
  const runMain = Module.runMain;


  Module.runMain = function () {
    Module.runMain = runMain;

    if (mainPath in __WEBPACK_IMPORTED_MODULE_1__builtin_modules_js__["a" /* default */]) {
      Module.runMain();
      return;
    }

    const filePath = Object(__WEBPACK_IMPORTED_MODULE_4__module_esm_resolve_filename_js__["a" /* default */])(mainPath, null, true);
    const pkgInfo = __WEBPACK_IMPORTED_MODULE_0__pkg_info_js__["a" /* default */].get(Object(__WEBPACK_IMPORTED_MODULE_2_path__["dirname"])(filePath));

    if (pkgInfo === null) {
      Module.runMain();
      return;
    }

    Object(__WEBPACK_IMPORTED_MODULE_3__module_esm_load_js__["a" /* default */])(filePath, null, true, pkgInfo.options);
    tryTickCallback();
  };

  function tryTickCallback() {
    try {
      _tickCallback.call(process);
    } catch (e) {}
  }
}

/* harmony default export */ __webpack_exports__["a"] = (hook);

/***/ }),
/* 95 */
/***/ (function(module, exports) {

module.exports = require("url");

/***/ }),
/* 96 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_path__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_path___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_path__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__decode_uri_component_js__ = __webpack_require__(61);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__encoded_slash_js__ = __webpack_require__(62);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__parse_url_js__ = __webpack_require__(63);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__vendor_punycode_punycode_es6_js__ = __webpack_require__(97);







const codeOfColon = ":".charCodeAt(0);
const codeOfSlash = "/".charCodeAt(0);

const localhostRegExp = /^\/\/localhost\b/;
const toUnicode = __WEBPACK_IMPORTED_MODULE_4__vendor_punycode_punycode_es6_js__["a" /* default */].toUnicode;


const API = {
  posix: { normalize: __WEBPACK_IMPORTED_MODULE_0_path__["posix"].normalize },
  win32: { normalize: __WEBPACK_IMPORTED_MODULE_0_path__["win32"].normalize }
};

function urlToPath(url) {
  let mode = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : "posix";
  const normalize = API[mode].normalize;

  const parsed = Object(__WEBPACK_IMPORTED_MODULE_3__parse_url_js__["a" /* default */])(url);
  let pathname = parsed.pathname;


  if (!pathname) {
    return "";
  }

  if (parsed.protocol !== "file:") {
    if (localhostRegExp.test(pathname)) {
      pathname = pathname.slice(11);
    } else {
      return "";
    }
  }

  if (Object(__WEBPACK_IMPORTED_MODULE_2__encoded_slash_js__["a" /* default */])(pathname)) {
    return "";
  }

  let host = parsed.host;

  pathname = Object(__WEBPACK_IMPORTED_MODULE_1__decode_uri_component_js__["a" /* default */])(pathname);

  // Section 2: Syntax
  // https://tools.ietf.org/html/rfc8089#section-2
  if (host === "localhost") {
    host = "";
  }if (host) {
    return mode === "win32" ? "\\\\" + toUnicode(host) + normalize(pathname) : "";
  }

  if (mode !== "win32") {
    return pathname;
  }

  // Section E.2: DOS and Windows Drive Letters
  // https://tools.ietf.org/html/rfc8089#appendix-E.2
  // https://tools.ietf.org/html/rfc8089#appendix-E.2.2
  if (pathname.length < 3 || pathname.charCodeAt(2) !== codeOfColon) {
    return "";
  }

  const code1 = pathname.charCodeAt(1);

  // Drive letters must be `[A-Za-z]:/`
  // All slashes of pathnames are forward slashes.
  if ((code1 > 64 && code1 < 91 || code1 > 96 && code1 < 123) && pathname.charCodeAt(3) === codeOfSlash) {
    return normalize(pathname).slice(1);
  }

  return "";
}

/* harmony default export */ __webpack_exports__["a"] = (urlToPath);

/***/ }),
/* 97 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";


/** Highest positive signed 32-bit float value */

const maxInt = 2147483647; // aka. 0x7FFFFFFF or 2^31-1

/** Bootstring parameters */
const base = 36;
const tMin = 1;
const tMax = 26;
const skew = 38;
const damp = 700;
const initialBias = 72;
const initialN = 128; // 0x80
const delimiter = '-'; // '\x2D'

/** Regular expressions */
const regexPunycode = /^xn--/;
const regexNonASCII = /[^\0-\x7E]/; // non-ASCII chars
const regexSeparators = /[\x2E\u3002\uFF0E\uFF61]/g; // RFC 3490 separators

/** Error messages */
const errors = {
	'overflow': 'Overflow: input needs wider integers to process',
	'not-basic': 'Illegal input >= 0x80 (not a basic code point)',
	'invalid-input': 'Invalid input'
};

/** Convenience shortcuts */
const baseMinusTMin = base - tMin;
const floor = Math.floor;
const stringFromCharCode = String.fromCharCode;

/*--------------------------------------------------------------------------*/

/**
 * A generic error utility function.
 * @private
 * @param {String} type The error type.
 * @returns {Error} Throws a `RangeError` with the applicable error message.
 */
function error(type) {
	throw new RangeError(errors[type]);
}

/**
 * A generic `Array#map` utility function.
 * @private
 * @param {Array} array The array to iterate over.
 * @param {Function} callback The function that gets called for every array
 * item.
 * @returns {Array} A new array of values returned by the callback function.
 */
function map(array, fn) {
	const result = [];
	let length = array.length;
	while (length--) {
		result[length] = fn(array[length]);
	}
	return result;
}

/**
 * A simple `Array#map`-like wrapper to work with domain name strings or email
 * addresses.
 * @private
 * @param {String} domain The domain name or email address.
 * @param {Function} callback The function that gets called for every
 * character.
 * @returns {Array} A new string of characters returned by the callback
 * function.
 */
function mapDomain(string, fn) {
	const parts = string.split('@');
	let result = '';
	if (parts.length > 1) {
		// In email addresses, only the domain name should be punycoded. Leave
		// the local part (i.e. everything up to `@`) intact.
		result = parts[0] + '@';
		string = parts[1];
	}
	// Avoid `split(regex)` for IE8 compatibility. See #17.
	string = string.replace(regexSeparators, '\x2E');
	const labels = string.split('.');
	const encoded = map(labels, fn).join('.');
	return result + encoded;
}

/**
 * Creates an array containing the numeric code points of each Unicode
 * character in the string. While JavaScript uses UCS-2 internally,
 * this function will convert a pair of surrogate halves (each of which
 * UCS-2 exposes as separate characters) into a single code point,
 * matching UTF-16.
 * @see `punycode.ucs2.encode`
 * @see <https://mathiasbynens.be/notes/javascript-encoding>
 * @memberOf punycode.ucs2
 * @name decode
 * @param {String} string The Unicode input string (UCS-2).
 * @returns {Array} The new array of code points.
 */
function ucs2decode(string) {
	const output = [];
	let counter = 0;
	const length = string.length;
	while (counter < length) {
		const value = string.charCodeAt(counter++);
		if (value >= 0xD800 && value <= 0xDBFF && counter < length) {
			// It's a high surrogate, and there is a next character.
			const extra = string.charCodeAt(counter++);
			if ((extra & 0xFC00) == 0xDC00) {
				// Low surrogate.
				output.push(((value & 0x3FF) << 10) + (extra & 0x3FF) + 0x10000);
			} else {
				// It's an unmatched surrogate; only append this code unit, in case the
				// next code unit is the high surrogate of a surrogate pair.
				output.push(value);
				counter--;
			}
		} else {
			output.push(value);
		}
	}
	return output;
}

/**
 * Creates a string based on an array of numeric code points.
 * @see `punycode.ucs2.decode`
 * @memberOf punycode.ucs2
 * @name encode
 * @param {Array} codePoints The array of numeric code points.
 * @returns {String} The new Unicode string (UCS-2).
 */
const ucs2encode = function (array) {
	return String.fromCodePoint.apply(String, array);
};

/**
 * Converts a basic code point into a digit/integer.
 * @see `digitToBasic()`
 * @private
 * @param {Number} codePoint The basic numeric code point value.
 * @returns {Number} The numeric value of a basic code point (for use in
 * representing integers) in the range `0` to `base - 1`, or `base` if
 * the code point does not represent a value.
 */
const basicToDigit = function (codePoint) {
	if (codePoint - 0x30 < 0x0A) {
		return codePoint - 0x16;
	}
	if (codePoint - 0x41 < 0x1A) {
		return codePoint - 0x41;
	}
	if (codePoint - 0x61 < 0x1A) {
		return codePoint - 0x61;
	}
	return base;
};

/**
 * Converts a digit/integer into a basic code point.
 * @see `basicToDigit()`
 * @private
 * @param {Number} digit The numeric value of a basic code point.
 * @returns {Number} The basic code point whose value (when used for
 * representing integers) is `digit`, which needs to be in the range
 * `0` to `base - 1`. If `flag` is non-zero, the uppercase form is
 * used; else, the lowercase form is used. The behavior is undefined
 * if `flag` is non-zero and `digit` has no uppercase form.
 */
const digitToBasic = function (digit, flag) {
	//  0..25 map to ASCII a..z or A..Z
	// 26..35 map to ASCII 0..9
	return digit + 22 + 75 * (digit < 26) - ((flag != 0) << 5);
};

/**
 * Bias adaptation function as per section 3.4 of RFC 3492.
 * https://tools.ietf.org/html/rfc3492#section-3.4
 * @private
 */
const adapt = function (delta, numPoints, firstTime) {
	let k = 0;
	delta = firstTime ? floor(delta / damp) : delta >> 1;
	delta += floor(delta / numPoints);
	for (; /* no initialization */delta > baseMinusTMin * tMax >> 1; k += base) {
		delta = floor(delta / baseMinusTMin);
	}
	return floor(k + (baseMinusTMin + 1) * delta / (delta + skew));
};

/**
 * Converts a Punycode string of ASCII-only symbols to a string of Unicode
 * symbols.
 * @memberOf punycode
 * @param {String} input The Punycode string of ASCII-only symbols.
 * @returns {String} The resulting string of Unicode symbols.
 */
const decode = function (input) {
	// Don't use UCS-2.
	const output = [];
	const inputLength = input.length;
	let i = 0;
	let n = initialN;
	let bias = initialBias;

	// Handle the basic code points: let `basic` be the number of input code
	// points before the last delimiter, or `0` if there is none, then copy
	// the first basic code points to the output.

	let basic = input.lastIndexOf(delimiter);
	if (basic < 0) {
		basic = 0;
	}

	for (let j = 0; j < basic; ++j) {
		// if it's not a basic code point
		if (input.charCodeAt(j) >= 0x80) {
			error('not-basic');
		}
		output.push(input.charCodeAt(j));
	}

	// Main decoding loop: start just after the last delimiter if any basic code
	// points were copied; start at the beginning otherwise.

	for (let index = basic > 0 ? basic + 1 : 0; index < inputLength;) /* no final expression */{

		// `index` is the index of the next character to be consumed.
		// Decode a generalized variable-length integer into `delta`,
		// which gets added to `i`. The overflow checking is easier
		// if we increase `i` as we go, then subtract off its starting
		// value at the end to obtain `delta`.
		let oldi = i;
		for (let w = 1, k = base;; /* no condition */k += base) {

			if (index >= inputLength) {
				error('invalid-input');
			}

			const digit = basicToDigit(input.charCodeAt(index++));

			if (digit >= base || digit > floor((maxInt - i) / w)) {
				error('overflow');
			}

			i += digit * w;
			const t = k <= bias ? tMin : k >= bias + tMax ? tMax : k - bias;

			if (digit < t) {
				break;
			}

			const baseMinusT = base - t;
			if (w > floor(maxInt / baseMinusT)) {
				error('overflow');
			}

			w *= baseMinusT;
		}

		const out = output.length + 1;
		bias = adapt(i - oldi, out, oldi == 0);

		// `i` was supposed to wrap around from `out` to `0`,
		// incrementing `n` each time, so we'll fix that now:
		if (floor(i / out) > maxInt - n) {
			error('overflow');
		}

		n += floor(i / out);
		i %= out;

		// Insert `n` at position `i` of the output.
		output.splice(i++, 0, n);
	}

	return String.fromCodePoint.apply(String, output);
};

/**
 * Converts a string of Unicode symbols (e.g. a domain name label) to a
 * Punycode string of ASCII-only symbols.
 * @memberOf punycode
 * @param {String} input The string of Unicode symbols.
 * @returns {String} The resulting Punycode string of ASCII-only symbols.
 */
const encode = function (input) {
	const output = [];

	// Convert the input in UCS-2 to an array of Unicode code points.
	input = ucs2decode(input);

	// Cache the length.
	let inputLength = input.length;

	// Initialize the state.
	let n = initialN;
	let delta = 0;
	let bias = initialBias;

	// Handle the basic code points.

	for (let _i = 0, _input = input; _i < _input.length; _i++) {
		const currentValue = _input[_i];
		if (currentValue < 0x80) {
			output.push(stringFromCharCode(currentValue));
		}
	}

	let basicLength = output.length;
	let handledCPCount = basicLength;

	// `handledCPCount` is the number of code points that have been handled;
	// `basicLength` is the number of basic code points.

	// Finish the basic string with a delimiter unless it's empty.
	if (basicLength) {
		output.push(delimiter);
	}

	// Main encoding loop:
	while (handledCPCount < inputLength) {

		// All non-basic code points < n have been handled already. Find the next
		// larger one:
		let m = maxInt;

		for (let _i2 = 0, _input2 = input; _i2 < _input2.length; _i2++) {
			const currentValue = _input2[_i2];
			if (currentValue >= n && currentValue < m) {
				m = currentValue;
			}
		}

		// Increase `delta` enough to advance the decoder's <n,i> state to <m,0>,
		// but guard against overflow.


		const handledCPCountPlusOne = handledCPCount + 1;
		if (m - n > floor((maxInt - delta) / handledCPCountPlusOne)) {
			error('overflow');
		}

		delta += (m - n) * handledCPCountPlusOne;
		n = m;

		for (let _i3 = 0, _input3 = input; _i3 < _input3.length; _i3++) {
			const currentValue = _input3[_i3];
			if (currentValue < n && ++delta > maxInt) {
				error('overflow');
			}
			if (currentValue == n) {
				// Represent delta as a generalized variable-length integer.
				let q = delta;
				for (let k = base;; /* no condition */k += base) {
					const t = k <= bias ? tMin : k >= bias + tMax ? tMax : k - bias;
					if (q < t) {
						break;
					}
					const qMinusT = q - t;
					const baseMinusT = base - t;
					output.push(stringFromCharCode(digitToBasic(t + qMinusT % baseMinusT, 0)));
					q = floor(qMinusT / baseMinusT);
				}

				output.push(stringFromCharCode(digitToBasic(q, 0)));
				bias = adapt(delta, handledCPCountPlusOne, handledCPCount == basicLength);
				delta = 0;
				++handledCPCount;
			}
		}

		++delta;
		++n;
	}
	return output.join('');
};

/**
 * Converts a Punycode string representing a domain name or an email address
 * to Unicode. Only the Punycoded parts of the input will be converted, i.e.
 * it doesn't matter if you call it on a string that has already been
 * converted to Unicode.
 * @memberOf punycode
 * @param {String} input The Punycoded domain name or email address to
 * convert to Unicode.
 * @returns {String} The Unicode representation of the given Punycode
 * string.
 */
const toUnicode = function (input) {
	return mapDomain(input, function (string) {
		return regexPunycode.test(string) ? decode(string.slice(4).toLowerCase()) : string;
	});
};

/**
 * Converts a Unicode string representing a domain name or an email address to
 * Punycode. Only the non-ASCII parts of the domain name will be converted,
 * i.e. it doesn't matter if you call it with a domain that's already in
 * ASCII.
 * @memberOf punycode
 * @param {String} input The domain name or email address to convert, as a
 * Unicode string.
 * @returns {String} The Punycode representation of the given domain name or
 * email address.
 */
const toASCII = function (input) {
	return mapDomain(input, function (string) {
		return regexNonASCII.test(string) ? 'xn--' + encode(string) : string;
	});
};

/*--------------------------------------------------------------------------*/

/** Define the public API */
const punycode = {
	/**
  * A string representing the current Punycode.js version number.
  * @memberOf punycode
  * @type String
  */
	'version': '2.1.0',
	/**
  * An object of methods to convert from JavaScript's internal character
  * representation (UCS-2) to Unicode code points, and back.
  * @see <https://mathiasbynens.be/notes/javascript-encoding>
  * @memberOf punycode
  * @type Object
  */
	'ucs2': {
		'decode': ucs2decode,
		'encode': ucs2encode
	},
	'decode': decode,
	'encode': encode,
	'toASCII': toASCII,
	'toUnicode': toUnicode
};

/* harmony default export */ __webpack_exports__["a"] = (punycode);

/***/ }),
/* 98 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_path__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_path___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_path__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__pkg_info_js__ = __webpack_require__(15);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__runtime_js__ = __webpack_require__(64);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__wrapper_js__ = __webpack_require__(39);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__util_assign_js__ = __webpack_require__(26);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__util_attempt_js__ = __webpack_require__(67);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__binding_js__ = __webpack_require__(8);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__caching_compiler_js__ = __webpack_require__(69);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__util_encode_id_js__ = __webpack_require__(78);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__errors_js__ = __webpack_require__(21);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__path_extname_js__ = __webpack_require__(28);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11_fs__ = __webpack_require__(5);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11_fs___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_11_fs__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_12__util_get_cache_file_name_js__ = __webpack_require__(79);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_13__util_get_cache_state_hash_js__ = __webpack_require__(146);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_14__fs_gunzip_js__ = __webpack_require__(147);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_15__parse_has_pragma_js__ = __webpack_require__(73);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_16__util_is_error_js__ = __webpack_require__(20);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_17__util_is_object_js__ = __webpack_require__(19);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_18__util_is_object_like_js__ = __webpack_require__(4);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_19__error_mask_stack_trace_js__ = __webpack_require__(68);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_20__module_state_js__ = __webpack_require__(12);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_21__fs_mtime_js__ = __webpack_require__(148);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_22__fs_read_file_js__ = __webpack_require__(23);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_23_semver__ = __webpack_require__(11);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_23_semver___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_23_semver__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_24__util_set_property_js__ = __webpack_require__(10);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_25__util_set_source_type_js__ = __webpack_require__(149);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_26__fs_stat_js__ = __webpack_require__(24);






























const fsBinding = __WEBPACK_IMPORTED_MODULE_6__binding_js__["a" /* default */].fs;
const mjsSym = Symbol.for('@std/esm:extensions[".mjs"]');

function hook(Module, options) {
  options = Object(__WEBPACK_IMPORTED_MODULE_18__util_is_object_like_js__["a" /* default */])(options) ? options : null;

  const _extensions = Module._extensions;

  const jsCompiler = __WEBPACK_IMPORTED_MODULE_3__wrapper_js__["a" /* default */].unwrap(_extensions, ".js");
  const passthruMap = new Map();

  let allowTopLevelAwait = Object(__WEBPACK_IMPORTED_MODULE_17__util_is_object_js__["a" /* default */])(process.mainModule) && Object(__WEBPACK_IMPORTED_MODULE_23_semver__["satisfies"])(process.version, ">=7.6.0");

  function managerWrapper(manager, func, args) {
    const filePath = args[1];

    const dirPath = Object(__WEBPACK_IMPORTED_MODULE_0_path__["dirname"])(filePath);
    let pkgInfo = options === null ? __WEBPACK_IMPORTED_MODULE_1__pkg_info_js__["a" /* default */].get(dirPath) : null;

    if (options !== null) {
      pkgInfo = __WEBPACK_IMPORTED_MODULE_1__pkg_info_js__["a" /* default */].read(dirPath, true);
      __WEBPACK_IMPORTED_MODULE_1__pkg_info_js__["a" /* default */].set(dirPath, pkgInfo);
      Object(__WEBPACK_IMPORTED_MODULE_4__util_assign_js__["a" /* default */])(pkgInfo.options, options);
    }

    if (pkgInfo === null || pkgInfo.options === null) {
      return func.apply(this, args);
    }

    const wrapped = __WEBPACK_IMPORTED_MODULE_3__wrapper_js__["a" /* default */].find(_extensions, ".js", pkgInfo.range);

    return wrapped === null ? func.apply(this, args) : wrapped.call(this, manager, func, pkgInfo, args);
  }

  // eslint-disable-next-line consistent-return
  function methodWrapper(manager, func, pkgInfo, args) {
    const mod = args[0],
          filePath = args[1];

    const ext = Object(__WEBPACK_IMPORTED_MODULE_10__path_extname_js__["a" /* default */])(filePath);
    const options = pkgInfo.options;


    let hint = "script";
    let type = "script";

    if (options.esm === "all") {
      type = "module";
    } else if (options.esm === "js") {
      type = "unambiguous";
    }

    if (ext === ".mjs" || ext === ".mjs.gz") {
      hint = "module";
      if (type === "script") {
        type = "module";
      }
    }

    const cache = pkgInfo.cache,
          cachePath = pkgInfo.cachePath;

    const cacheKey = Object(__WEBPACK_IMPORTED_MODULE_21__fs_mtime_js__["a" /* default */])(filePath);
    const cacheFileName = Object(__WEBPACK_IMPORTED_MODULE_12__util_get_cache_file_name_js__["a" /* default */])(filePath, cacheKey, pkgInfo);

    const stateHash = Object(__WEBPACK_IMPORTED_MODULE_13__util_get_cache_state_hash_js__["a" /* default */])(cacheFileName);
    const runtimeAlias = Object(__WEBPACK_IMPORTED_MODULE_8__util_encode_id_js__["a" /* default */])("_" + stateHash.slice(0, 3));

    let cacheCode;
    let sourceCode;
    let cacheValue = cache[cacheFileName];

    if (cacheValue === true) {
      cacheCode = readCode(Object(__WEBPACK_IMPORTED_MODULE_0_path__["join"])(cachePath, cacheFileName), options);
    } else {
      sourceCode = readCode(filePath, options);
    }

    if (!Object(__WEBPACK_IMPORTED_MODULE_17__util_is_object_js__["a" /* default */])(cacheValue)) {
      if (cacheValue === true) {
        if (type === "unambiguous") {
          type = Object(__WEBPACK_IMPORTED_MODULE_15__parse_has_pragma_js__["a" /* default */])(cacheCode, "use script") ? "script" : "module";
        }

        cacheValue = { code: cacheCode, type };
        cache[cacheFileName] = cacheValue;
      } else {
        const compilerOptions = {
          cacheFileName,
          cachePath,
          filePath,
          hint,
          pkgInfo,
          runtimeAlias,
          type
        };

        const callback = function () {
          return __WEBPACK_IMPORTED_MODULE_7__caching_compiler_js__["a" /* default */].compile(sourceCode, compilerOptions);
        };
        cacheValue = options.debug ? callback() : Object(__WEBPACK_IMPORTED_MODULE_5__util_attempt_js__["a" /* default */])(callback, manager, sourceCode);
      }
    }

    const noDepth = __WEBPACK_IMPORTED_MODULE_20__module_state_js__["a" /* default */].requireDepth === 0;

    if (noDepth) {
      __WEBPACK_IMPORTED_MODULE_26__fs_stat_js__["a" /* default */].cache = Object.create(null);
    }

    const tryModuleCompile = cacheValue.type === "module" ? tryESMCompile : tryCJSCompile;
    tryModuleCompile.call(this, func, mod, cacheValue.code, filePath, runtimeAlias, options);

    if (noDepth) {
      __WEBPACK_IMPORTED_MODULE_26__fs_stat_js__["a" /* default */].cache = null;
    }
  }

  function readCode(filePath, options) {
    return options.gz && Object(__WEBPACK_IMPORTED_MODULE_0_path__["extname"])(filePath) === ".gz" ? Object(__WEBPACK_IMPORTED_MODULE_14__fs_gunzip_js__["a" /* default */])(Object(__WEBPACK_IMPORTED_MODULE_22__fs_read_file_js__["a" /* default */])(filePath), "utf8") : Object(__WEBPACK_IMPORTED_MODULE_22__fs_read_file_js__["a" /* default */])(filePath, "utf8");
  }

  function tryCJSCompile(func, mod, content, filePath, runtimeAlias, options) {
    const exported = Object.create(null);
    Object(__WEBPACK_IMPORTED_MODULE_25__util_set_source_type_js__["a" /* default */])(exported, "script");
    __WEBPACK_IMPORTED_MODULE_2__runtime_js__["a" /* default */].enable(mod, exported, options);

    content = "const " + runtimeAlias + "=this;" + runtimeAlias + ".r((function(exports,require,module,__filename,__dirname){" + content + "\n}))";

    tryModuleCompile.call(this, func, mod, content, filePath, options);
  }

  function tryESMCompile(func, mod, content, filePath, runtimeAlias, options) {
    const exported = Object.create(null);
    Object(__WEBPACK_IMPORTED_MODULE_25__util_set_source_type_js__["a" /* default */])(exported, "module");
    __WEBPACK_IMPORTED_MODULE_2__runtime_js__["a" /* default */].enable(mod, exported, options);

    let async = "";

    if (allowTopLevelAwait && options.await) {
      allowTopLevelAwait = false;
      if (process.mainModule === mod || process.mainModule.children.some(function (child) {
        return child === mod;
      })) {
        async = "async ";
      }
    }

    content = (options.cjs ? '"use strict";const ' + runtimeAlias + "=this;" : "") + runtimeAlias + ".r((" + async + "function(){" + content + "\n}))";

    const moduleWrap = Module.wrap;

    const customWrap = function (script) {
      Module.wrap = moduleWrap;
      return '"use strict";(function(){const ' + runtimeAlias + "=this;" + script + "\n})";
    };

    if (!options.cjs) {
      Module.wrap = customWrap;
    }

    try {
      tryModuleCompile.call(this, func, mod, content, filePath, options);
    } finally {
      if (Module.wrap === customWrap) {
        Module.wrap = moduleWrap;
      }
    }
  }

  function tryModuleCompile(func, mod, content, filePath, options) {
    const moduleCompile = mod._compile;
    const moduleReadFile = fsBinding.internalModuleReadFile;
    const passthru = passthruMap.get(func);
    const readFileSync = __WEBPACK_IMPORTED_MODULE_11_fs___default.a.readFileSync;


    let restored = false;

    const readAndRestore = function () {
      restored = true;

      if (typeof moduleReadFile === "function") {
        fsBinding.internalModuleReadFile = moduleReadFile;
      }

      __WEBPACK_IMPORTED_MODULE_11_fs___default.a.readFileSync = readFileSync;
      return content;
    };

    const customModuleCompile = function (content, compilePath) {
      if (compilePath === filePath && !restored) {
        // This fallback is only hit if the read file wrappers are missed,
        // which should never happen.
        content = readAndRestore();
      }

      mod._compile = moduleCompile;
      return moduleCompile.call(this, content, compilePath);
    };

    const customModuleReadFile = function (readPath) {
      return readPath === filePath ? readAndRestore() : moduleReadFile.call(this, readPath);
    };

    const customReadFileSync = function (readPath, readOptions) {
      return readPath === filePath ? readAndRestore() : readFileSync.call(this, readPath, readOptions);
    };

    if (typeof moduleReadFile === "function") {
      // Wrap `process.binding("fs").internalModuleReadFile` in case future
      // versions of Node use it instead of `fs.readFileSync`.
      fsBinding.internalModuleReadFile = customModuleReadFile;
    }

    // Wrap `fs.readFileSync` to avoid an extra file read when the passthru
    // `Module._extensions[ext]` is called.
    __WEBPACK_IMPORTED_MODULE_11_fs___default.a.readFileSync = customReadFileSync;

    // Wrap `mod._compile` in the off chance the read file wrappers are missed.
    mod._compile = customModuleCompile;

    try {
      if (options.debug) {
        if (passthru) {
          func.call(this, mod, filePath);
        } else {
          mod._compile(content, filePath);
        }
      } else {
        try {
          if (passthru) {
            func.call(this, mod, filePath);
          } else {
            mod._compile(content, filePath);
          }
        } catch (e) {
          throw Object(__WEBPACK_IMPORTED_MODULE_19__error_mask_stack_trace_js__["a" /* default */])(e);
        }
      }
    } finally {
      if (fsBinding.internalModuleReadFile === customModuleReadFile) {
        fsBinding.internalModuleReadFile = moduleReadFile;
      }

      if (__WEBPACK_IMPORTED_MODULE_11_fs___default.a.readFileSync === customReadFileSync) {
        __WEBPACK_IMPORTED_MODULE_11_fs___default.a.readFileSync = readFileSync;
      }

      if (mod._compile === customModuleCompile) {
        mod._compile = moduleCompile;
      }
    }
  }

  const exts = [".js", ".gz", ".js.gz", ".mjs.gz", ".mjs"];

  exts.forEach(function (key) {
    if (typeof _extensions[key] !== "function") {
      // Mimic the built-in behavior for ".mjs" and unrecognized extensions.
      if (key === ".gz") {
        _extensions[key] = gzCompiler;
      } else if (key === ".mjs" || key === ".mjs.gz") {
        _extensions[key] = mjsCompiler;
      } else if (key !== ".js") {
        _extensions[key] = jsCompiler;
      }
    }

    const extCompiler = __WEBPACK_IMPORTED_MODULE_3__wrapper_js__["a" /* default */].unwrap(_extensions, key);
    let passthru = !extCompiler[mjsSym];

    if (passthru && key === ".mjs") {
      try {
        extCompiler();
      } catch (e) {
        if (Object(__WEBPACK_IMPORTED_MODULE_16__util_is_error_js__["a" /* default */])(e) && e.code === "ERR_REQUIRE_ESM") {
          passthru = false;
        }
      }
    }

    passthruMap.set(extCompiler, passthru);

    __WEBPACK_IMPORTED_MODULE_3__wrapper_js__["a" /* default */].manage(_extensions, key, managerWrapper);
    __WEBPACK_IMPORTED_MODULE_3__wrapper_js__["a" /* default */].wrap(_extensions, key, methodWrapper);
  });

  __WEBPACK_IMPORTED_MODULE_20__module_state_js__["a" /* default */].extensions[".js"] = _extensions[".js"];
}

function gzCompiler(mod, filePath) {
  let ext = Object(__WEBPACK_IMPORTED_MODULE_10__path_extname_js__["a" /* default */])(filePath);

  if (ext === ".gz" || typeof this[ext] !== "function") {
    ext = ".js";
  }

  const extCompiler = __WEBPACK_IMPORTED_MODULE_3__wrapper_js__["a" /* default */].unwrap(this, ext);
  return extCompiler.call(this, mod, filePath);
}

function mjsCompiler(mod, filePath) {
  throw new __WEBPACK_IMPORTED_MODULE_9__errors_js__["a" /* default */].Error("ERR_REQUIRE_ESM", filePath);
}

Object(__WEBPACK_IMPORTED_MODULE_24__util_set_property_js__["a" /* default */])(mjsCompiler, mjsSym, {
  configurable: false,
  enumerable: false,
  value: true,
  writable: false
});

/* harmony default export */ __webpack_exports__["a"] = (hook);

/***/ }),
/* 99 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__get_getter_js__ = __webpack_require__(60);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__get_setter_js__ = __webpack_require__(100);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__set_getter_js__ = __webpack_require__(9);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__set_setter_js__ = __webpack_require__(16);





function assignProperty(object, source, key) {
  const getter = Object(__WEBPACK_IMPORTED_MODULE_0__get_getter_js__["a" /* default */])(source, key);
  const setter = Object(__WEBPACK_IMPORTED_MODULE_1__get_setter_js__["a" /* default */])(source, key);
  const hasGetter = typeof getter === "function";
  const hasSetter = typeof setter === "function";

  if (hasGetter || hasSetter) {
    if (hasGetter) {
      Object(__WEBPACK_IMPORTED_MODULE_2__set_getter_js__["a" /* default */])(object, key, getter);
    }
    if (hasSetter) {
      Object(__WEBPACK_IMPORTED_MODULE_3__set_setter_js__["a" /* default */])(object, key, setter);
    }
  } else {
    object[key] = source[key];
  }

  return object;
}

/* harmony default export */ __webpack_exports__["a"] = (assignProperty);

/***/ }),
/* 100 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__has_js__ = __webpack_require__(7);


const lookupSetter = Object.prototype.__lookupSetter__;

function getSetter(object, key) {
  return Object(__WEBPACK_IMPORTED_MODULE_0__has_js__["a" /* default */])(object, key) ? lookupSetter.call(object, key) : void 0;
}

/* harmony default export */ __webpack_exports__["a"] = (getSetter);

/***/ }),
/* 101 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
function getModuleName(mod) {
  const filename = mod.filename,
        id = mod.id;

  return typeof filename === "string" ? filename : id;
}

/* harmony default export */ __webpack_exports__["a"] = (getModuleName);

/***/ }),
/* 102 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__is_object_like_js__ = __webpack_require__(4);


const getOwnPropertyNames = Object.getOwnPropertyNames;


function keysAll(object) {
  return Object(__WEBPACK_IMPORTED_MODULE_0__is_object_like_js__["a" /* default */])(object) ? getOwnPropertyNames(object) : [];
}

/* harmony default export */ __webpack_exports__["a"] = (keysAll);

/***/ }),
/* 103 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__entry_js__ = __webpack_require__(65);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__fast_object_js__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__builtin_modules_js__ = __webpack_require__(18);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__util_set_getter_js__ = __webpack_require__(9);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__util_set_property_js__ = __webpack_require__(10);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__util_set_setter_js__ = __webpack_require__(16);








const builtinEntries = Object.keys(__WEBPACK_IMPORTED_MODULE_2__builtin_modules_js__["a" /* default */]).reduce(function (object, id) {
  Object(__WEBPACK_IMPORTED_MODULE_3__util_set_getter_js__["a" /* default */])(object, id, function () {
    const entry = __WEBPACK_IMPORTED_MODULE_0__entry_js__["a" /* default */].get(__WEBPACK_IMPORTED_MODULE_2__builtin_modules_js__["a" /* default */][id]);
    entry.loaded();
    return object[id] = entry;
  });

  Object(__WEBPACK_IMPORTED_MODULE_5__util_set_setter_js__["a" /* default */])(object, id, function (value) {
    Object(__WEBPACK_IMPORTED_MODULE_4__util_set_property_js__["a" /* default */])(object, id, { value });
  });

  return object;
}, new __WEBPACK_IMPORTED_MODULE_1__fast_object_js__["a" /* default */]());

/* harmony default export */ __webpack_exports__["a"] = (builtinEntries);

/***/ }),
/* 104 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_path__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_path___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_path__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__wrapper_js__ = __webpack_require__(39);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__load_js__ = __webpack_require__(36);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__node_module_paths_js__ = __webpack_require__(27);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__resolve_filename_js__ = __webpack_require__(48);








function load(id, parent, isMain, options) {
  const filePath = Object(__WEBPACK_IMPORTED_MODULE_4__resolve_filename_js__["a" /* default */])(id, parent, isMain, options);
  return Object(__WEBPACK_IMPORTED_MODULE_2__load_js__["a" /* default */])(filePath, parent, isMain, require, loader);
}

function loader(filePath) {
  let ext = Object(__WEBPACK_IMPORTED_MODULE_0_path__["extname"])(filePath);
  var _non_webpack_require = require;
  const extensions = _non_webpack_require.extensions;


  if (!ext || typeof extensions[ext] !== "function") {
    ext = ".js";
  }

  const mod = this;
  mod.filename = filePath;
  mod.paths = Object(__WEBPACK_IMPORTED_MODULE_3__node_module_paths_js__["a" /* default */])(Object(__WEBPACK_IMPORTED_MODULE_0_path__["dirname"])(filePath));

  const extCompiler = __WEBPACK_IMPORTED_MODULE_1__wrapper_js__["a" /* default */].unwrap(extensions, ext);
  extCompiler.call(extensions, mod, filePath);
  mod.loaded = true;
}

/* harmony default export */ __webpack_exports__["a"] = (load);

/***/ }),
/* 105 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__fast_object_js__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_semver__ = __webpack_require__(11);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_semver___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_semver__);




const satisfyCache = new __WEBPACK_IMPORTED_MODULE_0__fast_object_js__["a" /* default */]();

function maxSatisfying(versions, range) {
  const cacheKey = versions + "\0" + range;

  return cacheKey in satisfyCache ? satisfyCache[cacheKey] : satisfyCache[cacheKey] = Object(__WEBPACK_IMPORTED_MODULE_1_semver__["maxSatisfying"])(versions, range);
}

/* harmony default export */ __webpack_exports__["a"] = (maxSatisfying);

/***/ }),
/* 106 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__binding_js__ = __webpack_require__(8);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__util_is_error_js__ = __webpack_require__(20);



const utilBinding = __WEBPACK_IMPORTED_MODULE_0__binding_js__["a" /* default */].util;
const _setHiddenValue = utilBinding.setHiddenValue;
const arrowMessageSymbol = utilBinding.arrow_message_private_symbol;
const decoratedSymbol = utilBinding.decorated_private_symbol;

const useArrowMessageSymbol = arrowMessageSymbol !== void 0;
const useDecoratedSymbol = decoratedSymbol !== void 0;
const useSetHiddenValue = typeof _setHiddenValue === "function";

function decorateStackTrace(error) {
  if (!Object(__WEBPACK_IMPORTED_MODULE_1__util_is_error_js__["a" /* default */])(error)) {
    return error;
  }

  if (useArrowMessageSymbol) {
    setHiddenValue(error, arrowMessageSymbol, "");
  } else {
    setHiddenValue(error, "arrowMessage", "");
    setHiddenValue(error, "node:arrowMessage", "");
  }

  if (useDecoratedSymbol) {
    setHiddenValue(error, decoratedSymbol, true);
  } else {
    setHiddenValue(error, "node:decorated", true);
  }

  return error;
}

function setHiddenValue(object, key, value) {
  if (useSetHiddenValue) {
    try {
      return _setHiddenValue.call(utilBinding, object, key, value);
    } catch (e) {}
  }

  return false;
}

/* harmony default export */ __webpack_exports__["a"] = (decorateStackTrace);

/***/ }),
/* 107 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__is_error_js__ = __webpack_require__(20);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__is_object_js__ = __webpack_require__(19);



function isParseError(value) {
  return Object(__WEBPACK_IMPORTED_MODULE_0__is_error_js__["a" /* default */])(value) && typeof value.pos === "number" && typeof value.raisedAt === "number" && Object(__WEBPACK_IMPORTED_MODULE_1__is_object_js__["a" /* default */])(value.loc);
}

/* harmony default export */ __webpack_exports__["a"] = (isParseError);

/***/ }),
/* 108 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__fast_path_js__ = __webpack_require__(109);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__parser_js__ = __webpack_require__(110);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__visitor_assignment_js__ = __webpack_require__(126);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__util_create_options_js__ = __webpack_require__(2);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__parse_has_pragma_js__ = __webpack_require__(73);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__visitor_identifier_js__ = __webpack_require__(127);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__visitor_import_export_js__ = __webpack_require__(128);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__util_strip_shebang_js__ = __webpack_require__(57);










const defaultOptions = Object(__WEBPACK_IMPORTED_MODULE_3__util_create_options_js__["a" /* default */])({
  cjs: false,
  ext: false,
  hint: "script",
  runtimeAlias: "_",
  type: "module",
  var: false
});

const argumentsRegExp = /\barguments\b/;
const importExportRegExp = /\b(?:im|ex)port\b/;

class Compiler {

  static compile(code, options) {
    code = Object(__WEBPACK_IMPORTED_MODULE_7__util_strip_shebang_js__["a" /* default */])(code);
    options = Object(__WEBPACK_IMPORTED_MODULE_3__util_create_options_js__["a" /* default */])(options, defaultOptions);

    var _options = options;
    let hint = _options.hint,
        type = _options.type;


    const result = {
      code,
      data: null,
      type: "script"
    };

    let useModule;

    if (type === "unambiguous" && (Object(__WEBPACK_IMPORTED_MODULE_4__parse_has_pragma_js__["a" /* default */])(code, "use script") || hint !== "module" && !importExportRegExp.test(code) && !(useModule = Object(__WEBPACK_IMPORTED_MODULE_4__parse_has_pragma_js__["a" /* default */])(code, "use module")))) {
      return result;
    }

    let ast;
    let error;
    let threw = true;

    const parserOptions = {
      allowReturnOutsideFunction: options.cjs,
      enableExportExtensions: options.ext,
      enableImportExtensions: options.ext,
      sourceType: type === "script" ? type : "module"
    };

    try {
      ast = __WEBPACK_IMPORTED_MODULE_1__parser_js__["a" /* default */].parse(code, parserOptions);
      threw = false;
    } catch (e) {
      error = e;
    }

    if (threw && type === "unambiguous") {
      type = parserOptions.sourceType = "script";

      try {
        ast = __WEBPACK_IMPORTED_MODULE_1__parser_js__["a" /* default */].parse(code, parserOptions);
        threw = false;
      } catch (e) {}
    }

    if (threw) {
      throw error;
    }

    const rootPath = new __WEBPACK_IMPORTED_MODULE_0__fast_path_js__["a" /* default */](ast);

    __WEBPACK_IMPORTED_MODULE_6__visitor_import_export_js__["a" /* default */].visit(rootPath, code, {
      generateVarDeclarations: options.var,
      runtimeAlias: options.runtimeAlias,
      sourceType: type
    });

    if (__WEBPACK_IMPORTED_MODULE_6__visitor_import_export_js__["a" /* default */].addedImportExport) {
      __WEBPACK_IMPORTED_MODULE_2__visitor_assignment_js__["a" /* default */].visit(rootPath, {
        exportedLocalNames: __WEBPACK_IMPORTED_MODULE_6__visitor_import_export_js__["a" /* default */].exportedLocalNames,
        importedLocalNames: __WEBPACK_IMPORTED_MODULE_6__visitor_import_export_js__["a" /* default */].importedLocalNames,
        magicString: __WEBPACK_IMPORTED_MODULE_6__visitor_import_export_js__["a" /* default */].magicString,
        runtimeAlias: __WEBPACK_IMPORTED_MODULE_6__visitor_import_export_js__["a" /* default */].runtimeAlias
      });

      __WEBPACK_IMPORTED_MODULE_6__visitor_import_export_js__["a" /* default */].finalizeHoisting();
    }

    if (type === "module" || __WEBPACK_IMPORTED_MODULE_6__visitor_import_export_js__["a" /* default */].addedImportExport || type === "unambiguous" && (hint === "module" || (typeof useModule === "boolean" ? useModule : useModule = Object(__WEBPACK_IMPORTED_MODULE_4__parse_has_pragma_js__["a" /* default */])(code, "use module")))) {
      result.type = "module";

      if (argumentsRegExp.test(code)) {
        __WEBPACK_IMPORTED_MODULE_5__visitor_identifier_js__["a" /* default */].visit(rootPath, {
          magicString: __WEBPACK_IMPORTED_MODULE_6__visitor_import_export_js__["a" /* default */].magicString
        });
      }
    }

    result.code = __WEBPACK_IMPORTED_MODULE_6__visitor_import_export_js__["a" /* default */].magicString.toString();
    return result;
  }
}

Compiler.defaultOptions = defaultOptions;
Object.setPrototypeOf(Compiler.prototype, null);

/* harmony default export */ __webpack_exports__["a"] = (Compiler);

/***/ }),
/* 109 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__util_is_object_js__ = __webpack_require__(19);
// A simplified version of the AST traversal abstraction used by Recast.
// Copyright Ben Newman. Released under MIT license:
// https://github.com/benjamn/recast/blob/master/lib/fast-path.js



const alwaysTrue = function () {
  return true;
};

class FastPath {
  constructor(ast) {
    this.stack = [ast];
  }

  // Temporarily push a `key` and its `value` onto `this.stack`, then call the
  // `visitor` method with a reference to `this` (modified) `FastPath` object.
  // Note that the stack is restored to its original state after the `visitor`
  // method has finished, so don't retain a reference to the path.
  call(visitor, methodName, key) {
    const stack = this.stack;

    const object = stack[stack.length - 1];

    stack.push(key, object[key]);
    const result = visitor[methodName](this);
    stack.length -= 2;

    return result;
  }

  // Similar to `FastPath.prototype.call`, except that the value obtained by
  // `this.getValue()` should be array-like. The `visitor` method is called with
  // a reference to this path object for each element of the array.
  each(visitor, methodName) {
    let i = -1;
    const stack = this.stack;

    const array = stack[stack.length - 1];
    const length = array.length;


    while (++i < length) {
      stack.push(i, array[i]);
      visitor[methodName](this);
      stack.length -= 2;
    }
  }

  getParentNode(callback) {
    return getNode(this, -2, callback);
  }

  getValue() {
    const stack = this.stack;

    return stack[stack.length - 1];
  }
}

function getNode(path, pos, callback) {
  const stack = path.stack;

  const stackCount = stack.length;
  let i = stackCount;

  if (typeof callback !== "function") {
    callback = alwaysTrue;
  }

  if (pos !== void 0) {
    i = pos < 0 ? i + pos : pos;
  }

  while (i-- > 0) {
    // Without a complete list of node type names, we have to settle for this
    // fuzzy matching of object shapes.
    const value = stack[i--];
    if (Object(__WEBPACK_IMPORTED_MODULE_0__util_is_object_js__["a" /* default */])(value) && !Array.isArray(value) && callback(value)) {
      return value;
    }
  }

  return null;
}

Object.setPrototypeOf(FastPath.prototype, null);

/* harmony default export */ __webpack_exports__["a"] = (FastPath);

/***/ }),
/* 110 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__acorn_parser_js__ = __webpack_require__(40);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__util_create_options_js__ = __webpack_require__(2);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__acorn_ext_await_anywhere_js__ = __webpack_require__(120);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__acorn_ext_dynamic_import_js__ = __webpack_require__(121);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__acorn_ext_export_js__ = __webpack_require__(122);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__acorn_ext_import_js__ = __webpack_require__(123);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__acorn_ext_object_rest_spread_js__ = __webpack_require__(124);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__acorn_ext_tolerance_js__ = __webpack_require__(125);










const defaultOptions = Object(__WEBPACK_IMPORTED_MODULE_1__util_create_options_js__["a" /* default */])({
  allowReturnOutsideFunction: false,
  ecmaVersion: 9,
  enableExportExtensions: false,
  enableImportExtensions: false,
  sourceType: "module"
});

class Parser {

  static parse(code, options) {
    options = Object(__WEBPACK_IMPORTED_MODULE_1__util_create_options_js__["a" /* default */])(options, defaultOptions);
    return extend(new __WEBPACK_IMPORTED_MODULE_0__acorn_parser_js__["a" /* default */](options, code), options).parse();
  }
}

Parser.defaultOptions = defaultOptions;
function extend(parser, options) {
  Object(__WEBPACK_IMPORTED_MODULE_2__acorn_ext_await_anywhere_js__["a" /* enable */])(parser);
  Object(__WEBPACK_IMPORTED_MODULE_3__acorn_ext_dynamic_import_js__["a" /* enable */])(parser);
  Object(__WEBPACK_IMPORTED_MODULE_6__acorn_ext_object_rest_spread_js__["a" /* enable */])(parser);
  Object(__WEBPACK_IMPORTED_MODULE_7__acorn_ext_tolerance_js__["a" /* enable */])(parser);

  if (options.enableExportExtensions) {
    Object(__WEBPACK_IMPORTED_MODULE_4__acorn_ext_export_js__["a" /* enable */])(parser);
  }

  if (options.enableImportExtensions) {
    Object(__WEBPACK_IMPORTED_MODULE_5__acorn_ext_import_js__["a" /* enable */])(parser);
  }

  return parser;
}

Object.setPrototypeOf(Parser.prototype, null);

/* harmony default export */ __webpack_exports__["a"] = (Parser);

/***/ }),
/* 111 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__tokentype__ = __webpack_require__(3);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__state__ = __webpack_require__(6);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__parseutil__ = __webpack_require__(70);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__whitespace__ = __webpack_require__(13);
// A recursive descent parser operates by defining functions for all
// syntactic elements, and recursively calling those, each function
// advancing the input stream and returning an AST node. Precedence
// of constructs (for example, the fact that `!x[1]` means `!(x[1])`
// instead of `(!x)[1]` is handled by the fact that the parser
// function that parses unary prefix operators is called first, and
// in turn calls the function that parses `[]` subscripts — that
// way, it'll receive the node for `x[1]` already parsed, and wraps
// *that* in the unary operator node.
//
// Acorn uses an [operator precedence parser][opp] to handle binary
// operator precedence, because it is much more compact than using
// the technique outlined above, which uses different, nesting
// functions to specify precedence, for all of the ten binary
// precedence levels that JavaScript defines.
//
// [opp]: http://en.wikipedia.org/wiki/Operator-precedence_parser






const pp = __WEBPACK_IMPORTED_MODULE_1__state__["a" /* Parser */].prototype;

// Check if property name clashes with already added.
// Object/class getters and setters are not allowed to clash —
// either with each other or with an init property — and in
// strict mode, init properties are also not allowed to be repeated.

pp.checkPropClash = function (prop, propHash) {
  if (this.options.ecmaVersion >= 6 && (prop.computed || prop.method || prop.shorthand)) return;
  let key = prop.key,
      name;
  switch (key.type) {
    case "Identifier":
      name = key.name;break;
    case "Literal":
      name = String(key.value);break;
    default:
      return;
  }
  let kind = prop.kind;

  if (this.options.ecmaVersion >= 6) {
    if (name === "__proto__" && kind === "init") {
      if (propHash.proto) this.raiseRecoverable(key.start, "Redefinition of __proto__ property");
      propHash.proto = true;
    }
    return;
  }
  name = "$" + name;
  let other = propHash[name];
  if (other) {
    let redefinition;
    if (kind === "init") {
      redefinition = this.strict && other.init || other.get || other.set;
    } else {
      redefinition = other.init || other[kind];
    }
    if (redefinition) this.raiseRecoverable(key.start, "Redefinition of property");
  } else {
    other = propHash[name] = {
      init: false,
      get: false,
      set: false
    };
  }
  other[kind] = true;
};

// ### Expression parsing

// These nest, from the most general expression type at the top to
// 'atomic', nondivisible expression types at the bottom. Most of
// the functions will simply let the function(s) below them parse,
// and, *if* the syntactic construct they handle is present, wrap
// the AST node that the inner parser gave them in another node.

// Parse a full expression. The optional arguments are used to
// forbid the `in` operator (in for loops initalization expressions)
// and provide reference for storing '=' operator inside shorthand
// property assignment in contexts where both object expression
// and object pattern might appear (so it's possible to raise
// delayed syntax error at correct position).

pp.parseExpression = function (noIn, refDestructuringErrors) {
  let startPos = this.start,
      startLoc = this.startLoc;
  let expr = this.parseMaybeAssign(noIn, refDestructuringErrors);
  if (this.type === __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].comma) {
    let node = this.startNodeAt(startPos, startLoc);
    node.expressions = [expr];
    while (this.eat(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].comma)) node.expressions.push(this.parseMaybeAssign(noIn, refDestructuringErrors));
    return this.finishNode(node, "SequenceExpression");
  }
  return expr;
};

// Parse an assignment expression. This includes applications of
// operators like `+=`.

pp.parseMaybeAssign = function (noIn, refDestructuringErrors, afterLeftParse) {
  if (this.inGenerator && this.isContextual("yield")) return this.parseYield();

  let ownDestructuringErrors = false,
      oldParenAssign = -1,
      oldTrailingComma = -1;
  if (refDestructuringErrors) {
    oldParenAssign = refDestructuringErrors.parenthesizedAssign;
    oldTrailingComma = refDestructuringErrors.trailingComma;
    refDestructuringErrors.parenthesizedAssign = refDestructuringErrors.trailingComma = -1;
  } else {
    refDestructuringErrors = new __WEBPACK_IMPORTED_MODULE_2__parseutil__["a" /* DestructuringErrors */]();
    ownDestructuringErrors = true;
  }

  let startPos = this.start,
      startLoc = this.startLoc;
  if (this.type == __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].parenL || this.type == __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].name) this.potentialArrowAt = this.start;
  let left = this.parseMaybeConditional(noIn, refDestructuringErrors);
  if (afterLeftParse) left = afterLeftParse.call(this, left, startPos, startLoc);
  if (this.type.isAssign) {
    this.checkPatternErrors(refDestructuringErrors, true);
    if (!ownDestructuringErrors) __WEBPACK_IMPORTED_MODULE_2__parseutil__["a" /* DestructuringErrors */].call(refDestructuringErrors);
    let node = this.startNodeAt(startPos, startLoc);
    node.operator = this.value;
    node.left = this.type === __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].eq ? this.toAssignable(left) : left;
    refDestructuringErrors.shorthandAssign = -1; // reset because shorthand default was used correctly
    this.checkLVal(left);
    this.next();
    node.right = this.parseMaybeAssign(noIn);
    return this.finishNode(node, "AssignmentExpression");
  } else {
    if (ownDestructuringErrors) this.checkExpressionErrors(refDestructuringErrors, true);
  }
  if (oldParenAssign > -1) refDestructuringErrors.parenthesizedAssign = oldParenAssign;
  if (oldTrailingComma > -1) refDestructuringErrors.trailingComma = oldTrailingComma;
  return left;
};

// Parse a ternary conditional (`?:`) operator.

pp.parseMaybeConditional = function (noIn, refDestructuringErrors) {
  let startPos = this.start,
      startLoc = this.startLoc;
  let expr = this.parseExprOps(noIn, refDestructuringErrors);
  if (this.checkExpressionErrors(refDestructuringErrors)) return expr;
  if (this.eat(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].question)) {
    let node = this.startNodeAt(startPos, startLoc);
    node.test = expr;
    node.consequent = this.parseMaybeAssign();
    this.expect(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].colon);
    node.alternate = this.parseMaybeAssign(noIn);
    return this.finishNode(node, "ConditionalExpression");
  }
  return expr;
};

// Start the precedence parser.

pp.parseExprOps = function (noIn, refDestructuringErrors) {
  let startPos = this.start,
      startLoc = this.startLoc;
  let expr = this.parseMaybeUnary(refDestructuringErrors, false);
  if (this.checkExpressionErrors(refDestructuringErrors)) return expr;
  return expr.start == startPos && expr.type === "ArrowFunctionExpression" ? expr : this.parseExprOp(expr, startPos, startLoc, -1, noIn);
};

// Parse binary operators with the operator precedence parsing
// algorithm. `left` is the left-hand side of the operator.
// `minPrec` provides context that allows the function to stop and
// defer further parser to one of its callers when it encounters an
// operator that has a lower precedence than the set it is parsing.

pp.parseExprOp = function (left, leftStartPos, leftStartLoc, minPrec, noIn) {
  let prec = this.type.binop;
  if (prec != null && (!noIn || this.type !== __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */]._in)) {
    if (prec > minPrec) {
      let logical = this.type === __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].logicalOR || this.type === __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].logicalAND;
      let op = this.value;
      this.next();
      let startPos = this.start,
          startLoc = this.startLoc;
      let right = this.parseExprOp(this.parseMaybeUnary(null, false), startPos, startLoc, prec, noIn);
      let node = this.buildBinary(leftStartPos, leftStartLoc, left, right, op, logical);
      return this.parseExprOp(node, leftStartPos, leftStartLoc, minPrec, noIn);
    }
  }
  return left;
};

pp.buildBinary = function (startPos, startLoc, left, right, op, logical) {
  let node = this.startNodeAt(startPos, startLoc);
  node.left = left;
  node.operator = op;
  node.right = right;
  return this.finishNode(node, logical ? "LogicalExpression" : "BinaryExpression");
};

// Parse unary operators, both prefix and postfix.

pp.parseMaybeUnary = function (refDestructuringErrors, sawUnary) {
  let startPos = this.start,
      startLoc = this.startLoc,
      expr;
  if (this.inAsync && this.isContextual("await")) {
    expr = this.parseAwait(refDestructuringErrors);
    sawUnary = true;
  } else if (this.type.prefix) {
    let node = this.startNode(),
        update = this.type === __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].incDec;
    node.operator = this.value;
    node.prefix = true;
    this.next();
    node.argument = this.parseMaybeUnary(null, true);
    this.checkExpressionErrors(refDestructuringErrors, true);
    if (update) this.checkLVal(node.argument);else if (this.strict && node.operator === "delete" && node.argument.type === "Identifier") this.raiseRecoverable(node.start, "Deleting local variable in strict mode");else sawUnary = true;
    expr = this.finishNode(node, update ? "UpdateExpression" : "UnaryExpression");
  } else {
    expr = this.parseExprSubscripts(refDestructuringErrors);
    if (this.checkExpressionErrors(refDestructuringErrors)) return expr;
    while (this.type.postfix && !this.canInsertSemicolon()) {
      let node = this.startNodeAt(startPos, startLoc);
      node.operator = this.value;
      node.prefix = false;
      node.argument = expr;
      this.checkLVal(expr);
      this.next();
      expr = this.finishNode(node, "UpdateExpression");
    }
  }

  if (!sawUnary && this.eat(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].starstar)) return this.buildBinary(startPos, startLoc, expr, this.parseMaybeUnary(null, false), "**", false);else return expr;
};

// Parse call, dot, and `[]`-subscript expressions.

pp.parseExprSubscripts = function (refDestructuringErrors) {
  let startPos = this.start,
      startLoc = this.startLoc;
  let expr = this.parseExprAtom(refDestructuringErrors);
  let skipArrowSubscripts = expr.type === "ArrowFunctionExpression" && this.input.slice(this.lastTokStart, this.lastTokEnd) !== ")";
  if (this.checkExpressionErrors(refDestructuringErrors) || skipArrowSubscripts) return expr;
  let result = this.parseSubscripts(expr, startPos, startLoc);
  if (refDestructuringErrors && result.type === "MemberExpression") {
    if (refDestructuringErrors.parenthesizedAssign >= result.start) refDestructuringErrors.parenthesizedAssign = -1;
    if (refDestructuringErrors.parenthesizedBind >= result.start) refDestructuringErrors.parenthesizedBind = -1;
  }
  return result;
};

pp.parseSubscripts = function (base, startPos, startLoc, noCalls) {
  let maybeAsyncArrow = this.options.ecmaVersion >= 8 && base.type === "Identifier" && base.name === "async" && this.lastTokEnd == base.end && !this.canInsertSemicolon();
  for (let computed;;) {
    if ((computed = this.eat(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].bracketL)) || this.eat(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].dot)) {
      let node = this.startNodeAt(startPos, startLoc);
      node.object = base;
      node.property = computed ? this.parseExpression() : this.parseIdent(true);
      node.computed = !!computed;
      if (computed) this.expect(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].bracketR);
      base = this.finishNode(node, "MemberExpression");
    } else if (!noCalls && this.eat(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].parenL)) {
      let refDestructuringErrors = new __WEBPACK_IMPORTED_MODULE_2__parseutil__["a" /* DestructuringErrors */](),
          oldYieldPos = this.yieldPos,
          oldAwaitPos = this.awaitPos;
      this.yieldPos = 0;
      this.awaitPos = 0;
      let exprList = this.parseExprList(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].parenR, this.options.ecmaVersion >= 8, false, refDestructuringErrors);
      if (maybeAsyncArrow && !this.canInsertSemicolon() && this.eat(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].arrow)) {
        this.checkPatternErrors(refDestructuringErrors, false);
        this.checkYieldAwaitInDefaultParams();
        this.yieldPos = oldYieldPos;
        this.awaitPos = oldAwaitPos;
        return this.parseArrowExpression(this.startNodeAt(startPos, startLoc), exprList, true);
      }
      this.checkExpressionErrors(refDestructuringErrors, true);
      this.yieldPos = oldYieldPos || this.yieldPos;
      this.awaitPos = oldAwaitPos || this.awaitPos;
      let node = this.startNodeAt(startPos, startLoc);
      node.callee = base;
      node.arguments = exprList;
      base = this.finishNode(node, "CallExpression");
    } else if (this.type === __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].backQuote) {
      let node = this.startNodeAt(startPos, startLoc);
      node.tag = base;
      node.quasi = this.parseTemplate({ isTagged: true });
      base = this.finishNode(node, "TaggedTemplateExpression");
    } else {
      return base;
    }
  }
};

// Parse an atomic expression — either a single token that is an
// expression, an expression started by a keyword like `function` or
// `new`, or an expression wrapped in punctuation like `()`, `[]`,
// or `{}`.

pp.parseExprAtom = function (refDestructuringErrors) {
  let node,
      canBeArrow = this.potentialArrowAt == this.start;
  switch (this.type) {
    case __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */]._super:
      if (!this.inFunction) this.raise(this.start, "'super' outside of function or class");

    case __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */]._this:
      let type = this.type === __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */]._this ? "ThisExpression" : "Super";
      node = this.startNode();
      this.next();
      return this.finishNode(node, type);

    case __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].name:
      let startPos = this.start,
          startLoc = this.startLoc;
      let id = this.parseIdent(this.type !== __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].name);
      if (this.options.ecmaVersion >= 8 && id.name === "async" && !this.canInsertSemicolon() && this.eat(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */]._function)) return this.parseFunction(this.startNodeAt(startPos, startLoc), false, false, true);
      if (canBeArrow && !this.canInsertSemicolon()) {
        if (this.eat(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].arrow)) return this.parseArrowExpression(this.startNodeAt(startPos, startLoc), [id], false);
        if (this.options.ecmaVersion >= 8 && id.name === "async" && this.type === __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].name) {
          id = this.parseIdent();
          if (this.canInsertSemicolon() || !this.eat(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].arrow)) this.unexpected();
          return this.parseArrowExpression(this.startNodeAt(startPos, startLoc), [id], true);
        }
      }
      return id;

    case __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].regexp:
      let value = this.value;
      node = this.parseLiteral(value.value);
      node.regex = { pattern: value.pattern, flags: value.flags };
      return node;

    case __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].num:case __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].string:
      return this.parseLiteral(this.value);

    case __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */]._null:case __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */]._true:case __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */]._false:
      node = this.startNode();
      node.value = this.type === __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */]._null ? null : this.type === __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */]._true;
      node.raw = this.type.keyword;
      this.next();
      return this.finishNode(node, "Literal");

    case __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].parenL:
      let start = this.start,
          expr = this.parseParenAndDistinguishExpression(canBeArrow);
      if (refDestructuringErrors) {
        if (refDestructuringErrors.parenthesizedAssign < 0 && !this.isSimpleAssignTarget(expr)) refDestructuringErrors.parenthesizedAssign = start;
        if (refDestructuringErrors.parenthesizedBind < 0) refDestructuringErrors.parenthesizedBind = start;
      }
      return expr;

    case __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].bracketL:
      node = this.startNode();
      this.next();
      node.elements = this.parseExprList(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].bracketR, true, true, refDestructuringErrors);
      return this.finishNode(node, "ArrayExpression");

    case __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].braceL:
      return this.parseObj(false, refDestructuringErrors);

    case __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */]._function:
      node = this.startNode();
      this.next();
      return this.parseFunction(node, false);

    case __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */]._class:
      return this.parseClass(this.startNode(), false);

    case __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */]._new:
      return this.parseNew();

    case __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].backQuote:
      return this.parseTemplate();

    default:
      this.unexpected();
  }
};

pp.parseLiteral = function (value) {
  let node = this.startNode();
  node.value = value;
  node.raw = this.input.slice(this.start, this.end);
  this.next();
  return this.finishNode(node, "Literal");
};

pp.parseParenExpression = function () {
  this.expect(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].parenL);
  let val = this.parseExpression();
  this.expect(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].parenR);
  return val;
};

pp.parseParenAndDistinguishExpression = function (canBeArrow) {
  let startPos = this.start,
      startLoc = this.startLoc,
      val,
      allowTrailingComma = this.options.ecmaVersion >= 8;
  if (this.options.ecmaVersion >= 6) {
    this.next();

    let innerStartPos = this.start,
        innerStartLoc = this.startLoc;
    let exprList = [],
        first = true,
        lastIsComma = false;
    let refDestructuringErrors = new __WEBPACK_IMPORTED_MODULE_2__parseutil__["a" /* DestructuringErrors */](),
        oldYieldPos = this.yieldPos,
        oldAwaitPos = this.awaitPos,
        spreadStart,
        innerParenStart;
    this.yieldPos = 0;
    this.awaitPos = 0;
    while (this.type !== __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].parenR) {
      first ? first = false : this.expect(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].comma);
      if (allowTrailingComma && this.afterTrailingComma(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].parenR, true)) {
        lastIsComma = true;
        break;
      } else if (this.type === __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].ellipsis) {
        spreadStart = this.start;
        exprList.push(this.parseParenItem(this.parseRestBinding()));
        if (this.type === __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].comma) this.raise(this.start, "Comma is not permitted after the rest element");
        break;
      } else {
        if (this.type === __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].parenL && !innerParenStart) {
          innerParenStart = this.start;
        }
        exprList.push(this.parseMaybeAssign(false, refDestructuringErrors, this.parseParenItem));
      }
    }
    let innerEndPos = this.start,
        innerEndLoc = this.startLoc;
    this.expect(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].parenR);

    if (canBeArrow && !this.canInsertSemicolon() && this.eat(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].arrow)) {
      this.checkPatternErrors(refDestructuringErrors, false);
      this.checkYieldAwaitInDefaultParams();
      if (innerParenStart) this.unexpected(innerParenStart);
      this.yieldPos = oldYieldPos;
      this.awaitPos = oldAwaitPos;
      return this.parseParenArrowList(startPos, startLoc, exprList);
    }

    if (!exprList.length || lastIsComma) this.unexpected(this.lastTokStart);
    if (spreadStart) this.unexpected(spreadStart);
    this.checkExpressionErrors(refDestructuringErrors, true);
    this.yieldPos = oldYieldPos || this.yieldPos;
    this.awaitPos = oldAwaitPos || this.awaitPos;

    if (exprList.length > 1) {
      val = this.startNodeAt(innerStartPos, innerStartLoc);
      val.expressions = exprList;
      this.finishNodeAt(val, "SequenceExpression", innerEndPos, innerEndLoc);
    } else {
      val = exprList[0];
    }
  } else {
    val = this.parseParenExpression();
  }

  if (this.options.preserveParens) {
    let par = this.startNodeAt(startPos, startLoc);
    par.expression = val;
    return this.finishNode(par, "ParenthesizedExpression");
  } else {
    return val;
  }
};

pp.parseParenItem = function (item) {
  return item;
};

pp.parseParenArrowList = function (startPos, startLoc, exprList) {
  return this.parseArrowExpression(this.startNodeAt(startPos, startLoc), exprList);
};

// New's precedence is slightly tricky. It must allow its argument to
// be a `[]` or dot subscript expression, but not a call — at least,
// not without wrapping it in parentheses. Thus, it uses the noCalls
// argument to parseSubscripts to prevent it from consuming the
// argument list.

const empty = [];

pp.parseNew = function () {
  let node = this.startNode();
  let meta = this.parseIdent(true);
  if (this.options.ecmaVersion >= 6 && this.eat(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].dot)) {
    node.meta = meta;
    node.property = this.parseIdent(true);
    if (node.property.name !== "target") this.raiseRecoverable(node.property.start, "The only valid meta property for new is new.target");
    if (!this.inFunction) this.raiseRecoverable(node.start, "new.target can only be used in functions");
    return this.finishNode(node, "MetaProperty");
  }
  let startPos = this.start,
      startLoc = this.startLoc;
  node.callee = this.parseSubscripts(this.parseExprAtom(), startPos, startLoc, true);
  if (this.eat(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].parenL)) node.arguments = this.parseExprList(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].parenR, this.options.ecmaVersion >= 8, false);else node.arguments = empty;
  return this.finishNode(node, "NewExpression");
};

// Parse template expression.

pp.parseTemplateElement = function (_ref) {
  let isTagged = _ref.isTagged;

  let elem = this.startNode();
  if (this.type === __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].invalidTemplate) {
    if (!isTagged) {
      this.raiseRecoverable(this.start, "Bad escape sequence in untagged template literal");
    }
    elem.value = {
      raw: this.value,
      cooked: null
    };
  } else {
    elem.value = {
      raw: this.input.slice(this.start, this.end).replace(/\r\n?/g, "\n"),
      cooked: this.value
    };
  }
  this.next();
  elem.tail = this.type === __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].backQuote;
  return this.finishNode(elem, "TemplateElement");
};

pp.parseTemplate = function () {
  var _ref2 = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : {},
      _ref2$isTagged = _ref2.isTagged;

  let isTagged = _ref2$isTagged === undefined ? false : _ref2$isTagged;

  let node = this.startNode();
  this.next();
  node.expressions = [];
  let curElt = this.parseTemplateElement({ isTagged });
  node.quasis = [curElt];
  while (!curElt.tail) {
    this.expect(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].dollarBraceL);
    node.expressions.push(this.parseExpression());
    this.expect(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].braceR);
    node.quasis.push(curElt = this.parseTemplateElement({ isTagged }));
  }
  this.next();
  return this.finishNode(node, "TemplateLiteral");
};

// Parse an object literal or binding pattern.

pp.isAsyncProp = function (prop) {
  return !prop.computed && prop.key.type === "Identifier" && prop.key.name === "async" && (this.type === __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].name || this.type === __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].num || this.type === __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].string || this.type === __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].bracketL || this.type.keyword) && !__WEBPACK_IMPORTED_MODULE_3__whitespace__["b" /* lineBreak */].test(this.input.slice(this.lastTokEnd, this.start));
};

pp.parseObj = function (isPattern, refDestructuringErrors) {
  let node = this.startNode(),
      first = true,
      propHash = {};
  node.properties = [];
  this.next();
  while (!this.eat(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].braceR)) {
    if (!first) {
      this.expect(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].comma);
      if (this.afterTrailingComma(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].braceR)) break;
    } else first = false;

    let prop = this.startNode(),
        isGenerator,
        isAsync,
        startPos,
        startLoc;
    if (this.options.ecmaVersion >= 6) {
      prop.method = false;
      prop.shorthand = false;
      if (isPattern || refDestructuringErrors) {
        startPos = this.start;
        startLoc = this.startLoc;
      }
      if (!isPattern) isGenerator = this.eat(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].star);
    }
    this.parsePropertyName(prop);
    if (!isPattern && this.options.ecmaVersion >= 8 && !isGenerator && this.isAsyncProp(prop)) {
      isAsync = true;
      this.parsePropertyName(prop, refDestructuringErrors);
    } else {
      isAsync = false;
    }
    this.parsePropertyValue(prop, isPattern, isGenerator, isAsync, startPos, startLoc, refDestructuringErrors);
    this.checkPropClash(prop, propHash);
    node.properties.push(this.finishNode(prop, "Property"));
  }
  return this.finishNode(node, isPattern ? "ObjectPattern" : "ObjectExpression");
};

pp.parsePropertyValue = function (prop, isPattern, isGenerator, isAsync, startPos, startLoc, refDestructuringErrors) {
  if ((isGenerator || isAsync) && this.type === __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].colon) this.unexpected();

  if (this.eat(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].colon)) {
    prop.value = isPattern ? this.parseMaybeDefault(this.start, this.startLoc) : this.parseMaybeAssign(false, refDestructuringErrors);
    prop.kind = "init";
  } else if (this.options.ecmaVersion >= 6 && this.type === __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].parenL) {
    if (isPattern) this.unexpected();
    prop.kind = "init";
    prop.method = true;
    prop.value = this.parseMethod(isGenerator, isAsync);
  } else if (this.options.ecmaVersion >= 5 && !prop.computed && prop.key.type === "Identifier" && (prop.key.name === "get" || prop.key.name === "set") && this.type != __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].comma && this.type != __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].braceR) {
    if (isGenerator || isAsync || isPattern) this.unexpected();
    prop.kind = prop.key.name;
    this.parsePropertyName(prop);
    prop.value = this.parseMethod(false);
    let paramCount = prop.kind === "get" ? 0 : 1;
    if (prop.value.params.length !== paramCount) {
      let start = prop.value.start;
      if (prop.kind === "get") this.raiseRecoverable(start, "getter should have no params");else this.raiseRecoverable(start, "setter should have exactly one param");
    } else {
      if (prop.kind === "set" && prop.value.params[0].type === "RestElement") this.raiseRecoverable(prop.value.params[0].start, "Setter cannot use rest params");
    }
  } else if (this.options.ecmaVersion >= 6 && !prop.computed && prop.key.type === "Identifier") {
    this.checkUnreserved(prop.key);
    prop.kind = "init";
    if (isPattern) {
      prop.value = this.parseMaybeDefault(startPos, startLoc, prop.key);
    } else if (this.type === __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].eq && refDestructuringErrors) {
      if (refDestructuringErrors.shorthandAssign < 0) refDestructuringErrors.shorthandAssign = this.start;
      prop.value = this.parseMaybeDefault(startPos, startLoc, prop.key);
    } else {
      prop.value = prop.key;
    }
    prop.shorthand = true;
  } else this.unexpected();
};

pp.parsePropertyName = function (prop) {
  if (this.options.ecmaVersion >= 6) {
    if (this.eat(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].bracketL)) {
      prop.computed = true;
      prop.key = this.parseMaybeAssign();
      this.expect(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].bracketR);
      return prop.key;
    } else {
      prop.computed = false;
    }
  }
  return prop.key = this.type === __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].num || this.type === __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].string ? this.parseExprAtom() : this.parseIdent(true);
};

// Initialize empty function node.

pp.initFunction = function (node) {
  node.id = null;
  if (this.options.ecmaVersion >= 6) {
    node.generator = false;
    node.expression = false;
  }
  if (this.options.ecmaVersion >= 8) node.async = false;
};

// Parse object or class method.

pp.parseMethod = function (isGenerator, isAsync) {
  let node = this.startNode(),
      oldInGen = this.inGenerator,
      oldInAsync = this.inAsync,
      oldYieldPos = this.yieldPos,
      oldAwaitPos = this.awaitPos,
      oldInFunc = this.inFunction;

  this.initFunction(node);
  if (this.options.ecmaVersion >= 6) node.generator = isGenerator;
  if (this.options.ecmaVersion >= 8) node.async = !!isAsync;

  this.inGenerator = node.generator;
  this.inAsync = node.async;
  this.yieldPos = 0;
  this.awaitPos = 0;
  this.inFunction = true;
  this.enterFunctionScope();

  this.expect(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].parenL);
  node.params = this.parseBindingList(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].parenR, false, this.options.ecmaVersion >= 8);
  this.checkYieldAwaitInDefaultParams();
  this.parseFunctionBody(node, false);

  this.inGenerator = oldInGen;
  this.inAsync = oldInAsync;
  this.yieldPos = oldYieldPos;
  this.awaitPos = oldAwaitPos;
  this.inFunction = oldInFunc;
  return this.finishNode(node, "FunctionExpression");
};

// Parse arrow function expression with given parameters.

pp.parseArrowExpression = function (node, params, isAsync) {
  let oldInGen = this.inGenerator,
      oldInAsync = this.inAsync,
      oldYieldPos = this.yieldPos,
      oldAwaitPos = this.awaitPos,
      oldInFunc = this.inFunction;

  this.enterFunctionScope();
  this.initFunction(node);
  if (this.options.ecmaVersion >= 8) node.async = !!isAsync;

  this.inGenerator = false;
  this.inAsync = node.async;
  this.yieldPos = 0;
  this.awaitPos = 0;
  this.inFunction = true;

  node.params = this.toAssignableList(params, true);
  this.parseFunctionBody(node, true);

  this.inGenerator = oldInGen;
  this.inAsync = oldInAsync;
  this.yieldPos = oldYieldPos;
  this.awaitPos = oldAwaitPos;
  this.inFunction = oldInFunc;
  return this.finishNode(node, "ArrowFunctionExpression");
};

// Parse function body and check parameters.

pp.parseFunctionBody = function (node, isArrowFunction) {
  let isExpression = isArrowFunction && this.type !== __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].braceL;
  let oldStrict = this.strict,
      useStrict = false;

  if (isExpression) {
    node.body = this.parseMaybeAssign();
    node.expression = true;
    this.checkParams(node, false);
  } else {
    let nonSimple = this.options.ecmaVersion >= 7 && !this.isSimpleParamList(node.params);
    if (!oldStrict || nonSimple) {
      useStrict = this.strictDirective(this.end);
      // If this is a strict mode function, verify that argument names
      // are not repeated, and it does not try to bind the words `eval`
      // or `arguments`.
      if (useStrict && nonSimple) this.raiseRecoverable(node.start, "Illegal 'use strict' directive in function with non-simple parameter list");
    }
    // Start a new scope with regard to labels and the `inFunction`
    // flag (restore them to their old value afterwards).
    let oldLabels = this.labels;
    this.labels = [];
    if (useStrict) this.strict = true;

    // Add the params to varDeclaredNames to ensure that an error is thrown
    // if a let/const declaration in the function clashes with one of the params.
    this.checkParams(node, !oldStrict && !useStrict && !isArrowFunction && this.isSimpleParamList(node.params));
    node.body = this.parseBlock(false);
    node.expression = false;
    this.labels = oldLabels;
  }
  this.exitFunctionScope();

  if (this.strict && node.id) {
    // Ensure the function name isn't a forbidden identifier in strict mode, e.g. 'eval'
    this.checkLVal(node.id, "none");
  }
  this.strict = oldStrict;
};

pp.isSimpleParamList = function (params) {
  for (let _i = 0; _i < params.length; _i++) {
    let param = params[_i];
    if (param.type !== "Identifier") return false;
  }

  return true;
};

// Checks function params for various disallowed patterns such as using "eval"
// or "arguments" and duplicate parameters.

pp.checkParams = function (node, allowDuplicates) {
  let nameHash = {};

  for (let _i2 = 0, _node$params = node.params; _i2 < _node$params.length; _i2++) {
    let param = _node$params[_i2];
    this.checkLVal(param, "var", allowDuplicates ? null : nameHash);
  }
};

// Parses a comma-separated list of expressions, and returns them as
// an array. `close` is the token type that ends the list, and
// `allowEmpty` can be turned on to allow subsequent commas with
// nothing in between them to be parsed as `null` (which is needed
// for array literals).

pp.parseExprList = function (close, allowTrailingComma, allowEmpty, refDestructuringErrors) {
  let elts = [],
      first = true;
  while (!this.eat(close)) {
    if (!first) {
      this.expect(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].comma);
      if (allowTrailingComma && this.afterTrailingComma(close)) break;
    } else first = false;

    let elt;
    if (allowEmpty && this.type === __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].comma) elt = null;else if (this.type === __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].ellipsis) {
      elt = this.parseSpread(refDestructuringErrors);
      if (refDestructuringErrors && this.type === __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].comma && refDestructuringErrors.trailingComma < 0) refDestructuringErrors.trailingComma = this.start;
    } else {
      elt = this.parseMaybeAssign(false, refDestructuringErrors);
    }
    elts.push(elt);
  }
  return elts;
};

// Parse the next token as an identifier. If `liberal` is true (used
// when parsing properties), it will also convert keywords into
// identifiers.

pp.checkUnreserved = function (_ref3) {
  let start = _ref3.start,
      end = _ref3.end,
      name = _ref3.name;

  if (this.inGenerator && name === "yield") this.raiseRecoverable(start, "Can not use 'yield' as identifier inside a generator");
  if (this.inAsync && name === "await") this.raiseRecoverable(start, "Can not use 'await' as identifier inside an async function");
  if (this.isKeyword(name)) this.raise(start, `Unexpected keyword '${name}'`);
  if (this.options.ecmaVersion < 6 && this.input.slice(start, end).indexOf("\\") != -1) return;
  const re = this.strict ? this.reservedWordsStrict : this.reservedWords;
  if (re.test(name)) this.raiseRecoverable(start, `The keyword '${name}' is reserved`);
};

pp.parseIdent = function (liberal, isBinding) {
  let node = this.startNode();
  if (liberal && this.options.allowReserved == "never") liberal = false;
  if (this.type === __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].name) {
    node.name = this.value;
  } else if (this.type.keyword) {
    node.name = this.type.keyword;
  } else {
    this.unexpected();
  }
  this.next();
  this.finishNode(node, "Identifier");
  if (!liberal) this.checkUnreserved(node);
  return node;
};

// Parses yield expression inside generator.

pp.parseYield = function () {
  if (!this.yieldPos) this.yieldPos = this.start;

  let node = this.startNode();
  this.next();
  if (this.type == __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].semi || this.canInsertSemicolon() || this.type != __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].star && !this.type.startsExpr) {
    node.delegate = false;
    node.argument = null;
  } else {
    node.delegate = this.eat(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].star);
    node.argument = this.parseMaybeAssign();
  }
  return this.finishNode(node, "YieldExpression");
};

pp.parseAwait = function () {
  if (!this.awaitPos) this.awaitPos = this.start;

  let node = this.startNode();
  this.next();
  node.argument = this.parseMaybeUnary(null, true);
  return this.finishNode(node, "AwaitExpression");
};

/***/ }),
/* 112 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (immutable) */ __webpack_exports__["a"] = getOptions;
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__util__ = __webpack_require__(29);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__locutil__ = __webpack_require__(30);



// A second optional argument can be given to further configure
// the parser process. These options are recognized:

const defaultOptions = {
  // `ecmaVersion` indicates the ECMAScript version to parse. Must
  // be either 3, 5, 6 (2015), 7 (2016), or 8 (2017). This influences support
  // for strict mode, the set of reserved words, and support for
  // new syntax features. The default is 7.
  ecmaVersion: 7,
  // `sourceType` indicates the mode the code should be parsed in.
  // Can be either `"script"` or `"module"`. This influences global
  // strict mode and parsing of `import` and `export` declarations.
  sourceType: "script",
  // `onInsertedSemicolon` can be a callback that will be called
  // when a semicolon is automatically inserted. It will be passed
  // th position of the comma as an offset, and if `locations` is
  // enabled, it is given the location as a `{line, column}` object
  // as second argument.
  onInsertedSemicolon: null,
  // `onTrailingComma` is similar to `onInsertedSemicolon`, but for
  // trailing commas.
  onTrailingComma: null,
  // By default, reserved words are only enforced if ecmaVersion >= 5.
  // Set `allowReserved` to a boolean value to explicitly turn this on
  // an off. When this option has the value "never", reserved words
  // and keywords can also not be used as property names.
  allowReserved: null,
  // When enabled, a return at the top level is not considered an
  // error.
  allowReturnOutsideFunction: false,
  // When enabled, import/export statements are not constrained to
  // appearing at the top of the program.
  allowImportExportEverywhere: false,
  // When enabled, hashbang directive in the beginning of file
  // is allowed and treated as a line comment.
  allowHashBang: false,
  // When `locations` is on, `loc` properties holding objects with
  // `start` and `end` properties in `{line, column}` form (with
  // line being 1-based and column 0-based) will be attached to the
  // nodes.
  locations: false,
  // A function can be passed as `onToken` option, which will
  // cause Acorn to call that function with object in the same
  // format as tokens returned from `tokenizer().getToken()`. Note
  // that you are not allowed to call the parser from the
  // callback—that will corrupt its internal state.
  onToken: null,
  // A function can be passed as `onComment` option, which will
  // cause Acorn to call that function with `(block, text, start,
  // end)` parameters whenever a comment is skipped. `block` is a
  // boolean indicating whether this is a block (`/* */`) comment,
  // `text` is the content of the comment, and `start` and `end` are
  // character offsets that denote the start and end of the comment.
  // When the `locations` option is on, two more parameters are
  // passed, the full `{line, column}` locations of the start and
  // end of the comments. Note that you are not allowed to call the
  // parser from the callback—that will corrupt its internal state.
  onComment: null,
  // Nodes have their start and end characters offsets recorded in
  // `start` and `end` properties (directly on the node, rather than
  // the `loc` object, which holds line/column data. To also add a
  // [semi-standardized][range] `range` property holding a `[start,
  // end]` array with the same numbers, set the `ranges` option to
  // `true`.
  //
  // [range]: https://bugzilla.mozilla.org/show_bug.cgi?id=745678
  ranges: false,
  // It is possible to parse multiple files into a single AST by
  // passing the tree produced by parsing the first file as
  // `program` option in subsequent parses. This will add the
  // toplevel forms of the parsed file to the `Program` (top) node
  // of an existing parse tree.
  program: null,
  // When `locations` is on, you can pass this to record the source
  // file in every node's `loc` object.
  sourceFile: null,
  // This value, if given, is stored in every node, whether
  // `locations` is on or off.
  directSourceFile: null,
  // When enabled, parenthesized expressions are represented by
  // (non-standard) ParenthesizedExpression nodes
  preserveParens: false,
  plugins: {}

  // Interpret and default an options object

};
/* unused harmony export defaultOptions */
function getOptions(opts) {
  let options = {};

  for (let opt in defaultOptions) options[opt] = opts && Object(__WEBPACK_IMPORTED_MODULE_0__util__["a" /* has */])(opts, opt) ? opts[opt] : defaultOptions[opt];

  if (options.ecmaVersion >= 2015) options.ecmaVersion -= 2009;

  if (options.allowReserved == null) options.allowReserved = options.ecmaVersion < 5;

  if (Object(__WEBPACK_IMPORTED_MODULE_0__util__["b" /* isArray */])(options.onToken)) {
    let tokens = options.onToken;
    options.onToken = function (token) {
      return tokens.push(token);
    };
  }
  if (Object(__WEBPACK_IMPORTED_MODULE_0__util__["b" /* isArray */])(options.onComment)) options.onComment = pushComment(options, options.onComment);

  return options;
}

function pushComment(options, array) {
  return function (block, text, start, end, startLoc, endLoc) {
    let comment = {
      type: block ? "Block" : "Line",
      value: text,
      start: start,
      end: end
    };
    if (options.locations) comment.loc = new __WEBPACK_IMPORTED_MODULE_1__locutil__["b" /* SourceLocation */](this, startLoc, endLoc);
    if (options.ranges) comment.range = [start, end];
    array.push(comment);
  };
}

/***/ }),
/* 113 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__state__ = __webpack_require__(6);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__locutil__ = __webpack_require__(30);



const pp = __WEBPACK_IMPORTED_MODULE_0__state__["a" /* Parser */].prototype;

// This function is used to raise exceptions on parse errors. It
// takes an offset integer (into the current `input`) to indicate
// the location of the error, attaches the position to the end
// of the error message, and then raises a `SyntaxError` with that
// message.

pp.raise = function (pos, message) {
  let loc = Object(__WEBPACK_IMPORTED_MODULE_1__locutil__["c" /* getLineInfo */])(this.input, pos);
  message += " (" + loc.line + ":" + loc.column + ")";
  let err = new SyntaxError(message);
  err.pos = pos;err.loc = loc;err.raisedAt = this.pos;
  throw err;
};

pp.raiseRecoverable = pp.raise;

pp.curPosition = function () {
  if (this.options.locations) {
    return new __WEBPACK_IMPORTED_MODULE_1__locutil__["a" /* Position */](this.curLine, this.pos - this.lineStart);
  }
};

/***/ }),
/* 114 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__tokentype__ = __webpack_require__(3);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__state__ = __webpack_require__(6);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__util__ = __webpack_require__(29);




const pp = __WEBPACK_IMPORTED_MODULE_1__state__["a" /* Parser */].prototype;

// Convert existing expression atom to assignable pattern
// if possible.

pp.toAssignable = function (node, isBinding) {
  if (this.options.ecmaVersion >= 6 && node) {
    switch (node.type) {
      case "Identifier":
        if (this.inAsync && node.name === "await") this.raise(node.start, "Can not use 'await' as identifier inside an async function");
        break;

      case "ObjectPattern":
      case "ArrayPattern":
        break;

      case "ObjectExpression":
        node.type = "ObjectPattern";

        for (let _i = 0, _node$properties = node.properties; _i < _node$properties.length; _i++) {
          let prop = _node$properties[_i];
          if (prop.kind !== "init") this.raise(prop.key.start, "Object pattern can't contain getter or setter");
          this.toAssignable(prop.value, isBinding);
        }

        break;

      case "ArrayExpression":
        node.type = "ArrayPattern";
        this.toAssignableList(node.elements, isBinding);
        break;

      case "AssignmentExpression":
        if (node.operator === "=") {
          node.type = "AssignmentPattern";
          delete node.operator;
          this.toAssignable(node.left, isBinding);
          // falls through to AssignmentPattern
        } else {
          this.raise(node.left.end, "Only '=' operator can be used for specifying default value.");
          break;
        }

      case "AssignmentPattern":
        break;

      case "ParenthesizedExpression":
        this.toAssignable(node.expression, isBinding);
        break;

      case "MemberExpression":
        if (!isBinding) break;

      default:
        this.raise(node.start, "Assigning to rvalue");
    }
  }
  return node;
};

// Convert list of expression atoms to binding list.

pp.toAssignableList = function (exprList, isBinding) {
  let end = exprList.length;
  if (end) {
    let last = exprList[end - 1];
    if (last && last.type == "RestElement") {
      --end;
    } else if (last && last.type == "SpreadElement") {
      last.type = "RestElement";
      let arg = last.argument;
      this.toAssignable(arg, isBinding);
      --end;
    }

    if (this.options.ecmaVersion === 6 && isBinding && last && last.type === "RestElement" && last.argument.type !== "Identifier") this.unexpected(last.argument.start);
  }
  for (let i = 0; i < end; i++) {
    let elt = exprList[i];
    if (elt) this.toAssignable(elt, isBinding);
  }
  return exprList;
};

// Parses spread element.

pp.parseSpread = function (refDestructuringErrors) {
  let node = this.startNode();
  this.next();
  node.argument = this.parseMaybeAssign(false, refDestructuringErrors);
  return this.finishNode(node, "SpreadElement");
};

pp.parseRestBinding = function () {
  let node = this.startNode();
  this.next();

  // RestElement inside of a function parameter must be an identifier
  if (this.options.ecmaVersion === 6 && this.type !== __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].name) this.unexpected();

  node.argument = this.parseBindingAtom();

  return this.finishNode(node, "RestElement");
};

// Parses lvalue (assignable) atom.

pp.parseBindingAtom = function () {
  if (this.options.ecmaVersion < 6) return this.parseIdent();
  switch (this.type) {
    case __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].name:
      return this.parseIdent();

    case __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].bracketL:
      let node = this.startNode();
      this.next();
      node.elements = this.parseBindingList(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].bracketR, true, true);
      return this.finishNode(node, "ArrayPattern");

    case __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].braceL:
      return this.parseObj(true);

    default:
      this.unexpected();
  }
};

pp.parseBindingList = function (close, allowEmpty, allowTrailingComma) {
  let elts = [],
      first = true;
  while (!this.eat(close)) {
    if (first) first = false;else this.expect(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].comma);
    if (allowEmpty && this.type === __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].comma) {
      elts.push(null);
    } else if (allowTrailingComma && this.afterTrailingComma(close)) {
      break;
    } else if (this.type === __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].ellipsis) {
      let rest = this.parseRestBinding();
      this.parseBindingListItem(rest);
      elts.push(rest);
      if (this.type === __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].comma) this.raise(this.start, "Comma is not permitted after the rest element");
      this.expect(close);
      break;
    } else {
      let elem = this.parseMaybeDefault(this.start, this.startLoc);
      this.parseBindingListItem(elem);
      elts.push(elem);
    }
  }
  return elts;
};

pp.parseBindingListItem = function (param) {
  return param;
};

// Parses assignment pattern around given atom if possible.

pp.parseMaybeDefault = function (startPos, startLoc, left) {
  left = left || this.parseBindingAtom();
  if (this.options.ecmaVersion < 6 || !this.eat(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].eq)) return left;
  let node = this.startNodeAt(startPos, startLoc);
  node.left = left;
  node.right = this.parseMaybeAssign();
  return this.finishNode(node, "AssignmentPattern");
};

// Verify that a node is an lval — something that can be assigned
// to.
// bindingType can be either:
// 'var' indicating that the lval creates a 'var' binding
// 'let' indicating that the lval creates a lexical ('let' or 'const') binding
// 'none' indicating that the binding should be checked for illegal identifiers, but not for duplicate references

pp.checkLVal = function (expr, bindingType, checkClashes) {
  switch (expr.type) {
    case "Identifier":
      if (this.strict && this.reservedWordsStrictBind.test(expr.name)) this.raiseRecoverable(expr.start, (bindingType ? "Binding " : "Assigning to ") + expr.name + " in strict mode");
      if (checkClashes) {
        if (Object(__WEBPACK_IMPORTED_MODULE_2__util__["a" /* has */])(checkClashes, expr.name)) this.raiseRecoverable(expr.start, "Argument name clash");
        checkClashes[expr.name] = true;
      }
      if (bindingType && bindingType !== "none") {
        if (bindingType === "var" && !this.canDeclareVarName(expr.name) || bindingType !== "var" && !this.canDeclareLexicalName(expr.name)) {
          this.raiseRecoverable(expr.start, `Identifier '${expr.name}' has already been declared`);
        }
        if (bindingType === "var") {
          this.declareVarName(expr.name);
        } else {
          this.declareLexicalName(expr.name);
        }
      }
      break;

    case "MemberExpression":
      if (bindingType) this.raiseRecoverable(expr.start, (bindingType ? "Binding" : "Assigning to") + " member expression");
      break;

    case "ObjectPattern":
      for (let _i2 = 0, _expr$properties = expr.properties; _i2 < _expr$properties.length; _i2++) {
        let prop = _expr$properties[_i2];
        this.checkLVal(prop.value, bindingType, checkClashes);
      }

      break;

    case "ArrayPattern":
      for (let _i3 = 0, _expr$elements = expr.elements; _i3 < _expr$elements.length; _i3++) {
        let elem = _expr$elements[_i3];
        if (elem) this.checkLVal(elem, bindingType, checkClashes);
      }

      break;

    case "AssignmentPattern":
      this.checkLVal(expr.left, bindingType, checkClashes);
      break;

    case "RestElement":
      this.checkLVal(expr.argument, bindingType, checkClashes);
      break;

    case "ParenthesizedExpression":
      this.checkLVal(expr.expression, bindingType, checkClashes);
      break;

    default:
      this.raise(expr.start, (bindingType ? "Binding" : "Assigning to") + " rvalue");
  }
};

/***/ }),
/* 115 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__state__ = __webpack_require__(6);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__locutil__ = __webpack_require__(30);



class Node {
  constructor(parser, pos, loc) {
    this.type = "";
    this.start = pos;
    this.end = 0;
    if (parser.options.locations) this.loc = new __WEBPACK_IMPORTED_MODULE_1__locutil__["b" /* SourceLocation */](parser, loc);
    if (parser.options.directSourceFile) this.sourceFile = parser.options.directSourceFile;
    if (parser.options.ranges) this.range = [pos, 0];
  }
}
/* unused harmony export Node */


// Start an AST node, attaching a start offset.

const pp = __WEBPACK_IMPORTED_MODULE_0__state__["a" /* Parser */].prototype;

pp.startNode = function () {
  return new Node(this, this.start, this.startLoc);
};

pp.startNodeAt = function (pos, loc) {
  return new Node(this, pos, loc);
};

// Finish an AST node, adding `type` and `end` properties.

function finishNodeAt(node, type, pos, loc) {
  node.type = type;
  node.end = pos;
  if (this.options.locations) node.loc.end = loc;
  if (this.options.ranges) node.range[1] = pos;
  return node;
}

pp.finishNode = function (node, type) {
  return finishNodeAt.call(this, node, type, this.lastTokEnd, this.lastTokEndLoc);
};

// Finish node at given position

pp.finishNodeAt = function (node, type, pos, loc) {
  return finishNodeAt.call(this, node, type, pos, loc);
};

/***/ }),
/* 116 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__state__ = __webpack_require__(6);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__util__ = __webpack_require__(29);



const pp = __WEBPACK_IMPORTED_MODULE_0__state__["a" /* Parser */].prototype;

// Object.assign polyfill
const assign = Object.assign || function (target) {
  for (var _len = arguments.length, sources = Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
    sources[_key - 1] = arguments[_key];
  }

  for (let _i = 0; _i < sources.length; _i++) {
    let source = sources[_i];
    for (const key in source) {
      if (Object(__WEBPACK_IMPORTED_MODULE_1__util__["a" /* has */])(source, key)) {
        target[key] = source[key];
      }
    }
  }

  return target;
};

// The functions in this module keep track of declared variables in the current scope in order to detect duplicate variable names.

pp.enterFunctionScope = function () {
  // var: a hash of var-declared names in the current lexical scope
  // lexical: a hash of lexically-declared names in the current lexical scope
  // childVar: a hash of var-declared names in all child lexical scopes of the current lexical scope (within the current function scope)
  // parentLexical: a hash of lexically-declared names in all parent lexical scopes of the current lexical scope (within the current function scope)
  this.scopeStack.push({ var: {}, lexical: {}, childVar: {}, parentLexical: {} });
};

pp.exitFunctionScope = function () {
  this.scopeStack.pop();
};

pp.enterLexicalScope = function () {
  const parentScope = this.scopeStack[this.scopeStack.length - 1];
  const childScope = { var: {}, lexical: {}, childVar: {}, parentLexical: {} };

  this.scopeStack.push(childScope);
  assign(childScope.parentLexical, parentScope.lexical, parentScope.parentLexical);
};

pp.exitLexicalScope = function () {
  const childScope = this.scopeStack.pop();
  const parentScope = this.scopeStack[this.scopeStack.length - 1];

  assign(parentScope.childVar, childScope.var, childScope.childVar);
};

/**
 * A name can be declared with `var` if there are no variables with the same name declared with `let`/`const`
 * in the current lexical scope or any of the parent lexical scopes in this function.
 */
pp.canDeclareVarName = function (name) {
  const currentScope = this.scopeStack[this.scopeStack.length - 1];

  return !Object(__WEBPACK_IMPORTED_MODULE_1__util__["a" /* has */])(currentScope.lexical, name) && !Object(__WEBPACK_IMPORTED_MODULE_1__util__["a" /* has */])(currentScope.parentLexical, name);
};

/**
 * A name can be declared with `let`/`const` if there are no variables with the same name declared with `let`/`const`
 * in the current scope, and there are no variables with the same name declared with `var` in the current scope or in
 * any child lexical scopes in this function.
 */
pp.canDeclareLexicalName = function (name) {
  const currentScope = this.scopeStack[this.scopeStack.length - 1];

  return !Object(__WEBPACK_IMPORTED_MODULE_1__util__["a" /* has */])(currentScope.lexical, name) && !Object(__WEBPACK_IMPORTED_MODULE_1__util__["a" /* has */])(currentScope.var, name) && !Object(__WEBPACK_IMPORTED_MODULE_1__util__["a" /* has */])(currentScope.childVar, name);
};

pp.declareVarName = function (name) {
  this.scopeStack[this.scopeStack.length - 1].var[name] = true;
};

pp.declareLexicalName = function (name) {
  this.scopeStack[this.scopeStack.length - 1].lexical[name] = true;
};

/***/ }),
/* 117 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__tokentype__ = __webpack_require__(3);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__state__ = __webpack_require__(6);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__whitespace__ = __webpack_require__(13);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__identifier__ = __webpack_require__(41);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__util__ = __webpack_require__(29);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__parseutil__ = __webpack_require__(70);







const pp = __WEBPACK_IMPORTED_MODULE_1__state__["a" /* Parser */].prototype;

// ### Statement parsing

// Parse a program. Initializes the parser, reads any number of
// statements, and wraps them in a Program node.  Optionally takes a
// `program` argument.  If present, the statements will be appended
// to its body instead of creating a new node.

pp.parseTopLevel = function (node) {
  let exports = {};
  if (!node.body) node.body = [];
  while (this.type !== __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].eof) {
    let stmt = this.parseStatement(true, true, exports);
    node.body.push(stmt);
  }
  this.next();
  if (this.options.ecmaVersion >= 6) {
    node.sourceType = this.options.sourceType;
  }
  return this.finishNode(node, "Program");
};

const loopLabel = { kind: "loop" },
      switchLabel = { kind: "switch" };

pp.isLet = function () {
  if (this.type !== __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].name || this.options.ecmaVersion < 6 || this.value != "let") return false;
  __WEBPACK_IMPORTED_MODULE_2__whitespace__["e" /* skipWhiteSpace */].lastIndex = this.pos;
  let skip = __WEBPACK_IMPORTED_MODULE_2__whitespace__["e" /* skipWhiteSpace */].exec(this.input);
  let next = this.pos + skip[0].length,
      nextCh = this.input.charCodeAt(next);
  if (nextCh === 91 || nextCh == 123) return true; // '{' and '['
  if (Object(__WEBPACK_IMPORTED_MODULE_3__identifier__["b" /* isIdentifierStart */])(nextCh, true)) {
    let pos = next + 1;
    while (Object(__WEBPACK_IMPORTED_MODULE_3__identifier__["a" /* isIdentifierChar */])(this.input.charCodeAt(pos), true)) ++pos;
    let ident = this.input.slice(next, pos);
    if (!this.isKeyword(ident)) return true;
  }
  return false;
};

// check 'async [no LineTerminator here] function'
// - 'async /*foo*/ function' is OK.
// - 'async /*\n*/ function' is invalid.
pp.isAsyncFunction = function () {
  if (this.type !== __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].name || this.options.ecmaVersion < 8 || this.value != "async") return false;

  __WEBPACK_IMPORTED_MODULE_2__whitespace__["e" /* skipWhiteSpace */].lastIndex = this.pos;
  let skip = __WEBPACK_IMPORTED_MODULE_2__whitespace__["e" /* skipWhiteSpace */].exec(this.input);
  let next = this.pos + skip[0].length;
  return !__WEBPACK_IMPORTED_MODULE_2__whitespace__["b" /* lineBreak */].test(this.input.slice(this.pos, next)) && this.input.slice(next, next + 8) === "function" && (next + 8 == this.input.length || !Object(__WEBPACK_IMPORTED_MODULE_3__identifier__["a" /* isIdentifierChar */])(this.input.charAt(next + 8)));
};

// Parse a single statement.
//
// If expecting a statement and finding a slash operator, parse a
// regular expression literal. This is to handle cases like
// `if (foo) /blah/.exec(foo)`, where looking at the previous token
// does not help.

pp.parseStatement = function (declaration, topLevel, exports) {
  let starttype = this.type,
      node = this.startNode(),
      kind;

  if (this.isLet()) {
    starttype = __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */]._var;
    kind = "let";
  }

  // Most types of statements are recognized by the keyword they
  // start with. Many are trivial to parse, some require a bit of
  // complexity.

  switch (starttype) {
    case __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */]._break:case __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */]._continue:
      return this.parseBreakContinueStatement(node, starttype.keyword);
    case __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */]._debugger:
      return this.parseDebuggerStatement(node);
    case __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */]._do:
      return this.parseDoStatement(node);
    case __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */]._for:
      return this.parseForStatement(node);
    case __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */]._function:
      if (!declaration && this.options.ecmaVersion >= 6) this.unexpected();
      return this.parseFunctionStatement(node, false);
    case __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */]._class:
      if (!declaration) this.unexpected();
      return this.parseClass(node, true);
    case __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */]._if:
      return this.parseIfStatement(node);
    case __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */]._return:
      return this.parseReturnStatement(node);
    case __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */]._switch:
      return this.parseSwitchStatement(node);
    case __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */]._throw:
      return this.parseThrowStatement(node);
    case __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */]._try:
      return this.parseTryStatement(node);
    case __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */]._const:case __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */]._var:
      kind = kind || this.value;
      if (!declaration && kind != "var") this.unexpected();
      return this.parseVarStatement(node, kind);
    case __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */]._while:
      return this.parseWhileStatement(node);
    case __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */]._with:
      return this.parseWithStatement(node);
    case __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].braceL:
      return this.parseBlock();
    case __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].semi:
      return this.parseEmptyStatement(node);
    case __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */]._export:
    case __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */]._import:
      if (!this.options.allowImportExportEverywhere) {
        if (!topLevel) this.raise(this.start, "'import' and 'export' may only appear at the top level");
        if (!this.inModule) this.raise(this.start, "'import' and 'export' may appear only with 'sourceType: module'");
      }
      return starttype === __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */]._import ? this.parseImport(node) : this.parseExport(node, exports);

    // If the statement does not start with a statement keyword or a
    // brace, it's an ExpressionStatement or LabeledStatement. We
    // simply start parsing an expression, and afterwards, if the
    // next token is a colon and the expression was a simple
    // Identifier node, we switch to interpreting it as a label.
    default:
      if (this.isAsyncFunction() && declaration) {
        this.next();
        return this.parseFunctionStatement(node, true);
      }

      let maybeName = this.value,
          expr = this.parseExpression();
      if (starttype === __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].name && expr.type === "Identifier" && this.eat(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].colon)) return this.parseLabeledStatement(node, maybeName, expr);else return this.parseExpressionStatement(node, expr);
  }
};

pp.parseBreakContinueStatement = function (node, keyword) {
  let isBreak = keyword == "break";
  this.next();
  if (this.eat(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].semi) || this.insertSemicolon()) node.label = null;else if (this.type !== __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].name) this.unexpected();else {
    node.label = this.parseIdent();
    this.semicolon();
  }

  // Verify that there is an actual destination to break or
  // continue to.
  let i = 0;
  for (; i < this.labels.length; ++i) {
    let lab = this.labels[i];
    if (node.label == null || lab.name === node.label.name) {
      if (lab.kind != null && (isBreak || lab.kind === "loop")) break;
      if (node.label && isBreak) break;
    }
  }
  if (i === this.labels.length) this.raise(node.start, "Unsyntactic " + keyword);
  return this.finishNode(node, isBreak ? "BreakStatement" : "ContinueStatement");
};

pp.parseDebuggerStatement = function (node) {
  this.next();
  this.semicolon();
  return this.finishNode(node, "DebuggerStatement");
};

pp.parseDoStatement = function (node) {
  this.next();
  this.labels.push(loopLabel);
  node.body = this.parseStatement(false);
  this.labels.pop();
  this.expect(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */]._while);
  node.test = this.parseParenExpression();
  if (this.options.ecmaVersion >= 6) this.eat(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].semi);else this.semicolon();
  return this.finishNode(node, "DoWhileStatement");
};

// Disambiguating between a `for` and a `for`/`in` or `for`/`of`
// loop is non-trivial. Basically, we have to parse the init `var`
// statement or expression, disallowing the `in` operator (see
// the second parameter to `parseExpression`), and then check
// whether the next token is `in` or `of`. When there is no init
// part (semicolon immediately after the opening parenthesis), it
// is a regular `for` loop.

pp.parseForStatement = function (node) {
  this.next();
  this.labels.push(loopLabel);
  this.enterLexicalScope();
  this.expect(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].parenL);
  if (this.type === __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].semi) return this.parseFor(node, null);
  let isLet = this.isLet();
  if (this.type === __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */]._var || this.type === __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */]._const || isLet) {
    let init = this.startNode(),
        kind = isLet ? "let" : this.value;
    this.next();
    this.parseVar(init, true, kind);
    this.finishNode(init, "VariableDeclaration");
    if ((this.type === __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */]._in || this.options.ecmaVersion >= 6 && this.isContextual("of")) && init.declarations.length === 1 && !(kind !== "var" && init.declarations[0].init)) return this.parseForIn(node, init);
    return this.parseFor(node, init);
  }
  let refDestructuringErrors = new __WEBPACK_IMPORTED_MODULE_5__parseutil__["a" /* DestructuringErrors */]();
  let init = this.parseExpression(true, refDestructuringErrors);
  if (this.type === __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */]._in || this.options.ecmaVersion >= 6 && this.isContextual("of")) {
    this.toAssignable(init);
    this.checkLVal(init);
    this.checkPatternErrors(refDestructuringErrors, true);
    return this.parseForIn(node, init);
  } else {
    this.checkExpressionErrors(refDestructuringErrors, true);
  }
  return this.parseFor(node, init);
};

pp.parseFunctionStatement = function (node, isAsync) {
  this.next();
  return this.parseFunction(node, true, false, isAsync);
};

pp.isFunction = function () {
  return this.type === __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */]._function || this.isAsyncFunction();
};

pp.parseIfStatement = function (node) {
  this.next();
  node.test = this.parseParenExpression();
  // allow function declarations in branches, but only in non-strict mode
  node.consequent = this.parseStatement(!this.strict && this.isFunction());
  node.alternate = this.eat(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */]._else) ? this.parseStatement(!this.strict && this.isFunction()) : null;
  return this.finishNode(node, "IfStatement");
};

pp.parseReturnStatement = function (node) {
  if (!this.inFunction && !this.options.allowReturnOutsideFunction) this.raise(this.start, "'return' outside of function");
  this.next();

  // In `return` (and `break`/`continue`), the keywords with
  // optional arguments, we eagerly look for a semicolon or the
  // possibility to insert one.

  if (this.eat(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].semi) || this.insertSemicolon()) node.argument = null;else {
    node.argument = this.parseExpression();this.semicolon();
  }
  return this.finishNode(node, "ReturnStatement");
};

pp.parseSwitchStatement = function (node) {
  this.next();
  node.discriminant = this.parseParenExpression();
  node.cases = [];
  this.expect(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].braceL);
  this.labels.push(switchLabel);
  this.enterLexicalScope();

  // Statements under must be grouped (by label) in SwitchCase
  // nodes. `cur` is used to keep the node that we are currently
  // adding statements to.

  let cur;
  for (let sawDefault = false; this.type != __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].braceR;) {
    if (this.type === __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */]._case || this.type === __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */]._default) {
      let isCase = this.type === __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */]._case;
      if (cur) this.finishNode(cur, "SwitchCase");
      node.cases.push(cur = this.startNode());
      cur.consequent = [];
      this.next();
      if (isCase) {
        cur.test = this.parseExpression();
      } else {
        if (sawDefault) this.raiseRecoverable(this.lastTokStart, "Multiple default clauses");
        sawDefault = true;
        cur.test = null;
      }
      this.expect(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].colon);
    } else {
      if (!cur) this.unexpected();
      cur.consequent.push(this.parseStatement(true));
    }
  }
  this.exitLexicalScope();
  if (cur) this.finishNode(cur, "SwitchCase");
  this.next(); // Closing brace
  this.labels.pop();
  return this.finishNode(node, "SwitchStatement");
};

pp.parseThrowStatement = function (node) {
  this.next();
  if (__WEBPACK_IMPORTED_MODULE_2__whitespace__["b" /* lineBreak */].test(this.input.slice(this.lastTokEnd, this.start))) this.raise(this.lastTokEnd, "Illegal newline after throw");
  node.argument = this.parseExpression();
  this.semicolon();
  return this.finishNode(node, "ThrowStatement");
};

// Reused empty array added for node fields that are always empty.

const empty = [];

pp.parseTryStatement = function (node) {
  this.next();
  node.block = this.parseBlock();
  node.handler = null;
  if (this.type === __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */]._catch) {
    let clause = this.startNode();
    this.next();
    this.expect(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].parenL);
    clause.param = this.parseBindingAtom();
    this.enterLexicalScope();
    this.checkLVal(clause.param, "let");
    this.expect(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].parenR);
    clause.body = this.parseBlock(false);
    this.exitLexicalScope();
    node.handler = this.finishNode(clause, "CatchClause");
  }
  node.finalizer = this.eat(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */]._finally) ? this.parseBlock() : null;
  if (!node.handler && !node.finalizer) this.raise(node.start, "Missing catch or finally clause");
  return this.finishNode(node, "TryStatement");
};

pp.parseVarStatement = function (node, kind) {
  this.next();
  this.parseVar(node, false, kind);
  this.semicolon();
  return this.finishNode(node, "VariableDeclaration");
};

pp.parseWhileStatement = function (node) {
  this.next();
  node.test = this.parseParenExpression();
  this.labels.push(loopLabel);
  node.body = this.parseStatement(false);
  this.labels.pop();
  return this.finishNode(node, "WhileStatement");
};

pp.parseWithStatement = function (node) {
  if (this.strict) this.raise(this.start, "'with' in strict mode");
  this.next();
  node.object = this.parseParenExpression();
  node.body = this.parseStatement(false);
  return this.finishNode(node, "WithStatement");
};

pp.parseEmptyStatement = function (node) {
  this.next();
  return this.finishNode(node, "EmptyStatement");
};

pp.parseLabeledStatement = function (node, maybeName, expr) {
  for (let _i = 0, _labels = this.labels; _i < _labels.length; _i++) {
    let label = _labels[_i];
    if (label.name === maybeName) this.raise(expr.start, "Label '" + maybeName + "' is already declared");
  }

  let kind = this.type.isLoop ? "loop" : this.type === __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */]._switch ? "switch" : null;
  for (let i = this.labels.length - 1; i >= 0; i--) {
    let label = this.labels[i];
    if (label.statementStart == node.start) {
      label.statementStart = this.start;
      label.kind = kind;
    } else break;
  }
  this.labels.push({ name: maybeName, kind: kind, statementStart: this.start });
  node.body = this.parseStatement(true);
  if (node.body.type == "ClassDeclaration" || node.body.type == "VariableDeclaration" && node.body.kind != "var" || node.body.type == "FunctionDeclaration" && (this.strict || node.body.generator)) this.raiseRecoverable(node.body.start, "Invalid labeled declaration");
  this.labels.pop();
  node.label = expr;
  return this.finishNode(node, "LabeledStatement");
};

pp.parseExpressionStatement = function (node, expr) {
  node.expression = expr;
  this.semicolon();
  return this.finishNode(node, "ExpressionStatement");
};

// Parse a semicolon-enclosed block of statements, handling `"use
// strict"` declarations when `allowStrict` is true (used for
// function bodies).

pp.parseBlock = function () {
  let createNewLexicalScope = arguments.length > 0 && arguments[0] !== undefined ? arguments[0] : true;

  let node = this.startNode();
  node.body = [];
  this.expect(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].braceL);
  if (createNewLexicalScope) {
    this.enterLexicalScope();
  }
  while (!this.eat(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].braceR)) {
    let stmt = this.parseStatement(true);
    node.body.push(stmt);
  }
  if (createNewLexicalScope) {
    this.exitLexicalScope();
  }
  return this.finishNode(node, "BlockStatement");
};

// Parse a regular `for` loop. The disambiguation code in
// `parseStatement` will already have parsed the init statement or
// expression.

pp.parseFor = function (node, init) {
  node.init = init;
  this.expect(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].semi);
  node.test = this.type === __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].semi ? null : this.parseExpression();
  this.expect(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].semi);
  node.update = this.type === __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].parenR ? null : this.parseExpression();
  this.expect(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].parenR);
  this.exitLexicalScope();
  node.body = this.parseStatement(false);
  this.labels.pop();
  return this.finishNode(node, "ForStatement");
};

// Parse a `for`/`in` and `for`/`of` loop, which are almost
// same from parser's perspective.

pp.parseForIn = function (node, init) {
  let type = this.type === __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */]._in ? "ForInStatement" : "ForOfStatement";
  this.next();
  node.left = init;
  node.right = this.parseExpression();
  this.expect(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].parenR);
  this.exitLexicalScope();
  node.body = this.parseStatement(false);
  this.labels.pop();
  return this.finishNode(node, type);
};

// Parse a list of variable declarations.

pp.parseVar = function (node, isFor, kind) {
  node.declarations = [];
  node.kind = kind;
  for (;;) {
    let decl = this.startNode();
    this.parseVarId(decl, kind);
    if (this.eat(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].eq)) {
      decl.init = this.parseMaybeAssign(isFor);
    } else if (kind === "const" && !(this.type === __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */]._in || this.options.ecmaVersion >= 6 && this.isContextual("of"))) {
      this.unexpected();
    } else if (decl.id.type != "Identifier" && !(isFor && (this.type === __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */]._in || this.isContextual("of")))) {
      this.raise(this.lastTokEnd, "Complex binding patterns require an initialization value");
    } else {
      decl.init = null;
    }
    node.declarations.push(this.finishNode(decl, "VariableDeclarator"));
    if (!this.eat(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].comma)) break;
  }
  return node;
};

pp.parseVarId = function (decl, kind) {
  decl.id = this.parseBindingAtom(kind);
  this.checkLVal(decl.id, kind, false);
};

// Parse a function declaration or literal (depending on the
// `isStatement` parameter).

pp.parseFunction = function (node, isStatement, allowExpressionBody, isAsync) {
  this.initFunction(node);
  if (this.options.ecmaVersion >= 6 && !isAsync) node.generator = this.eat(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].star);
  if (this.options.ecmaVersion >= 8) node.async = !!isAsync;

  if (isStatement) {
    node.id = isStatement === "nullableID" && this.type != __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].name ? null : this.parseIdent();
    if (node.id) {
      this.checkLVal(node.id, "var");
    }
  }

  let oldInGen = this.inGenerator,
      oldInAsync = this.inAsync,
      oldYieldPos = this.yieldPos,
      oldAwaitPos = this.awaitPos,
      oldInFunc = this.inFunction;
  this.inGenerator = node.generator;
  this.inAsync = node.async;
  this.yieldPos = 0;
  this.awaitPos = 0;
  this.inFunction = true;
  this.enterFunctionScope();

  if (!isStatement) node.id = this.type == __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].name ? this.parseIdent() : null;

  this.parseFunctionParams(node);
  this.parseFunctionBody(node, allowExpressionBody);

  this.inGenerator = oldInGen;
  this.inAsync = oldInAsync;
  this.yieldPos = oldYieldPos;
  this.awaitPos = oldAwaitPos;
  this.inFunction = oldInFunc;
  return this.finishNode(node, isStatement ? "FunctionDeclaration" : "FunctionExpression");
};

pp.parseFunctionParams = function (node) {
  this.expect(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].parenL);
  node.params = this.parseBindingList(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].parenR, false, this.options.ecmaVersion >= 8);
  this.checkYieldAwaitInDefaultParams();
};

// Parse a class declaration or literal (depending on the
// `isStatement` parameter).

pp.parseClass = function (node, isStatement) {
  this.next();

  this.parseClassId(node, isStatement);
  this.parseClassSuper(node);
  let classBody = this.startNode();
  let hadConstructor = false;
  classBody.body = [];
  this.expect(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].braceL);
  while (!this.eat(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].braceR)) {
    if (this.eat(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].semi)) continue;
    let method = this.startNode();
    let isGenerator = this.eat(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].star);
    let isAsync = false;
    let isMaybeStatic = this.type === __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].name && this.value === "static";
    this.parsePropertyName(method);
    method.static = isMaybeStatic && this.type !== __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].parenL;
    if (method.static) {
      if (isGenerator) this.unexpected();
      isGenerator = this.eat(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].star);
      this.parsePropertyName(method);
    }
    if (this.options.ecmaVersion >= 8 && !isGenerator && !method.computed && method.key.type === "Identifier" && method.key.name === "async" && this.type !== __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].parenL && !this.canInsertSemicolon()) {
      isAsync = true;
      this.parsePropertyName(method);
    }
    method.kind = "method";
    let isGetSet = false;
    if (!method.computed) {
      let key = method.key;

      if (!isGenerator && !isAsync && key.type === "Identifier" && this.type !== __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].parenL && (key.name === "get" || key.name === "set")) {
        isGetSet = true;
        method.kind = key.name;
        key = this.parsePropertyName(method);
      }
      if (!method.static && (key.type === "Identifier" && key.name === "constructor" || key.type === "Literal" && key.value === "constructor")) {
        if (hadConstructor) this.raise(key.start, "Duplicate constructor in the same class");
        if (isGetSet) this.raise(key.start, "Constructor can't have get/set modifier");
        if (isGenerator) this.raise(key.start, "Constructor can't be a generator");
        if (isAsync) this.raise(key.start, "Constructor can't be an async method");
        method.kind = "constructor";
        hadConstructor = true;
      }
    }
    this.parseClassMethod(classBody, method, isGenerator, isAsync);
    if (isGetSet) {
      let paramCount = method.kind === "get" ? 0 : 1;
      if (method.value.params.length !== paramCount) {
        let start = method.value.start;
        if (method.kind === "get") this.raiseRecoverable(start, "getter should have no params");else this.raiseRecoverable(start, "setter should have exactly one param");
      } else {
        if (method.kind === "set" && method.value.params[0].type === "RestElement") this.raiseRecoverable(method.value.params[0].start, "Setter cannot use rest params");
      }
    }
  }
  node.body = this.finishNode(classBody, "ClassBody");
  return this.finishNode(node, isStatement ? "ClassDeclaration" : "ClassExpression");
};

pp.parseClassMethod = function (classBody, method, isGenerator, isAsync) {
  method.value = this.parseMethod(isGenerator, isAsync);
  classBody.body.push(this.finishNode(method, "MethodDefinition"));
};

pp.parseClassId = function (node, isStatement) {
  node.id = this.type === __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].name ? this.parseIdent() : isStatement === true ? this.unexpected() : null;
};

pp.parseClassSuper = function (node) {
  node.superClass = this.eat(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */]._extends) ? this.parseExprSubscripts() : null;
};

// Parses module export declaration.

pp.parseExport = function (node, exports) {
  this.next();
  // export * from '...'
  if (this.eat(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].star)) {
    this.expectContextual("from");
    node.source = this.type === __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].string ? this.parseExprAtom() : this.unexpected();
    this.semicolon();
    return this.finishNode(node, "ExportAllDeclaration");
  }
  if (this.eat(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */]._default)) {
    // export default ...
    this.checkExport(exports, "default", this.lastTokStart);
    let isAsync;
    if (this.type === __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */]._function || (isAsync = this.isAsyncFunction())) {
      let fNode = this.startNode();
      this.next();
      if (isAsync) this.next();
      node.declaration = this.parseFunction(fNode, "nullableID", false, isAsync);
    } else if (this.type === __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */]._class) {
      let cNode = this.startNode();
      node.declaration = this.parseClass(cNode, "nullableID");
    } else {
      node.declaration = this.parseMaybeAssign();
      this.semicolon();
    }
    return this.finishNode(node, "ExportDefaultDeclaration");
  }
  // export var|const|let|function|class ...
  if (this.shouldParseExportStatement()) {
    node.declaration = this.parseStatement(true);
    if (node.declaration.type === "VariableDeclaration") this.checkVariableExport(exports, node.declaration.declarations);else this.checkExport(exports, node.declaration.id.name, node.declaration.id.start);
    node.specifiers = [];
    node.source = null;
  } else {
    // export { x, y as z } [from '...']
    node.declaration = null;
    node.specifiers = this.parseExportSpecifiers(exports);
    if (this.eatContextual("from")) {
      node.source = this.type === __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].string ? this.parseExprAtom() : this.unexpected();
    } else {
      // check for keywords used as local names
      for (let _i2 = 0, _node$specifiers = node.specifiers; _i2 < _node$specifiers.length; _i2++) {
        let spec = _node$specifiers[_i2];
        this.checkUnreserved(spec.local);
      }

      node.source = null;
    }
    this.semicolon();
  }
  return this.finishNode(node, "ExportNamedDeclaration");
};

pp.checkExport = function (exports, name, pos) {
  if (!exports) return;
  if (Object(__WEBPACK_IMPORTED_MODULE_4__util__["a" /* has */])(exports, name)) this.raiseRecoverable(pos, "Duplicate export '" + name + "'");
  exports[name] = true;
};

pp.checkPatternExport = function (exports, pat) {
  let type = pat.type;
  if (type == "Identifier") this.checkExport(exports, pat.name, pat.start);else if (type == "ObjectPattern") for (let _i3 = 0, _pat$properties = pat.properties; _i3 < _pat$properties.length; _i3++) {
      let prop = _pat$properties[_i3];
      this.checkPatternExport(exports, prop.value);
    } else if (type == "ArrayPattern") for (let _i4 = 0, _pat$elements = pat.elements; _i4 < _pat$elements.length; _i4++) {
      let elt = _pat$elements[_i4];
      if (elt) this.checkPatternExport(exports, elt);
    } else if (type == "AssignmentPattern") this.checkPatternExport(exports, pat.left);else if (type == "ParenthesizedExpression") this.checkPatternExport(exports, pat.expression);
};

pp.checkVariableExport = function (exports, decls) {
  if (!exports) return;

  for (let _i5 = 0; _i5 < decls.length; _i5++) {
    let decl = decls[_i5];
    this.checkPatternExport(exports, decl.id);
  }
};

pp.shouldParseExportStatement = function () {
  return this.type.keyword === "var" || this.type.keyword === "const" || this.type.keyword === "class" || this.type.keyword === "function" || this.isLet() || this.isAsyncFunction();
};

// Parses a comma-separated list of module exports.

pp.parseExportSpecifiers = function (exports) {
  let nodes = [],
      first = true;
  // export { x, y as z } [from '...']
  this.expect(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].braceL);
  while (!this.eat(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].braceR)) {
    if (!first) {
      this.expect(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].comma);
      if (this.afterTrailingComma(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].braceR)) break;
    } else first = false;

    let node = this.startNode();
    node.local = this.parseIdent(true);
    node.exported = this.eatContextual("as") ? this.parseIdent(true) : node.local;
    this.checkExport(exports, node.exported.name, node.exported.start);
    nodes.push(this.finishNode(node, "ExportSpecifier"));
  }
  return nodes;
};

// Parses import declaration.

pp.parseImport = function (node) {
  this.next();
  // import '...'
  if (this.type === __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].string) {
    node.specifiers = empty;
    node.source = this.parseExprAtom();
  } else {
    node.specifiers = this.parseImportSpecifiers();
    this.expectContextual("from");
    node.source = this.type === __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].string ? this.parseExprAtom() : this.unexpected();
  }
  this.semicolon();
  return this.finishNode(node, "ImportDeclaration");
};

// Parses a comma-separated list of module imports.

pp.parseImportSpecifiers = function () {
  let nodes = [],
      first = true;
  if (this.type === __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].name) {
    // import defaultObj, { x, y as z } from '...'
    let node = this.startNode();
    node.local = this.parseIdent();
    this.checkLVal(node.local, "let");
    nodes.push(this.finishNode(node, "ImportDefaultSpecifier"));
    if (!this.eat(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].comma)) return nodes;
  }
  if (this.type === __WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].star) {
    let node = this.startNode();
    this.next();
    this.expectContextual("as");
    node.local = this.parseIdent();
    this.checkLVal(node.local, "let");
    nodes.push(this.finishNode(node, "ImportNamespaceSpecifier"));
    return nodes;
  }
  this.expect(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].braceL);
  while (!this.eat(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].braceR)) {
    if (!first) {
      this.expect(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].comma);
      if (this.afterTrailingComma(__WEBPACK_IMPORTED_MODULE_0__tokentype__["b" /* types */].braceR)) break;
    } else first = false;

    let node = this.startNode();
    node.imported = this.parseIdent(true);
    if (this.eatContextual("as")) {
      node.local = this.parseIdent();
    } else {
      this.checkUnreserved(node.imported);
      node.local = node.imported;
    }
    this.checkLVal(node.local, "let");
    nodes.push(this.finishNode(node, "ImportSpecifier"));
  }
  return nodes;
};

/***/ }),
/* 118 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__state__ = __webpack_require__(6);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__tokentype__ = __webpack_require__(3);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__whitespace__ = __webpack_require__(13);
// The algorithm used to determine whether a regexp can appear at a
// given point in the program is loosely based on sweet.js' approach.
// See https://github.com/mozilla/sweet.js/wiki/design





class TokContext {
  constructor(token, isExpr, preserveSpace, override, generator) {
    this.token = token;
    this.isExpr = !!isExpr;
    this.preserveSpace = !!preserveSpace;
    this.override = override;
    this.generator = !!generator;
  }
}
/* unused harmony export TokContext */


const types = {
  b_stat: new TokContext("{", false),
  b_expr: new TokContext("{", true),
  b_tmpl: new TokContext("${", false),
  p_stat: new TokContext("(", false),
  p_expr: new TokContext("(", true),
  q_tmpl: new TokContext("`", true, true, function (p) {
    return p.tryReadTemplateToken();
  }),
  f_stat: new TokContext("function", false),
  f_expr: new TokContext("function", true),
  f_expr_gen: new TokContext("function", true, false, null, true),
  f_gen: new TokContext("function", false, false, null, true)
};
/* unused harmony export types */


const pp = __WEBPACK_IMPORTED_MODULE_0__state__["a" /* Parser */].prototype;

pp.initialContext = function () {
  return [types.b_stat];
};

pp.braceIsBlock = function (prevType) {
  let parent = this.curContext();
  if (parent === types.f_expr || parent === types.f_stat) return true;
  if (prevType === __WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].colon && (parent === types.b_stat || parent === types.b_expr)) return !parent.isExpr;

  // The check for `tt.name && exprAllowed` detects whether we are
  // after a `yield` or `of` construct. See the `updateContext` for
  // `tt.name`.
  if (prevType === __WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */]._return || prevType == __WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].name && this.exprAllowed) return __WEBPACK_IMPORTED_MODULE_2__whitespace__["b" /* lineBreak */].test(this.input.slice(this.lastTokEnd, this.start));
  if (prevType === __WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */]._else || prevType === __WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].semi || prevType === __WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].eof || prevType === __WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].parenR || prevType == __WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].arrow) return true;
  if (prevType == __WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].braceL) return parent === types.b_stat;
  if (prevType == __WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */]._var || prevType == __WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].name) return false;
  return !this.exprAllowed;
};

pp.inGeneratorContext = function () {
  for (let i = this.context.length - 1; i >= 1; i--) {
    let context = this.context[i];
    if (context.token === "function") return context.generator;
  }
  return false;
};

pp.updateContext = function (prevType) {
  let update,
      type = this.type;
  if (type.keyword && prevType == __WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].dot) this.exprAllowed = false;else if (update = type.updateContext) update.call(this, prevType);else this.exprAllowed = type.beforeExpr;
};

// Token-specific context update code

__WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].parenR.updateContext = __WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].braceR.updateContext = function () {
  if (this.context.length == 1) {
    this.exprAllowed = true;
    return;
  }
  let out = this.context.pop();
  if (out === types.b_stat && this.curContext().token === "function") {
    out = this.context.pop();
  }
  this.exprAllowed = !out.isExpr;
};

__WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].braceL.updateContext = function (prevType) {
  this.context.push(this.braceIsBlock(prevType) ? types.b_stat : types.b_expr);
  this.exprAllowed = true;
};

__WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].dollarBraceL.updateContext = function () {
  this.context.push(types.b_tmpl);
  this.exprAllowed = true;
};

__WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].parenL.updateContext = function (prevType) {
  let statementParens = prevType === __WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */]._if || prevType === __WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */]._for || prevType === __WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */]._with || prevType === __WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */]._while;
  this.context.push(statementParens ? types.p_stat : types.p_expr);
  this.exprAllowed = true;
};

__WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].incDec.updateContext = function () {
  // tokExprAllowed stays unchanged
};

__WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */]._function.updateContext = __WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */]._class.updateContext = function (prevType) {
  if (prevType.beforeExpr && prevType !== __WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].semi && prevType !== __WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */]._else && !((prevType === __WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].colon || prevType === __WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].braceL) && this.curContext() === types.b_stat)) this.context.push(types.f_expr);else this.context.push(types.f_stat);
  this.exprAllowed = false;
};

__WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].backQuote.updateContext = function () {
  if (this.curContext() === types.q_tmpl) this.context.pop();else this.context.push(types.q_tmpl);
  this.exprAllowed = false;
};

__WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].star.updateContext = function (prevType) {
  if (prevType == __WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */]._function) {
    let index = this.context.length - 1;
    if (this.context[index] === types.f_expr) this.context[index] = types.f_expr_gen;else this.context[index] = types.f_gen;
  }
  this.exprAllowed = true;
};

__WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].name.updateContext = function (prevType) {
  let allowed = false;
  if (this.options.ecmaVersion >= 6) {
    if (this.value == "of" && !this.exprAllowed || this.value == "yield" && this.inGeneratorContext()) allowed = true;
  }
  this.exprAllowed = allowed;
};

/***/ }),
/* 119 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__identifier__ = __webpack_require__(41);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__tokentype__ = __webpack_require__(3);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__state__ = __webpack_require__(6);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__locutil__ = __webpack_require__(30);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__whitespace__ = __webpack_require__(13);






// Object type used to represent tokens. Note that normally, tokens
// simply exist as properties on the parser object. This is only
// used for the onToken callback and the external tokenizer.

class Token {
  constructor(p) {
    this.type = p.type;
    this.value = p.value;
    this.start = p.start;
    this.end = p.end;
    if (p.options.locations) this.loc = new __WEBPACK_IMPORTED_MODULE_3__locutil__["b" /* SourceLocation */](p, p.startLoc, p.endLoc);
    if (p.options.ranges) this.range = [p.start, p.end];
  }
}
/* unused harmony export Token */


// ## Tokenizer

const pp = __WEBPACK_IMPORTED_MODULE_2__state__["a" /* Parser */].prototype;

// Are we running under Rhino?
const isRhino = typeof Packages == "object" && Object.prototype.toString.call(Packages) == "[object JavaPackage]";

// Move to the next token

pp.next = function () {
  if (this.options.onToken) this.options.onToken(new Token(this));

  this.lastTokEnd = this.end;
  this.lastTokStart = this.start;
  this.lastTokEndLoc = this.endLoc;
  this.lastTokStartLoc = this.startLoc;
  this.nextToken();
};

pp.getToken = function () {
  this.next();
  return new Token(this);
};

// If we're in an ES6 environment, make parsers iterable
if (typeof Symbol !== "undefined") pp[Symbol.iterator] = function () {
  var _this = this;

  return {
    next: function () {
      let token = _this.getToken();
      return {
        done: token.type === __WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].eof,
        value: token
      };
    }
  };
};

// Toggle strict mode. Re-reads the next number or string to please
// pedantic tests (`"use strict"; 010;` should fail).

pp.curContext = function () {
  return this.context[this.context.length - 1];
};

// Read a single token, updating the parser object's token-related
// properties.

pp.nextToken = function () {
  let curContext = this.curContext();
  if (!curContext || !curContext.preserveSpace) this.skipSpace();

  this.start = this.pos;
  if (this.options.locations) this.startLoc = this.curPosition();
  if (this.pos >= this.input.length) return this.finishToken(__WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].eof);

  if (curContext.override) return curContext.override(this);else this.readToken(this.fullCharCodeAtPos());
};

pp.readToken = function (code) {
  // Identifier or keyword. '\uXXXX' sequences are allowed in
  // identifiers, so '\' also dispatches to that.
  if (Object(__WEBPACK_IMPORTED_MODULE_0__identifier__["b" /* isIdentifierStart */])(code, this.options.ecmaVersion >= 6) || code === 92 /* '\' */) return this.readWord();

  return this.getTokenFromCode(code);
};

pp.fullCharCodeAtPos = function () {
  let code = this.input.charCodeAt(this.pos);
  if (code <= 0xd7ff || code >= 0xe000) return code;
  let next = this.input.charCodeAt(this.pos + 1);
  return (code << 10) + next - 0x35fdc00;
};

pp.skipBlockComment = function () {
  let startLoc = this.options.onComment && this.curPosition();
  let start = this.pos,
      end = this.input.indexOf("*/", this.pos += 2);
  if (end === -1) this.raise(this.pos - 2, "Unterminated comment");
  this.pos = end + 2;
  if (this.options.locations) {
    __WEBPACK_IMPORTED_MODULE_4__whitespace__["c" /* lineBreakG */].lastIndex = start;
    let match;
    while ((match = __WEBPACK_IMPORTED_MODULE_4__whitespace__["c" /* lineBreakG */].exec(this.input)) && match.index < this.pos) {
      ++this.curLine;
      this.lineStart = match.index + match[0].length;
    }
  }
  if (this.options.onComment) this.options.onComment(true, this.input.slice(start + 2, end), start, this.pos, startLoc, this.curPosition());
};

pp.skipLineComment = function (startSkip) {
  let start = this.pos;
  let startLoc = this.options.onComment && this.curPosition();
  let ch = this.input.charCodeAt(this.pos += startSkip);
  while (this.pos < this.input.length && !Object(__WEBPACK_IMPORTED_MODULE_4__whitespace__["a" /* isNewLine */])(ch)) {
    ch = this.input.charCodeAt(++this.pos);
  }
  if (this.options.onComment) this.options.onComment(false, this.input.slice(start + startSkip, this.pos), start, this.pos, startLoc, this.curPosition());
};

// Called at the start of the parse and after every token. Skips
// whitespace and comments, and.

pp.skipSpace = function () {
  loop: while (this.pos < this.input.length) {
    let ch = this.input.charCodeAt(this.pos);
    switch (ch) {
      case 32:case 160:
        // ' '
        ++this.pos;
        break;
      case 13:
        if (this.input.charCodeAt(this.pos + 1) === 10) {
          ++this.pos;
        }
      case 10:case 8232:case 8233:
        ++this.pos;
        if (this.options.locations) {
          ++this.curLine;
          this.lineStart = this.pos;
        }
        break;
      case 47:
        // '/'
        switch (this.input.charCodeAt(this.pos + 1)) {
          case 42:
            // '*'
            this.skipBlockComment();
            break;
          case 47:
            this.skipLineComment(2);
            break;
          default:
            break loop;
        }
        break;
      default:
        if (ch > 8 && ch < 14 || ch >= 5760 && __WEBPACK_IMPORTED_MODULE_4__whitespace__["d" /* nonASCIIwhitespace */].test(String.fromCharCode(ch))) {
          ++this.pos;
        } else {
          break loop;
        }
    }
  }
};

// Called at the end of every token. Sets `end`, `val`, and
// maintains `context` and `exprAllowed`, and skips the space after
// the token, so that the next one's `start` will point at the
// right position.

pp.finishToken = function (type, val) {
  this.end = this.pos;
  if (this.options.locations) this.endLoc = this.curPosition();
  let prevType = this.type;
  this.type = type;
  this.value = val;

  this.updateContext(prevType);
};

// ### Token reading

// This is the function that is called to fetch the next token. It
// is somewhat obscure, because it works in character codes rather
// than characters, and because operator parsing has been inlined
// into it.
//
// All in the name of speed.
//
pp.readToken_dot = function () {
  let next = this.input.charCodeAt(this.pos + 1);
  if (next >= 48 && next <= 57) return this.readNumber(true);
  let next2 = this.input.charCodeAt(this.pos + 2);
  if (this.options.ecmaVersion >= 6 && next === 46 && next2 === 46) {
    // 46 = dot '.'
    this.pos += 3;
    return this.finishToken(__WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].ellipsis);
  } else {
    ++this.pos;
    return this.finishToken(__WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].dot);
  }
};

pp.readToken_slash = function () {
  // '/'
  let next = this.input.charCodeAt(this.pos + 1);
  if (this.exprAllowed) {
    ++this.pos;return this.readRegexp();
  }
  if (next === 61) return this.finishOp(__WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].assign, 2);
  return this.finishOp(__WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].slash, 1);
};

pp.readToken_mult_modulo_exp = function (code) {
  // '%*'
  let next = this.input.charCodeAt(this.pos + 1);
  let size = 1;
  let tokentype = code === 42 ? __WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].star : __WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].modulo;

  // exponentiation operator ** and **=
  if (this.options.ecmaVersion >= 7 && next === 42) {
    ++size;
    tokentype = __WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].starstar;
    next = this.input.charCodeAt(this.pos + 2);
  }

  if (next === 61) return this.finishOp(__WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].assign, size + 1);
  return this.finishOp(tokentype, size);
};

pp.readToken_pipe_amp = function (code) {
  // '|&'
  let next = this.input.charCodeAt(this.pos + 1);
  if (next === code) return this.finishOp(code === 124 ? __WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].logicalOR : __WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].logicalAND, 2);
  if (next === 61) return this.finishOp(__WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].assign, 2);
  return this.finishOp(code === 124 ? __WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].bitwiseOR : __WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].bitwiseAND, 1);
};

pp.readToken_caret = function () {
  // '^'
  let next = this.input.charCodeAt(this.pos + 1);
  if (next === 61) return this.finishOp(__WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].assign, 2);
  return this.finishOp(__WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].bitwiseXOR, 1);
};

pp.readToken_plus_min = function (code) {
  // '+-'
  let next = this.input.charCodeAt(this.pos + 1);
  if (next === code) {
    if (next == 45 && !this.inModule && this.input.charCodeAt(this.pos + 2) == 62 && (this.lastTokEnd === 0 || __WEBPACK_IMPORTED_MODULE_4__whitespace__["b" /* lineBreak */].test(this.input.slice(this.lastTokEnd, this.pos)))) {
      // A `-->` line comment
      this.skipLineComment(3);
      this.skipSpace();
      return this.nextToken();
    }
    return this.finishOp(__WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].incDec, 2);
  }
  if (next === 61) return this.finishOp(__WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].assign, 2);
  return this.finishOp(__WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].plusMin, 1);
};

pp.readToken_lt_gt = function (code) {
  // '<>'
  let next = this.input.charCodeAt(this.pos + 1);
  let size = 1;
  if (next === code) {
    size = code === 62 && this.input.charCodeAt(this.pos + 2) === 62 ? 3 : 2;
    if (this.input.charCodeAt(this.pos + size) === 61) return this.finishOp(__WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].assign, size + 1);
    return this.finishOp(__WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].bitShift, size);
  }
  if (next == 33 && code == 60 && !this.inModule && this.input.charCodeAt(this.pos + 2) == 45 && this.input.charCodeAt(this.pos + 3) == 45) {
    // `<!--`, an XML-style comment that should be interpreted as a line comment
    this.skipLineComment(4);
    this.skipSpace();
    return this.nextToken();
  }
  if (next === 61) size = 2;
  return this.finishOp(__WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].relational, size);
};

pp.readToken_eq_excl = function (code) {
  // '=!'
  let next = this.input.charCodeAt(this.pos + 1);
  if (next === 61) return this.finishOp(__WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].equality, this.input.charCodeAt(this.pos + 2) === 61 ? 3 : 2);
  if (code === 61 && next === 62 && this.options.ecmaVersion >= 6) {
    // '=>'
    this.pos += 2;
    return this.finishToken(__WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].arrow);
  }
  return this.finishOp(code === 61 ? __WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].eq : __WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].prefix, 1);
};

pp.getTokenFromCode = function (code) {
  switch (code) {
    // The interpretation of a dot depends on whether it is followed
    // by a digit or another two dots.
    case 46:
      // '.'
      return this.readToken_dot();

    // Punctuation tokens.
    case 40:
      ++this.pos;return this.finishToken(__WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].parenL);
    case 41:
      ++this.pos;return this.finishToken(__WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].parenR);
    case 59:
      ++this.pos;return this.finishToken(__WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].semi);
    case 44:
      ++this.pos;return this.finishToken(__WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].comma);
    case 91:
      ++this.pos;return this.finishToken(__WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].bracketL);
    case 93:
      ++this.pos;return this.finishToken(__WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].bracketR);
    case 123:
      ++this.pos;return this.finishToken(__WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].braceL);
    case 125:
      ++this.pos;return this.finishToken(__WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].braceR);
    case 58:
      ++this.pos;return this.finishToken(__WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].colon);
    case 63:
      ++this.pos;return this.finishToken(__WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].question);

    case 96:
      // '`'
      if (this.options.ecmaVersion < 6) break;
      ++this.pos;
      return this.finishToken(__WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].backQuote);

    case 48:
      // '0'
      let next = this.input.charCodeAt(this.pos + 1);
      if (next === 120 || next === 88) return this.readRadixNumber(16); // '0x', '0X' - hex number
      if (this.options.ecmaVersion >= 6) {
        if (next === 111 || next === 79) return this.readRadixNumber(8); // '0o', '0O' - octal number
        if (next === 98 || next === 66) return this.readRadixNumber(2); // '0b', '0B' - binary number
      }
    // Anything else beginning with a digit is an integer, octal
    // number, or float.
    case 49:case 50:case 51:case 52:case 53:case 54:case 55:case 56:case 57:
      // 1-9
      return this.readNumber(false);

    // Quotes produce strings.
    case 34:case 39:
      // '"', "'"
      return this.readString(code);

    // Operators are parsed inline in tiny state machines. '=' (61) is
    // often referred to. `finishOp` simply skips the amount of
    // characters it is given as second argument, and returns a token
    // of the type given by its first argument.

    case 47:
      // '/'
      return this.readToken_slash();

    case 37:case 42:
      // '%*'
      return this.readToken_mult_modulo_exp(code);

    case 124:case 38:
      // '|&'
      return this.readToken_pipe_amp(code);

    case 94:
      // '^'
      return this.readToken_caret();

    case 43:case 45:
      // '+-'
      return this.readToken_plus_min(code);

    case 60:case 62:
      // '<>'
      return this.readToken_lt_gt(code);

    case 61:case 33:
      // '=!'
      return this.readToken_eq_excl(code);

    case 126:
      // '~'
      return this.finishOp(__WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].prefix, 1);
  }

  this.raise(this.pos, "Unexpected character '" + codePointToString(code) + "'");
};

pp.finishOp = function (type, size) {
  let str = this.input.slice(this.pos, this.pos + size);
  this.pos += size;
  return this.finishToken(type, str);
};

// Parse a regular expression. Some context-awareness is necessary,
// since a '/' inside a '[]' set does not end the expression.

function tryCreateRegexp(src, flags, throwErrorAt, parser) {
  try {
    return new RegExp(src, flags);
  } catch (e) {
    if (throwErrorAt !== undefined) {
      if (e instanceof SyntaxError) parser.raise(throwErrorAt, "Error parsing regular expression: " + e.message);
      throw e;
    }
  }
}

const regexpUnicodeSupport = !!tryCreateRegexp("\uffff", "u");

pp.readRegexp = function () {
  var _this2 = this;

  let escaped,
      inClass,
      start = this.pos;
  for (;;) {
    if (this.pos >= this.input.length) this.raise(start, "Unterminated regular expression");
    let ch = this.input.charAt(this.pos);
    if (__WEBPACK_IMPORTED_MODULE_4__whitespace__["b" /* lineBreak */].test(ch)) this.raise(start, "Unterminated regular expression");
    if (!escaped) {
      if (ch === "[") inClass = true;else if (ch === "]" && inClass) inClass = false;else if (ch === "/" && !inClass) break;
      escaped = ch === "\\";
    } else escaped = false;
    ++this.pos;
  }
  let content = this.input.slice(start, this.pos);
  ++this.pos;
  // Need to use `readWord1` because '\uXXXX' sequences are allowed
  // here (don't ask).
  let mods = this.readWord1();
  let tmp = content,
      tmpFlags = "";
  if (mods) {
    let validFlags = /^[gim]*$/;
    if (this.options.ecmaVersion >= 6) validFlags = /^[gimuy]*$/;
    if (!validFlags.test(mods)) this.raise(start, "Invalid regular expression flag");
    if (mods.indexOf("u") >= 0) {
      if (regexpUnicodeSupport) {
        tmpFlags = "u";
      } else {
        // Replace each astral symbol and every Unicode escape sequence that
        // possibly represents an astral symbol or a paired surrogate with a
        // single ASCII symbol to avoid throwing on regular expressions that
        // are only valid in combination with the `/u` flag.
        // Note: replacing with the ASCII symbol `x` might cause false
        // negatives in unlikely scenarios. For example, `[\u{61}-b]` is a
        // perfectly valid pattern that is equivalent to `[a-b]`, but it would
        // be replaced by `[x-b]` which throws an error.
        tmp = tmp.replace(/\\u\{([0-9a-fA-F]+)\}/g, function (_match, code, offset) {
          code = Number("0x" + code);
          if (code > 0x10FFFF) _this2.raise(start + offset + 3, "Code point out of bounds");
          return "x";
        });
        tmp = tmp.replace(/\\u([a-fA-F0-9]{4})|[\uD800-\uDBFF][\uDC00-\uDFFF]/g, "x");
        tmpFlags = tmpFlags.replace("u", "");
      }
    }
  }
  // Detect invalid regular expressions.
  let value = null;
  // Rhino's regular expression parser is flaky and throws uncatchable exceptions,
  // so don't do detection if we are running under Rhino
  if (!isRhino) {
    tryCreateRegexp(tmp, tmpFlags, start, this);
    // Get a regular expression object for this pattern-flag pair, or `null` in
    // case the current environment doesn't support the flags it uses.
    value = tryCreateRegexp(content, mods);
  }
  return this.finishToken(__WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].regexp, { pattern: content, flags: mods, value: value });
};

// Read an integer in the given radix. Return null if zero digits
// were read, the integer value otherwise. When `len` is given, this
// will return `null` unless the integer has exactly `len` digits.

pp.readInt = function (radix, len) {
  let start = this.pos,
      total = 0;
  for (let i = 0, e = len == null ? Infinity : len; i < e; ++i) {
    let code = this.input.charCodeAt(this.pos),
        val;
    if (code >= 97) val = code - 97 + 10; // a
    else if (code >= 65) val = code - 65 + 10; // A
      else if (code >= 48 && code <= 57) val = code - 48; // 0-9
        else val = Infinity;
    if (val >= radix) break;
    ++this.pos;
    total = total * radix + val;
  }
  if (this.pos === start || len != null && this.pos - start !== len) return null;

  return total;
};

pp.readRadixNumber = function (radix) {
  this.pos += 2; // 0x
  let val = this.readInt(radix);
  if (val == null) this.raise(this.start + 2, "Expected number in radix " + radix);
  if (Object(__WEBPACK_IMPORTED_MODULE_0__identifier__["b" /* isIdentifierStart */])(this.fullCharCodeAtPos())) this.raise(this.pos, "Identifier directly after number");
  return this.finishToken(__WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].num, val);
};

// Read an integer, octal integer, or floating-point number.

pp.readNumber = function (startsWithDot) {
  let start = this.pos,
      isFloat = false,
      octal = this.input.charCodeAt(this.pos) === 48;
  if (!startsWithDot && this.readInt(10) === null) this.raise(start, "Invalid number");
  if (octal && this.pos == start + 1) octal = false;
  let next = this.input.charCodeAt(this.pos);
  if (next === 46 && !octal) {
    // '.'
    ++this.pos;
    this.readInt(10);
    isFloat = true;
    next = this.input.charCodeAt(this.pos);
  }
  if ((next === 69 || next === 101) && !octal) {
    // 'eE'
    next = this.input.charCodeAt(++this.pos);
    if (next === 43 || next === 45) ++this.pos; // '+-'
    if (this.readInt(10) === null) this.raise(start, "Invalid number");
    isFloat = true;
  }
  if (Object(__WEBPACK_IMPORTED_MODULE_0__identifier__["b" /* isIdentifierStart */])(this.fullCharCodeAtPos())) this.raise(this.pos, "Identifier directly after number");

  let str = this.input.slice(start, this.pos),
      val;
  if (isFloat) val = parseFloat(str);else if (!octal || str.length === 1) val = parseInt(str, 10);else if (this.strict) this.raise(start, "Invalid number");else if (/[89]/.test(str)) val = parseInt(str, 10);else val = parseInt(str, 8);
  return this.finishToken(__WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].num, val);
};

// Read a string value, interpreting backslash-escapes.

pp.readCodePoint = function () {
  let ch = this.input.charCodeAt(this.pos),
      code;

  if (ch === 123) {
    // '{'
    if (this.options.ecmaVersion < 6) this.unexpected();
    let codePos = ++this.pos;
    code = this.readHexChar(this.input.indexOf("}", this.pos) - this.pos);
    ++this.pos;
    if (code > 0x10FFFF) this.invalidStringToken(codePos, "Code point out of bounds");
  } else {
    code = this.readHexChar(4);
  }
  return code;
};

function codePointToString(code) {
  // UTF-16 Decoding
  if (code <= 0xFFFF) return String.fromCharCode(code);
  code -= 0x10000;
  return String.fromCharCode((code >> 10) + 0xD800, (code & 1023) + 0xDC00);
}

pp.readString = function (quote) {
  let out = "",
      chunkStart = ++this.pos;
  for (;;) {
    if (this.pos >= this.input.length) this.raise(this.start, "Unterminated string constant");
    let ch = this.input.charCodeAt(this.pos);
    if (ch === quote) break;
    if (ch === 92) {
      // '\'
      out += this.input.slice(chunkStart, this.pos);
      out += this.readEscapedChar(false);
      chunkStart = this.pos;
    } else {
      if (Object(__WEBPACK_IMPORTED_MODULE_4__whitespace__["a" /* isNewLine */])(ch)) this.raise(this.start, "Unterminated string constant");
      ++this.pos;
    }
  }
  out += this.input.slice(chunkStart, this.pos++);
  return this.finishToken(__WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].string, out);
};

// Reads template string tokens.

const INVALID_TEMPLATE_ESCAPE_ERROR = {};

pp.tryReadTemplateToken = function () {
  this.inTemplateElement = true;
  try {
    this.readTmplToken();
  } catch (err) {
    if (err === INVALID_TEMPLATE_ESCAPE_ERROR) {
      this.readInvalidTemplateToken();
    } else {
      throw err;
    }
  }

  this.inTemplateElement = false;
};

pp.invalidStringToken = function (position, message) {
  if (this.inTemplateElement && this.options.ecmaVersion >= 9) {
    throw INVALID_TEMPLATE_ESCAPE_ERROR;
  } else {
    this.raise(position, message);
  }
};

pp.readTmplToken = function () {
  let out = "",
      chunkStart = this.pos;
  for (;;) {
    if (this.pos >= this.input.length) this.raise(this.start, "Unterminated template");
    let ch = this.input.charCodeAt(this.pos);
    if (ch === 96 || ch === 36 && this.input.charCodeAt(this.pos + 1) === 123) {
      // '`', '${'
      if (this.pos === this.start && (this.type === __WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].template || this.type === __WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].invalidTemplate)) {
        if (ch === 36) {
          this.pos += 2;
          return this.finishToken(__WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].dollarBraceL);
        } else {
          ++this.pos;
          return this.finishToken(__WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].backQuote);
        }
      }
      out += this.input.slice(chunkStart, this.pos);
      return this.finishToken(__WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].template, out);
    }
    if (ch === 92) {
      // '\'
      out += this.input.slice(chunkStart, this.pos);
      out += this.readEscapedChar(true);
      chunkStart = this.pos;
    } else if (Object(__WEBPACK_IMPORTED_MODULE_4__whitespace__["a" /* isNewLine */])(ch)) {
      out += this.input.slice(chunkStart, this.pos);
      ++this.pos;
      switch (ch) {
        case 13:
          if (this.input.charCodeAt(this.pos) === 10) ++this.pos;
        case 10:
          out += "\n";
          break;
        default:
          out += String.fromCharCode(ch);
          break;
      }
      if (this.options.locations) {
        ++this.curLine;
        this.lineStart = this.pos;
      }
      chunkStart = this.pos;
    } else {
      ++this.pos;
    }
  }
};

// Reads a template token to search for the end, without validating any escape sequences
pp.readInvalidTemplateToken = function () {
  for (; this.pos < this.input.length; this.pos++) {
    switch (this.input[this.pos]) {
      case "\\":
        ++this.pos;
        break;

      case "$":
        if (this.input[this.pos + 1] !== "{") {
          break;
        }
      // falls through

      case "`":
        return this.finishToken(__WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].invalidTemplate, this.input.slice(this.start, this.pos));

      // no default
    }
  }
  this.raise(this.start, "Unterminated template");
};

// Used to read escaped characters

pp.readEscapedChar = function (inTemplate) {
  let ch = this.input.charCodeAt(++this.pos);
  ++this.pos;
  switch (ch) {
    case 110:
      return "\n"; // 'n' -> '\n'
    case 114:
      return "\r"; // 'r' -> '\r'
    case 120:
      return String.fromCharCode(this.readHexChar(2)); // 'x'
    case 117:
      return codePointToString(this.readCodePoint()); // 'u'
    case 116:
      return "\t"; // 't' -> '\t'
    case 98:
      return "\b"; // 'b' -> '\b'
    case 118:
      return "\u000b"; // 'v' -> '\u000b'
    case 102:
      return "\f"; // 'f' -> '\f'
    case 13:
      if (this.input.charCodeAt(this.pos) === 10) ++this.pos; // '\r\n'
    case 10:
      // ' \n'
      if (this.options.locations) {
        this.lineStart = this.pos;++this.curLine;
      }
      return "";
    default:
      if (ch >= 48 && ch <= 55) {
        let octalStr = this.input.substr(this.pos - 1, 3).match(/^[0-7]+/)[0];
        let octal = parseInt(octalStr, 8);
        if (octal > 255) {
          octalStr = octalStr.slice(0, -1);
          octal = parseInt(octalStr, 8);
        }
        if (octalStr !== "0" && (this.strict || inTemplate)) {
          this.invalidStringToken(this.pos - 2, "Octal literal in strict mode");
        }
        this.pos += octalStr.length - 1;
        return String.fromCharCode(octal);
      }
      return String.fromCharCode(ch);
  }
};

// Used to read character escape sequences ('\x', '\u', '\U').

pp.readHexChar = function (len) {
  let codePos = this.pos;
  let n = this.readInt(16, len);
  if (n === null) this.invalidStringToken(codePos, "Bad character escape sequence");
  return n;
};

// Read an identifier, and return it as a string. Sets `this.containsEsc`
// to whether the word contained a '\u' escape.
//
// Incrementally adds only escaped chars, adding other chunks as-is
// as a micro-optimization.

pp.readWord1 = function () {
  this.containsEsc = false;
  let word = "",
      first = true,
      chunkStart = this.pos;
  let astral = this.options.ecmaVersion >= 6;
  while (this.pos < this.input.length) {
    let ch = this.fullCharCodeAtPos();
    if (Object(__WEBPACK_IMPORTED_MODULE_0__identifier__["a" /* isIdentifierChar */])(ch, astral)) {
      this.pos += ch <= 0xffff ? 1 : 2;
    } else if (ch === 92) {
      // "\"
      this.containsEsc = true;
      word += this.input.slice(chunkStart, this.pos);
      let escStart = this.pos;
      if (this.input.charCodeAt(++this.pos) != 117) // "u"
        this.invalidStringToken(this.pos, "Expecting Unicode escape sequence \\uXXXX");
      ++this.pos;
      let esc = this.readCodePoint();
      if (!(first ? __WEBPACK_IMPORTED_MODULE_0__identifier__["b" /* isIdentifierStart */] : __WEBPACK_IMPORTED_MODULE_0__identifier__["a" /* isIdentifierChar */])(esc, astral)) this.invalidStringToken(escStart, "Invalid Unicode escape");
      word += codePointToString(esc);
      chunkStart = this.pos;
    } else {
      break;
    }
    first = false;
  }
  return word + this.input.slice(chunkStart, this.pos);
};

// Read an identifier or keyword token. Will check for reserved
// words when necessary.

pp.readWord = function () {
  let word = this.readWord1();
  let type = __WEBPACK_IMPORTED_MODULE_1__tokentype__["b" /* types */].name;
  if (this.keywords.test(word)) {
    if (this.containsEsc) this.raiseRecoverable(this.start, "Escape sequence in keyword " + word);
    type = __WEBPACK_IMPORTED_MODULE_1__tokentype__["a" /* keywords */][word];
  }
  return this.finishToken(type, word);
};

/***/ }),
/* 120 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return enable; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__util_wrap_js__ = __webpack_require__(14);


function enable(parser) {
  parser.parseMaybeUnary = Object(__WEBPACK_IMPORTED_MODULE_0__util_wrap_js__["a" /* default */])(parser.parseMaybeUnary, parseMaybeUnary);
  return parser;
}

function parseMaybeUnary(func, args) {
  const refDestructuringErrors = args[0];

  return this.isContextual("await") ? this.parseAwait(refDestructuringErrors) : func.apply(this, args);
}



/***/ }),
/* 121 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return enable; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__parse_lookahead_js__ = __webpack_require__(71);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__vendor_acorn_src_tokentype_js__ = __webpack_require__(3);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__parse_unexpected_js__ = __webpack_require__(31);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__util_wrap_js__ = __webpack_require__(14);
// A simplified and more accurate version of the dynamic import acorn plugin.
// Copyright Jordan Gensler. Released under MIT license:
// https://github.com/kesne/acorn-dynamic-import






function enable(parser) {
  // Allow `yield import()` to parse.
  __WEBPACK_IMPORTED_MODULE_1__vendor_acorn_src_tokentype_js__["b" /* types */]._import.startsExpr = true;
  parser.parseExprAtom = Object(__WEBPACK_IMPORTED_MODULE_3__util_wrap_js__["a" /* default */])(parser.parseExprAtom, parseExprAtom);
  parser.parseStatement = Object(__WEBPACK_IMPORTED_MODULE_3__util_wrap_js__["a" /* default */])(parser.parseStatement, parseStatement);
  return parser;
}

function parseExprAtom(func, args) {
  const importPos = this.start;

  if (this.eat(__WEBPACK_IMPORTED_MODULE_1__vendor_acorn_src_tokentype_js__["b" /* types */]._import)) {
    if (this.type !== __WEBPACK_IMPORTED_MODULE_1__vendor_acorn_src_tokentype_js__["b" /* types */].parenL) {
      Object(__WEBPACK_IMPORTED_MODULE_2__parse_unexpected_js__["a" /* default */])(this);
    }

    return this.finishNode(this.startNodeAt(importPos), "Import");
  }

  return func.apply(this, args);
}

function parseStatement(func, args) {
  if (this.type === __WEBPACK_IMPORTED_MODULE_1__vendor_acorn_src_tokentype_js__["b" /* types */]._import && Object(__WEBPACK_IMPORTED_MODULE_0__parse_lookahead_js__["a" /* default */])(this).type === __WEBPACK_IMPORTED_MODULE_1__vendor_acorn_src_tokentype_js__["b" /* types */].parenL) {
    // import(...)
    const startPos = this.start;
    const node = this.startNode();
    const callExpr = this.startNode();
    const callee = this.parseExprAtom();

    this.next();

    callExpr.arguments = [this.parseMaybeAssign()];
    callExpr.callee = callee;
    this.finishNode(callExpr, "CallExpression");

    if (!this.eat(__WEBPACK_IMPORTED_MODULE_1__vendor_acorn_src_tokentype_js__["b" /* types */].parenR)) {
      Object(__WEBPACK_IMPORTED_MODULE_2__parse_unexpected_js__["a" /* default */])(this);
    }

    const expr = this.parseSubscripts(callExpr, startPos);
    return this.parseExpressionStatement(node, expr);
  }

  return func.apply(this, args);
}



/***/ }),
/* 122 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return enable; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__parse_lookahead_js__ = __webpack_require__(71);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__vendor_acorn_src_tokentype_js__ = __webpack_require__(3);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__parse_unexpected_js__ = __webpack_require__(31);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__util_wrap_js__ = __webpack_require__(14);





function enable(parser) {
  const key = typeof parser.parseExportSpecifiers === "function" ? "parseExportSpecifiers" : "parseExportSpecifierList";

  parser[key] = Object(__WEBPACK_IMPORTED_MODULE_3__util_wrap_js__["a" /* default */])(parser[key], parseExportSpecifiers);
  parser.parseExport = parseExport;
  return parser;
}

function parseExport(node, exported) {
  // export ...
  this.next();

  if (this.type === __WEBPACK_IMPORTED_MODULE_1__vendor_acorn_src_tokentype_js__["b" /* types */]._default) {
    // ... default function|class|=...
    return parseExportDefaultDeclaration(this, node, exported);
  }

  if (this.type === __WEBPACK_IMPORTED_MODULE_1__vendor_acorn_src_tokentype_js__["b" /* types */].star && Object(__WEBPACK_IMPORTED_MODULE_0__parse_lookahead_js__["a" /* default */])(this).isContextual("from")) {
    // ... * from "..."
    return parseExportNamespace(this, node);
  }

  if (this.shouldParseExportStatement()) {
    // ... var|const|let|function|class ...
    return parseExportNamedDeclaration(this, node, exported);
  }

  // ... def, [, * as ns [, { x, y as z }]] from "..."
  node.specifiers = typeof this.parseExportSpecifiers === "function" ? this.parseExportSpecifiers(exported) : this.parseExportSpecifierList();

  if (this.isContextual("from")) {
    parseExportFrom(this, node);
  } else {
    this.semicolon();
  }

  return this.finishNode(node, "ExportNamedDeclaration");
}

function parseExportSpecifiers(func, args) {
  let expectFrom = false;
  const exported = args[0];

  const specifiers = [];

  do {
    if (this.type === __WEBPACK_IMPORTED_MODULE_1__vendor_acorn_src_tokentype_js__["b" /* types */].name) {
      // ... def [, ...]
      expectFrom = true;
      specifiers.push(parseExportDefaultSpecifier(this));
    } else if (this.type === __WEBPACK_IMPORTED_MODULE_1__vendor_acorn_src_tokentype_js__["b" /* types */].star) {
      // ... * as ns [, ...]
      expectFrom = true;
      specifiers.push(parseExportNamespaceSpecifier(this, exported));
    } else if (this.type === __WEBPACK_IMPORTED_MODULE_1__vendor_acorn_src_tokentype_js__["b" /* types */].braceL) {
      // ... { x, y as z } [, ...]
      specifiers.push.apply(specifiers, func.apply(this, args));
    }
  } while (this.eat(__WEBPACK_IMPORTED_MODULE_1__vendor_acorn_src_tokentype_js__["b" /* types */].comma));

  if (expectFrom && !this.isContextual("from")) {
    Object(__WEBPACK_IMPORTED_MODULE_2__parse_unexpected_js__["a" /* default */])(this);
  }

  return specifiers;
}

function isAsyncFunction(parser) {
  return typeof parser.isAsyncFunction === "function" ? parser.isAsyncFunction() : parser.toks.isAsyncFunction();
}

function parseExportDefaultDeclaration(parser, node, exported) {
  // ... default function|class|=...
  exported.default = true;
  parser.next();

  let isAsync;
  if (parser.type === __WEBPACK_IMPORTED_MODULE_1__vendor_acorn_src_tokentype_js__["b" /* types */]._function || (isAsync = isAsyncFunction(parser))) {
    // Parse a function declaration.
    const funcNode = parser.startNode();
    if (isAsync) {
      parser.next();
    }
    parser.next();
    node.declaration = parser.parseFunction(funcNode, "nullableID", false, isAsync);
  } else if (parser.type === __WEBPACK_IMPORTED_MODULE_1__vendor_acorn_src_tokentype_js__["b" /* types */]._class) {
    // Parse a class declaration.
    node.declaration = parser.parseClass(parser.startNode(), "nullableID");
  } else {
    // Parse an assignment expression.
    node.declaration = parser.parseMaybeAssign();
  }

  parser.semicolon();
  return parser.finishNode(node, "ExportDefaultDeclaration");
}

function parseExportDefaultSpecifier(parser) {
  // ... def
  const specifier = parser.startNode();
  specifier.exported = parser.parseIdent();
  return parser.finishNode(specifier, "ExportDefaultSpecifier");
}

function parseExportFrom(parser, node) {
  // ... from "..."
  if (!parser.eatContextual("from")) {
    Object(__WEBPACK_IMPORTED_MODULE_2__parse_unexpected_js__["a" /* default */])(parser);
  }

  node.source = parser.type === __WEBPACK_IMPORTED_MODULE_1__vendor_acorn_src_tokentype_js__["b" /* types */].string ? parser.parseExprAtom() : null;
  parser.semicolon();
}

function parseExportNamedDeclaration(parser, node, exported) {
  // ... var|const|let|function|class ...
  node.declaration = parser.parseStatement(true);
  node.source = null;
  node.specifiers = [];

  if (node.declaration.type === "VariableDeclaration") {
    parser.checkVariableExport(exported, node.declaration.declarations);
  } else {
    exported[node.declaration.id.name] = true;
  }

  return parser.finishNode(node, "ExportNamedDeclaration");
}

function parseExportNamespace(parser, node) {
  // ... * from "..."
  parser.next();
  node.specifiers = [];
  parseExportFrom(parser, node);
  return parser.finishNode(node, "ExportAllDeclaration");
}

function parseExportNamespaceSpecifier(parser, exported) {
  // ... * as ns
  const star = parser.startNode();
  parser.next();

  if (!parser.eatContextual("as")) {
    Object(__WEBPACK_IMPORTED_MODULE_2__parse_unexpected_js__["a" /* default */])(parser);
  }

  star.exported = parser.parseIdent();
  exported[star.exported.name] = true;
  return parser.finishNode(star, "ExportNamespaceSpecifier");
}



/***/ }),
/* 123 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return enable; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__vendor_acorn_src_tokentype_js__ = __webpack_require__(3);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__parse_unexpected_js__ = __webpack_require__(31);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__util_wrap_js__ = __webpack_require__(14);




function enable(parser) {
  const key = typeof parser.parseImportSpecifiers === "function" ? "parseImportSpecifiers" : "parseImportSpecifierList";

  parser[key] = Object(__WEBPACK_IMPORTED_MODULE_2__util_wrap_js__["a" /* default */])(parser[key], parseImportSpecifiers);
  return parser;
}

function parseImportSpecifiers(func, args) {
  const specifiers = [];

  do {
    if (this.type === __WEBPACK_IMPORTED_MODULE_0__vendor_acorn_src_tokentype_js__["b" /* types */].name) {
      // ... def [, ...]
      specifiers.push(parseImportDefaultSpecifier(this));
    } else if (this.type === __WEBPACK_IMPORTED_MODULE_0__vendor_acorn_src_tokentype_js__["b" /* types */].star) {
      // ... * as ns [, ...]
      specifiers.push(parseImportNamespaceSpecifier(this));
    } else if (this.type === __WEBPACK_IMPORTED_MODULE_0__vendor_acorn_src_tokentype_js__["b" /* types */].braceL) {
      // ... { x, y as z } [, ...]
      specifiers.push.apply(specifiers, func.apply(this, args));
    }
  } while (this.eat(__WEBPACK_IMPORTED_MODULE_0__vendor_acorn_src_tokentype_js__["b" /* types */].comma));

  return specifiers;
}

function parseImportDefaultSpecifier(parser) {
  // ... def
  const specifier = parser.startNode();
  specifier.local = parser.parseIdent();
  return parser.finishNode(specifier, "ImportDefaultSpecifier");
}

function parseImportNamespaceSpecifier(parser) {
  // ... * as ns
  const star = parser.startNode();
  parser.next();

  if (!parser.eatContextual("as")) {
    Object(__WEBPACK_IMPORTED_MODULE_1__parse_unexpected_js__["a" /* default */])(parser);
  }

  star.local = parser.parseIdent();
  return parser.finishNode(star, "ImportNamespaceSpecifier");
}



/***/ }),
/* 124 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return enable; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__parse_raise_js__ = __webpack_require__(32);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__vendor_acorn_src_tokentype_js__ = __webpack_require__(3);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__parse_unexpected_js__ = __webpack_require__(31);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__util_wrap_js__ = __webpack_require__(14);
// A less strict version of the object rest/spread acorn plugin.
// Copyright Victor Homyakov. Released under MIT license:
// https://github.com/victor-homyakov/acorn-object-rest-spread






function enable(parser) {
  parser.parseObj = Object(__WEBPACK_IMPORTED_MODULE_3__util_wrap_js__["a" /* default */])(parser.parseObj, parseObj);
  parser.toAssignable = Object(__WEBPACK_IMPORTED_MODULE_3__util_wrap_js__["a" /* default */])(parser.toAssignable, toAssignable);
  return parser;
}

function parseObj(func, args) {
  let first = true;
  const isPattern = args[0],
        refDestructuringErrors = args[1];

  const node = this.startNode();
  const propHash = Object.create(null);

  node.properties = [];

  this.next();

  while (!this.eat(__WEBPACK_IMPORTED_MODULE_1__vendor_acorn_src_tokentype_js__["b" /* types */].braceR)) {
    if (first) {
      first = false;
    } else {
      if (!this.eat(__WEBPACK_IMPORTED_MODULE_1__vendor_acorn_src_tokentype_js__["b" /* types */].comma)) {
        Object(__WEBPACK_IMPORTED_MODULE_2__parse_unexpected_js__["a" /* default */])(this);
      }

      if (this.afterTrailingComma(__WEBPACK_IMPORTED_MODULE_1__vendor_acorn_src_tokentype_js__["b" /* types */].braceR)) {
        break;
      }
    }

    let startLoc;
    let startPos;
    let propNode = this.startNode();

    if (isPattern || refDestructuringErrors) {
      startPos = this.start;
      startLoc = this.startLoc;
    }

    // The rest/spread code is adapted from Babylon.
    // Copyright Babylon contributors. Released under MIT license:
    // https://github.com/babel/babylon/blob/master/src/parser/expression.js
    if (this.type === __WEBPACK_IMPORTED_MODULE_1__vendor_acorn_src_tokentype_js__["b" /* types */].ellipsis) {
      propNode = this.parseSpread(refDestructuringErrors);
      propNode.type = "SpreadElement";

      if (isPattern) {
        propNode.type = "RestElement";
        propNode.value = this.toAssignable(propNode.argument, true);
      }

      node.properties.push(propNode);
      continue;
    }

    propNode.method = propNode.shorthand = false;

    const isGenerator = !isPattern && this.eat(__WEBPACK_IMPORTED_MODULE_1__vendor_acorn_src_tokentype_js__["b" /* types */].star);

    this.parsePropertyName(propNode);

    let isAsync = false;

    if (!isPattern && !isGenerator && isAsyncProp(this, propNode)) {
      isAsync = true;
      this.parsePropertyName(propNode, refDestructuringErrors);
    }

    this.parsePropertyValue(propNode, isPattern, isGenerator, isAsync, startPos, startLoc, refDestructuringErrors);
    this.checkPropClash(propNode, propHash);
    node.properties.push(this.finishNode(propNode, "Property"));
  }

  return this.finishNode(node, isPattern ? "ObjectPattern" : "ObjectExpression");
}

function toAssignable(func, args) {
  const node = args[0],
        isBinding = args[1];


  if (node && node.type === "ObjectExpression") {
    node.type = "ObjectPattern";
    const properties = node.properties;

    for (let _i = 0; _i < properties.length; _i++) {
      const propNode = properties[_i];
      if (propNode.kind === "init") {
        this.toAssignable(propNode.value, isBinding);
      } else if (propNode.type === "SpreadElement") {
        propNode.value = this.toAssignable(propNode.argument, isBinding);
      } else {
        Object(__WEBPACK_IMPORTED_MODULE_0__parse_raise_js__["a" /* default */])(this, propNode.key.start, "Object pattern can't contain getter or setter");
      }
    }

    return node;
  }

  return func.apply(this, args);
}

function isAsyncProp(parser, propNode) {
  return typeof parser.isAsyncProp === "function" ? parser.isAsyncProp(propNode) : parser.toks.isAsyncProp(propNode);
}



/***/ }),
/* 125 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony export (binding) */ __webpack_require__.d(__webpack_exports__, "a", function() { return enable; });
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__util_wrap_js__ = __webpack_require__(14);


const parserDupPrefix = "Duplicate export '";
const engineDupPrefix = "Duplicate export of '";

const parserTypePostfix = "may appear only with 'sourceType: module'";
const engineTypePostfix = "may only be used in ES modules";

function enable(parser) {
  parser.checkLVal = Object(__WEBPACK_IMPORTED_MODULE_0__util_wrap_js__["a" /* default */])(parser.checkLVal, strictWrapper);
  parser.raise = Object(__WEBPACK_IMPORTED_MODULE_0__util_wrap_js__["a" /* default */])(parser.raise, raise);
  parser.raiseRecoverable = Object(__WEBPACK_IMPORTED_MODULE_0__util_wrap_js__["a" /* default */])(parser.raise, raiseRecoverable);
  parser.strict = false;
  return parser;
}

function raise(func, args) {
  const pos = args[0],
        message = args[1];

  // Correct message for `let default`:
  // https://github.com/ternjs/acorn/issues/544

  if (message === "The keyword 'let' is reserved") {
    func.call(this, pos, "Unexpected token");
    return;
  }

  if (message.endsWith(parserTypePostfix)) {
    func.call(this, pos, message.replace(parserTypePostfix, engineTypePostfix));
    return;
  }

  func.apply(this, args);
}

function raiseRecoverable(func, args) {
  const pos = args[0],
        message = args[1];


  if (message.startsWith(parserDupPrefix)) {
    func.call(this, pos, message.replace(parserDupPrefix, engineDupPrefix));
    return;
  }

  if (message.startsWith("Binding ") || message === "new.target can only be used in functions" || message === "The keyword 'await' is reserved") {
    func.call(this, pos, message);
  }
}

function strictWrapper(func, args) {
  this.strict = true;

  try {
    return func.apply(this, args);
  } finally {
    this.strict = false;
  }
}



/***/ }),
/* 126 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__visitor_js__ = __webpack_require__(42);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__parse_get_names_from_pattern_js__ = __webpack_require__(72);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__parse_raise_js__ = __webpack_require__(32);





const shadowedMap = new WeakMap();

class AssignmentVisitor extends __WEBPACK_IMPORTED_MODULE_0__visitor_js__["a" /* default */] {
  reset(rootPath, options) {
    this.exportedLocalNames = options.exportedLocalNames;
    this.importedLocalNames = options.importedLocalNames;
    this.magicString = options.magicString;
    this.runtimeAlias = options.runtimeAlias;
  }

  visitAssignmentExpression(path) {
    this.visitChildren(path);
    assignmentHelper(this, path, "left");
  }

  visitCallExpression(path) {
    this.visitChildren(path);

    var _path$getValue = path.getValue();

    const callee = _path$getValue.callee;

    if (callee.type === "Identifier" && callee.name === "eval") {
      wrap(this, path);
    }
  }

  visitUpdateExpression(path) {
    this.visitChildren(path);
    assignmentHelper(this, path, "argument");
  }
}

function assignmentHelper(visitor, path, childName) {
  const node = path.getValue();
  const child = node[childName];
  const exportedNames = visitor.exportedLocalNames;
  const importedNames = visitor.importedLocalNames;
  const names = Object(__WEBPACK_IMPORTED_MODULE_1__parse_get_names_from_pattern_js__["a" /* default */])(child);

  // Perform checks, which may throw errors, before source transformations.

  for (let _i = 0; _i < names.length; _i++) {
    const name = names[_i];
    if (importedNames[name] === true && !isShadowed(path, name)) {
      const parser = {
        input: visitor.magicString.original,
        pos: node.start,
        start: node.start
      };

      Object(__WEBPACK_IMPORTED_MODULE_2__parse_raise_js__["a" /* default */])(parser, parser.start, "Assignment to constant variable.", TypeError);
    }
  }

  // Wrap assignments to exported identifiers with `runtime.update()`.


  for (let _i2 = 0; _i2 < names.length; _i2++) {
    const name = names[_i2];
    if (exportedNames[name] === true && !isShadowed(path, name)) {
      wrap(visitor, path);
      return;
    }
  }
}

function hasNamed(nodes, name) {
  for (let _i3 = 0; _i3 < nodes.length; _i3++) {
    const node = nodes[_i3];
    const id = node.type === "VariableDeclarator" ? node.id : node;

    if (id.name === name) {
      return true;
    }
  }

  return false;
}

function hasParameter(node, name) {
  return hasNamed(node.params, name);
}

function hasVariable(node, name) {
  const body = node.body;

  for (let _i4 = 0; _i4 < body.length; _i4++) {
    const stmt = body[_i4];
    if (stmt.type === "VariableDeclaration" && hasNamed(stmt.declarations, name)) {
      return true;
    }
  }

  return false;
}

function isShadowed(path, name) {
  let shadowed = false;

  path.getParentNode(function (parent) {
    let cache = shadowedMap.get(parent);

    if (cache === void 0) {
      cache = Object.create(null);
      shadowedMap.set(parent, cache);
    } else if (name in cache) {
      return shadowed = cache[name];
    }

    const type = parent.type;


    if (type === "BlockStatement") {
      shadowed = hasVariable(parent, name);
    } else if (type === "FunctionDeclaration" || type === "FunctionExpression" || type === "ArrowFunctionExpression") {
      shadowed = hasParameter(parent, name);
    }

    return cache[name] = shadowed;
  });

  return shadowed;
}

function wrap(visitor, path) {
  const node = path.getValue();

  visitor.magicString.prependRight(node.start, visitor.runtimeAlias + ".u(").prependRight(node.end, ")");
}

/* harmony default export */ __webpack_exports__["a"] = (new AssignmentVisitor());

/***/ }),
/* 127 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__visitor_js__ = __webpack_require__(42);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__parse_raise_js__ = __webpack_require__(32);




const definedMap = new WeakMap();

class IdentifierVisitor extends __WEBPACK_IMPORTED_MODULE_0__visitor_js__["a" /* default */] {
  reset(rootPath, options) {
    this.magicString = options.magicString;
  }

  visitIdentifier(path) {
    const node = path.getValue();

    if (node.name === "arguments") {
      var _path$getParentNode = path.getParentNode();

      const operator = _path$getParentNode.operator,
            type = _path$getParentNode.type;


      if (!(type === "UnaryExpression" && operator === "typeof") && !isArgumentsDefined(path)) {
        const parser = {
          input: this.magicString.original,
          pos: node.start,
          start: node.start
        };

        Object(__WEBPACK_IMPORTED_MODULE_1__parse_raise_js__["a" /* default */])(parser, parser.start, "arguments is not defined", ReferenceError);
      }
    }

    this.visitChildren(path);
  }
}

function isArgumentsDefined(path) {
  let defined = false;

  path.getParentNode(function (parent) {
    defined = definedMap.get(parent);

    if (defined !== void 0) {
      return defined;
    }

    const type = parent.type;


    defined = type === "FunctionDeclaration" || type === "FunctionExpression";

    definedMap.set(parent, defined);
    return defined;
  });

  return defined;
}

/* harmony default export */ __webpack_exports__["a"] = (new IdentifierVisitor());

/***/ }),
/* 128 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__magic_string_js__ = __webpack_require__(129);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__ordered_map_js__ = __webpack_require__(130);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__visitor_js__ = __webpack_require__(42);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__parse_get_names_from_pattern_js__ = __webpack_require__(72);






const codeOfCR = "\r".charCodeAt(0);

const stringify = JSON.stringify;


class ImportExportVisitor extends __WEBPACK_IMPORTED_MODULE_2__visitor_js__["a" /* default */] {
  finalizeHoisting() {
    if (this.bodyInfo === null) {
      return;
    }

    const codeToInsert = this.bodyInfo.hoistedPrefixString + toModuleExport(this, this.bodyInfo.hoistedExportsMap) + this.bodyInfo.hoistedExportsString + this.bodyInfo.hoistedImportsString;

    this.magicString.prependRight(this.bodyInfo.insertCharIndex, codeToInsert);

    // Just in case we call finalizeHoisting again, don't hoist anything.
    this.bodyInfo = null;
  }

  reset(rootPath, code, options) {
    this.addedDynamicImport = false;
    this.addedImportExport = false;
    this.bodyInfo = null;
    this.code = code;
    this.exportedLocalNames = Object.create(null);
    this.generateVarDeclarations = options.generateVarDeclarations;
    this.importedLocalNames = Object.create(null);
    this.madeChanges = false;
    this.magicString = new __WEBPACK_IMPORTED_MODULE_0__magic_string_js__["a" /* default */](code);
    this.runtimeAlias = options.runtimeAlias;
    this.sourceType = options.sourceType;
  }

  visitCallExpression(path) {
    const node = path.getValue();
    const callee = node.callee;

    if (callee.type === "Import") {
      this.addedDynamicImport = true;
      overwrite(this, callee.start, callee.end, this.runtimeAlias + ".i");
    }

    this.visitChildren(path);
  }

  visitImportDeclaration(path) {
    if (this.sourceType === "script") {
      return;
    }

    this.addedImportExport = true;

    let i = -1;
    const node = path.getValue();
    const specifiers = node.specifiers;

    const specifierMap = computeSpecifierMap(specifiers);
    const lastIndex = specifiers.length - 1;

    let hoistedCode = specifiers.length ? this.generateVarDeclarations ? "var " : "let " : "";

    for (let _i = 0; _i < specifiers.length; _i++) {
      const specifier = specifiers[_i];const name = specifier.local.name;

      hoistedCode += name + (++i === lastIndex ? ";" : ",");
    }

    hoistedCode += toModuleImport(this, getSourceString(this, node), specifierMap);

    hoistImports(this, path, hoistedCode);
    addImportedLocalNames(this, specifierMap);
  }

  visitExportAllDeclaration(path) {
    if (this.sourceType === "script") {
      return;
    }

    this.addedImportExport = true;

    const node = path.getValue();
    const source = node.source;

    const hoistedCode = pad(this, this.runtimeAlias + ".w(" + getSourceString(this, node), node.start, source.start) + pad(this, ',[["*",' + this.runtimeAlias + ".n()]]);", source.end, node.end);

    hoistExports(this, path, hoistedCode);
  }

  visitExportDefaultDeclaration(path) {
    if (this.sourceType === "script") {
      return;
    }

    this.addedImportExport = true;

    const node = path.getValue();
    const declaration = node.declaration;
    const id = declaration.id,
          type = declaration.type;


    if (id && (type === "FunctionDeclaration" || type === "ClassDeclaration")) {
      // If the exported default value is a function or class declaration,
      // it's important that the declaration be visible to the rest of the
      // code in the exporting module, so we must avoid compiling it to a
      // named function or class expression.
      hoistExports(this, path, addToSpecifierMap(new __WEBPACK_IMPORTED_MODULE_1__ordered_map_js__["a" /* default */](), "default", id.name), "declaration");
    } else {
      // Otherwise, since the exported value is an expression, we use the
      // special `runtime.default(value)` form.
      path.call(this, "visitWithoutReset", "declaration");

      let prefix = this.runtimeAlias + ".d(";
      let suffix = ");";

      if (type === "SequenceExpression") {
        // If the exported expression is a comma-separated sequence expression,
        // `this.code.slice(declaration.start, declaration.end)` may not include
        // the vital parentheses, so we should wrap the expression with parentheses
        // to make absolutely sure it is treated as a single argument to
        // `runtime.default()`, rather than as multiple arguments.
        prefix += "(";
        suffix = ")" + suffix;
      }

      overwrite(this, node.start, declaration.start, prefix);
      overwrite(this, declaration.end, node.end, suffix);
    }
  }

  visitExportNamedDeclaration(path) {
    if (this.sourceType === "script") {
      return;
    }

    this.addedImportExport = true;

    const node = path.getValue();
    const declaration = node.declaration;


    if (declaration) {
      const specifierMap = new __WEBPACK_IMPORTED_MODULE_1__ordered_map_js__["a" /* default */]();
      const id = declaration.id,
            type = declaration.type;


      if (id && (type === "ClassDeclaration" || type === "FunctionDeclaration")) {
        addNameToMap(specifierMap, id.name);
      } else if (type === "VariableDeclaration") {
        const declarations = declaration.declarations;

        for (let _i2 = 0; _i2 < declarations.length; _i2++) {
          const varDecl = declarations[_i2];
          const names = Object(__WEBPACK_IMPORTED_MODULE_3__parse_get_names_from_pattern_js__["a" /* default */])(varDecl.id);

          for (let _i3 = 0; _i3 < names.length; _i3++) {
            const name = names[_i3];
            addNameToMap(specifierMap, name);
          }
        }
      }

      hoistExports(this, path, specifierMap, "declaration");

      // Skip adding declared names to this.exportedLocalNames if the
      // declaration is a const-kinded VariableDeclaration, because the
      // assignmentVisitor doesn't need to worry about changes to these
      // variables.
      if (canExportedValuesChange(node)) {
        addExportedLocalNames(this, specifierMap);
      }

      return;
    }

    const specifiers = node.specifiers;


    if (!specifiers) {
      return;
    }

    let specifierMap = computeSpecifierMap(specifiers);

    if (node.source == null) {
      hoistExports(this, path, specifierMap);
      addExportedLocalNames(this, specifierMap);
      return;
    }

    const newMap = new __WEBPACK_IMPORTED_MODULE_1__ordered_map_js__["a" /* default */]();
    const names = specifierMap.keys();

    for (let _i4 = 0; _i4 < names.length; _i4++) {
      const name = names[_i4];
      const locals = specifierMap.get(name).keys();

      addToSpecifierMap(newMap, locals[0], this.runtimeAlias + ".entry._namespace." + name);
    }

    specifierMap = newMap;

    // Even though the compiled code uses `runtime.watch()`, it should
    // still be hoisted as an export, i.e. before actual imports.
    hoistExports(this, path, toModuleImport(this, getSourceString(this, node), specifierMap));
  }
}

function addExportedLocalNames(visitor, specifierMap) {
  const exportedNames = visitor.exportedLocalNames;
  const names = specifierMap.keys();

  for (let _i5 = 0; _i5 < names.length; _i5++) {
    const name = names[_i5];
    const locals = specifierMap.get(name).keys();

    // It's tempting to record the exported name as the value here,
    // instead of true, but there can be more than one exported name
    // per local variable, and we don't actually use the exported
    // name(s) in the assignmentVisitor, so it's not worth the added
    // complexity of tracking unused information.
    exportedNames[locals[0]] = true;
  }
}

function addImportedLocalNames(visitor, specifierMap) {
  const importedNames = visitor.importedLocalNames;
  const names = specifierMap.keys();

  for (let _i6 = 0; _i6 < names.length; _i6++) {
    const name = names[_i6];
    const locals = specifierMap.get(name).keys();

    for (let _i7 = 0; _i7 < locals.length; _i7++) {
      const local = locals[_i7];
      importedNames[local] = true;
    }
  }
}

function addNameToMap(map, name) {
  addToSpecifierMap(map, name, name);
}

function addToSpecifierMap(map, __ported, local) {
  const locals = map.get(__ported) || new __WEBPACK_IMPORTED_MODULE_1__ordered_map_js__["a" /* default */]();
  locals.set(local, true);
  return map.set(__ported, locals);
}

// Returns a map from {im,ex}ported identifiers to lists of local variable
// names bound to those identifiers.
function computeSpecifierMap(specifiers) {
  const specifierMap = new __WEBPACK_IMPORTED_MODULE_1__ordered_map_js__["a" /* default */]();

  for (let _i8 = 0; _i8 < specifiers.length; _i8++) {
    const s = specifiers[_i8];
    const local = s.type === "ExportDefaultSpecifier" ? "default" : s.type === "ExportNamespaceSpecifier" ? "*" : s.local.name;

    const __ported = // The IMported or EXported name.
    s.type === "ImportSpecifier" ? s.imported.name : s.type === "ImportDefaultSpecifier" ? "default" : s.type === "ImportNamespaceSpecifier" ? "*" : s.type === "ExportSpecifier" || s.type === "ExportDefaultSpecifier" || s.type === "ExportNamespaceSpecifier" ? s.exported.name : null;

    if (typeof local === "string" && typeof __ported === "string") {
      addToSpecifierMap(specifierMap, __ported, local);
    }
  }

  return specifierMap;
}

function getBlockBodyInfo(visitor, path) {
  if (visitor.bodyInfo !== null) {
    return visitor.bodyInfo;
  }

  const parent = path.getParentNode();
  const body = parent.body;

  let hoistedPrefixString = "";
  let insertCharIndex = parent.start;
  let insertNodeIndex = 0;

  // Avoid hoisting above string literal expression statements such as
  // "use strict", which may depend on occurring at the beginning of
  // their enclosing scopes.
  let i = -1;
  const stmtCount = body.length;

  while (++i < stmtCount) {
    const stmt = body[i];
    if (stmt.type === "ExpressionStatement" && stmt.expression.type === "Literal" && typeof stmt.expression.value === "string") {
      insertCharIndex = stmt.end;
      insertNodeIndex = i + 1;
      hoistedPrefixString = ";";
    } else {
      break;
    }
  }

  const bodyInfo = visitor.bodyInfo = Object.create(null);
  bodyInfo.insertCharIndex = insertCharIndex;
  bodyInfo.insertNodeIndex = insertNodeIndex;
  bodyInfo.hoistedExportsMap = new __WEBPACK_IMPORTED_MODULE_1__ordered_map_js__["a" /* default */]();
  bodyInfo.hoistedExportsString = "";
  bodyInfo.hoistedImportsString = "";
  bodyInfo.hoistedPrefixString = hoistedPrefixString;

  return bodyInfo;
}

// Gets a string representation (including quotes) from an import or
// export declaration node.
function getSourceString(visitor, _ref) {
  let source = _ref.source;

  return visitor.code.slice(source.start, source.end);
}

function hoistImports(visitor, importDeclPath, hoistedCode) {
  preserveLine(visitor, importDeclPath);
  const bodyInfo = getBlockBodyInfo(visitor, importDeclPath);
  bodyInfo.hoistedImportsString += hoistedCode;
}

function hoistExports(visitor, exportDeclPath, mapOrString, childName) {
  if (childName) {
    preserveChild(visitor, exportDeclPath, childName);
  } else {
    preserveLine(visitor, exportDeclPath);
  }

  const bodyInfo = getBlockBodyInfo(visitor, exportDeclPath);

  if (typeof mapOrString === "string") {
    bodyInfo.hoistedExportsString += mapOrString;
    return;
  }

  const names = mapOrString.keys();

  for (let _i9 = 0; _i9 < names.length; _i9++) {
    const name = names[_i9];
    const locals = mapOrString.get(name).keys();

    addToSpecifierMap(bodyInfo.hoistedExportsMap, name, locals[0]);
  }
}

function canExportedValuesChange(exportDecl) {
  if (exportDecl.type === "ExportDefaultDeclaration") {
    const dd = exportDecl.declaration;
    return dd.type === "FunctionDeclaration" || dd.type === "ClassDeclaration";
  }

  if (exportDecl.type === "ExportNamedDeclaration") {
    const dd = exportDecl.declaration;
    if (dd && dd.type === "VariableDeclaration" && dd.kind === "const") {
      return false;
    }
  }

  return true;
}

function overwrite(visitor, oldStart, oldEnd, newCode) {
  const padded = pad(visitor, newCode, oldStart, oldEnd);

  if (oldStart !== oldEnd) {
    visitor.madeChanges = true;
    visitor.magicString.overwrite(oldStart, oldEnd, padded);
  } else if (padded !== "") {
    visitor.madeChanges = true;
    visitor.magicString.prependRight(oldStart, padded);
  }
}

function pad(visitor, newCode, oldStart, oldEnd) {
  const oldLines = visitor.code.slice(oldStart, oldEnd).split("\n");
  const oldLineCount = oldLines.length;
  const newLines = newCode.split("\n");
  const lastIndex = newLines.length - 1;
  let i = lastIndex - 1;

  while (++i < oldLineCount) {
    const oldLine = oldLines[i];
    const lastCharCode = oldLine.charCodeAt(oldLine.length - 1);

    if (i > lastIndex) {
      newLines[i] = "";
    }
    if (lastCharCode === codeOfCR) {
      newLines[i] += "\r";
    }
  }

  return newLines.join("\n");
}

function preserveChild(visitor, path, childName) {
  const node = path.getValue();
  const child = node[childName];

  overwrite(visitor, node.start, child.start, "");
  overwrite(visitor, child.end, node.end, "");

  path.call(visitor, "visitWithoutReset", childName);
}

function preserveLine(visitor, path) {
  const node = path.getValue();
  overwrite(visitor, node.start, node.end, "");
}

function safeParam(param, locals) {
  return locals.indexOf(param) === -1 ? param : safeParam("_" + param, locals);
}

function toModuleImport(visitor, code, specifierMap) {
  const names = specifierMap.keys();

  code = visitor.runtimeAlias + ".w(" + code;

  if (!names.length) {
    return code + ");";
  }

  let i = -1;
  const lastIndex = names.length - 1;

  code += ",[";

  for (let _i10 = 0; _i10 < names.length; _i10++) {
    const name = names[_i10];
    const locals = specifierMap.get(name).keys();
    const valueParam = safeParam("v", locals);

    /* eslint-disable lines-around-comment */
    code +=
    // Generate plain functions, instead of arrow functions,
    // to avoid a perf hit in Node 4.
    "[" + stringify(name) + ",function(" + valueParam + "){" +
    // Multiple local variables become a compound assignment.
    locals.join("=") + "=" + valueParam + "}]";
    /* eslint-enable lines-around-comment */

    if (++i !== lastIndex) {
      code += ",";
    }
  }

  code += "]);";

  return code;
}

function toModuleExport(visitor, specifierMap) {
  const names = specifierMap.keys();

  let code = "";

  if (!names.length) {
    return code;
  }

  let i = -1;
  const lastIndex = names.length - 1;

  code += visitor.runtimeAlias + ".e([";

  for (let _i11 = 0; _i11 < names.length; _i11++) {
    const name = names[_i11];
    const locals = specifierMap.get(name).keys();

    code += "[" + stringify(name) + ",()=>" + locals[0] + "]";

    if (++i !== lastIndex) {
      code += ",";
    }
  }

  code += "]);";

  return code;
}

/* harmony default export */ __webpack_exports__["a"] = (new ImportExportVisitor());

/***/ }),
/* 129 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
// A simplified version of magic-string.
// Copyright Rich Harris. Released under MIT license:
// https://github.com/Rich-Harris/magic-string

class Chunk {
  constructor(start, end, content) {
    this.start = start;
    this.end = end;
    this.original = content;
    this.intro = "";
    this.content = content;
    this.next = null;
  }

  contains(index) {
    return this.start < index && index < this.end;
  }

  prependRight(content) {
    this.intro = content + this.intro;
  }

  split(index) {
    const sliceIndex = index - this.start;
    const originalBefore = this.original.slice(0, sliceIndex);
    const originalAfter = this.original.slice(sliceIndex);

    const newChunk = new Chunk(index, this.end, originalAfter);

    this.original = originalBefore;
    this.end = index;
    this.content = originalBefore;

    newChunk.next = this.next;
    this.next = newChunk;

    return newChunk;
  }

  toString() {
    return this.intro + this.content;
  }
}

Object.setPrototypeOf(Chunk.prototype, null);

class MagicString {
  constructor(string) {
    const chunk = new Chunk(0, string.length, string);

    this.original = string;
    this.intro = "";
    this.firstChunk = chunk;
    this.lastSearchedChunk = chunk;
    this.byStart = Object.create(null);
    this.byEnd = Object.create(null);

    this.byStart[0] = chunk;
    this.byEnd[string.length] = chunk;
  }

  overwrite(start, end, content) {
    this._split(start);
    this._split(end);

    const first = this.byStart[start];
    const last = this.byEnd[end];

    first.content = content;
    first.end = end;
    first.intro = "";
    first.next = last.next;
    first.original = this.original.slice(start, end);

    return this;
  }

  prependRight(index, content) {
    this._split(index);
    const chunk = this.byStart[index];
    chunk.prependRight(content);
    return this;
  }

  _split(index) {
    if (this.byStart[index] || this.byEnd[index]) {
      return;
    }
    let chunk = this.lastSearchedChunk;
    const searchForward = index > chunk.end;

    while (true) {
      if (chunk.contains(index)) {
        this._splitChunk(chunk, index);
        return;
      }
      chunk = searchForward ? this.byStart[chunk.end] : this.byEnd[chunk.start];
    }
  }

  _splitChunk(chunk, index) {
    const newChunk = chunk.split(index);
    this.byEnd[index] = chunk;
    this.byStart[index] = newChunk;
    this.byEnd[newChunk.end] = newChunk;
    this.lastSearchedChunk = chunk;
  }

  toString() {
    let str = this.intro;
    let chunk = this.firstChunk;
    while (chunk) {
      str += chunk.toString();
      chunk = chunk.next;
    }
    return str;
  }
}

Object.setPrototypeOf(MagicString.prototype, null);

/* harmony default export */ __webpack_exports__["a"] = (MagicString);

/***/ }),
/* 130 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
class OrderedMap {
  constructor() {
    this.clear();
  }

  clear() {
    this._hash = Object.create(null);

    if (this._keys === void 0) {
      this._keys = [];
      this._values = [];
    } else {
      this._keys.length = this._values.length = 0;
    }

    return this;
  }

  get(key) {
    return this._values[this._hash[key]];
  }

  has(key) {
    return key in this._hash;
  }

  keys() {
    return this._keys;
  }

  set(key, value) {
    const hash = this._hash;
    const values = this._values;

    if (key in hash) {
      values[hash[key]] = value;
    } else {
      const keys = this._keys;
      const nextIndex = keys.length;

      hash[key] = nextIndex;
      keys[nextIndex] = key;
      values[nextIndex] = value;
    }

    return this;
  }

  values() {
    return this._values;
  }
}

Object.setPrototypeOf(OrderedMap.prototype, null);

/* harmony default export */ __webpack_exports__["a"] = (OrderedMap);

/***/ }),
/* 131 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_minizlib__ = __webpack_require__(74);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_minizlib___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_minizlib__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__util_create_options_js__ = __webpack_require__(2);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_zlib__ = __webpack_require__(76);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_zlib___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_zlib__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__stream_to_buffer_js__ = __webpack_require__(77);






const defaultOptions = Object(__WEBPACK_IMPORTED_MODULE_1__util_create_options_js__["a" /* default */])({
  level: 9
});

let useGzipFastPath = true;

function gzip(bufferOrString, options) {
  options = Object(__WEBPACK_IMPORTED_MODULE_1__util_create_options_js__["a" /* default */])(options, defaultOptions);

  if (useGzipFastPath) {
    try {
      return fastPathGzip(bufferOrString, options);
    } catch (e) {
      useGzipFastPath = false;
    }
  }
  return fallbackGzip(bufferOrString, options);
}

function fallbackGzip(bufferOrString, options) {
  return Object(__WEBPACK_IMPORTED_MODULE_2_zlib__["gzipSync"])(bufferOrString, options);
}

function fastPathGzip(bufferOrString, options) {
  return Object(__WEBPACK_IMPORTED_MODULE_3__stream_to_buffer_js__["a" /* default */])(new __WEBPACK_IMPORTED_MODULE_0_minizlib__["Gzip"](options), bufferOrString);
}

gzip.defaultOptions = defaultOptions;

/* harmony default export */ __webpack_exports__["a"] = (gzip);

/***/ }),
/* 132 */
/***/ (function(module, exports) {

module.exports = require("assert");

/***/ }),
/* 133 */
/***/ (function(module, exports) {

module.exports = require("buffer");

/***/ }),
/* 134 */
/***/ (function(module, exports) {

module.exports = Object.freeze({
  Z_NO_FLUSH: 0,
  Z_PARTIAL_FLUSH: 1,
  Z_SYNC_FLUSH: 2,
  Z_FULL_FLUSH: 3,
  Z_FINISH: 4,
  Z_BLOCK: 5,
  Z_OK: 0,
  Z_STREAM_END: 1,
  Z_NEED_DICT: 2,
  Z_ERRNO: -1,
  Z_STREAM_ERROR: -2,
  Z_DATA_ERROR: -3,
  Z_MEM_ERROR: -4,
  Z_BUF_ERROR: -5,
  Z_VERSION_ERROR: -6,
  Z_NO_COMPRESSION: 0,
  Z_BEST_SPEED: 1,
  Z_BEST_COMPRESSION: 9,
  Z_DEFAULT_COMPRESSION: -1,
  Z_FILTERED: 1,
  Z_HUFFMAN_ONLY: 2,
  Z_RLE: 3,
  Z_FIXED: 4,
  Z_DEFAULT_STRATEGY: 0,
  ZLIB_VERNUM: 4736,
  DEFLATE: 1,
  INFLATE: 2,
  GZIP: 3,
  GUNZIP: 4,
  DEFLATERAW: 5,
  INFLATERAW: 6,
  UNZIP: 7,
  Z_MIN_WINDOWBITS: 8,
  Z_MAX_WINDOWBITS: 15,
  Z_DEFAULT_WINDOWBITS: 15,
  Z_MIN_CHUNK: 64,
  Z_MAX_CHUNK: Infinity,
  Z_DEFAULT_CHUNK: 16384,
  Z_MIN_MEMLEVEL: 1,
  Z_MAX_MEMLEVEL: 9,
  Z_DEFAULT_MEMLEVEL: 8,
  Z_MIN_LEVEL: -1,
  Z_MAX_LEVEL: 9,
  Z_DEFAULT_LEVEL: -1
})


/***/ }),
/* 135 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

const EE = __webpack_require__(136)
const Yallist = __webpack_require__(75)
const EOF = Symbol('EOF')
const MAYBE_EMIT_END = Symbol('maybeEmitEnd')
const EMITTED_END = Symbol('emittedEnd')
const CLOSED = Symbol('closed')
const READ = Symbol('read')
const FLUSH = Symbol('flush')
const FLUSHCHUNK = Symbol('flushChunk')
const SD = __webpack_require__(138).StringDecoder
const ENCODING = Symbol('encoding')
const DECODER = Symbol('decoder')
const FLOWING = Symbol('flowing')
const RESUME = Symbol('resume')
const BUFFERLENGTH = Symbol('bufferLength')
const BUFFERPUSH = Symbol('bufferPush')
const BUFFERSHIFT = Symbol('bufferShift')
const OBJECTMODE = Symbol('objectMode')

class MiniPass extends EE {
  constructor (options) {
    super()
    this[FLOWING] = false
    this.pipes = new Yallist()
    this.buffer = new Yallist()
    this[OBJECTMODE] = options && options.objectMode || false
    if (this[OBJECTMODE])
      this[ENCODING] = null
    else
      this[ENCODING] = options && options.encoding || null
    if (this[ENCODING] === 'buffer')
      this[ENCODING] = null
    this[DECODER] = this[ENCODING] ? new SD(this[ENCODING]) : null
    this[EOF] = false
    this[EMITTED_END] = false
    this[CLOSED] = false
    this.writable = true
    this.readable = true
    this[BUFFERLENGTH] = 0
  }

  get bufferLength () { return this[BUFFERLENGTH] }

  get encoding () { return this[ENCODING] }
  set encoding (enc) {
    if (this[OBJECTMODE])
      throw new Error('cannot set encoding in objectMode')

    if (this[ENCODING] && enc !== this[ENCODING] &&
        (this[DECODER] && this[DECODER].lastNeed || this[BUFFERLENGTH]))
      throw new Error('cannot change encoding')

    if (this[ENCODING] !== enc) {
      this[DECODER] = enc ? new SD(enc) : null
      if (this.buffer.length)
        this.buffer = this.buffer.map(chunk => this[DECODER].write(chunk))
    }

    this[ENCODING] = enc
  }

  setEncoding (enc) {
    this.encoding = enc
  }

  write (chunk, encoding, cb) {
    if (this[EOF])
      throw new Error('write after end')

    if (typeof encoding === 'function')
      cb = encoding, encoding = 'utf8'

    if (!encoding)
      encoding = 'utf8'

    // fast-path writing strings of same encoding to a stream with
    // an empty buffer, skipping the buffer/decoder dance
    if (typeof chunk === 'string' && !this[OBJECTMODE] &&
        // unless it is a string already ready for us to use
        !(encoding === this[ENCODING] && !this[DECODER].lastNeed)) {
      chunk = new Buffer(chunk, encoding)
    }

    if (Buffer.isBuffer(chunk) && this[ENCODING])
      chunk = this[DECODER].write(chunk)

    try {
      return this.flowing
        ? (this.emit('data', chunk), this.flowing)
        : (this[BUFFERPUSH](chunk), false)
    } finally {
      this.emit('readable')
      if (cb)
        cb()
    }
  }

  read (n) {
    try {
      if (this[BUFFERLENGTH] === 0 || n === 0 || n > this[BUFFERLENGTH])
        return null

      if (this[OBJECTMODE])
        n = null

      if (this.buffer.length > 1 && !this[OBJECTMODE]) {
        if (this.encoding)
          this.buffer = new Yallist([
            Array.from(this.buffer).join('')
          ])
        else
          this.buffer = new Yallist([
            Buffer.concat(Array.from(this.buffer), this[BUFFERLENGTH])
          ])
      }

      return this[READ](n || null, this.buffer.head.value)
    } finally {
      this[MAYBE_EMIT_END]()
    }
  }

  [READ] (n, chunk) {
    if (n === chunk.length || n === null)
      this[BUFFERSHIFT]()
    else {
      this.buffer.head.value = chunk.slice(n)
      chunk = chunk.slice(0, n)
      this[BUFFERLENGTH] -= n
    }

    this.emit('data', chunk)

    if (!this.buffer.length && !this[EOF])
      this.emit('drain')

    return chunk
  }

  end (chunk, encoding, cb) {
    if (typeof chunk === 'function')
      cb = chunk, chunk = null
    if (typeof encoding === 'function')
      cb = encoding, encoding = 'utf8'
    if (chunk)
      this.write(chunk, encoding)
    if (cb)
      this.once('end', cb)
    this[EOF] = true
    this.writable = false
    if (this.flowing)
      this[MAYBE_EMIT_END]()
  }

  // don't let the internal resume be overwritten
  [RESUME] () {
    this[FLOWING] = true
    this.emit('resume')
    if (this.buffer.length)
      this[FLUSH]()
    else if (this[EOF])
      this[MAYBE_EMIT_END]()
    else
      this.emit('drain')
  }

  resume () {
    return this[RESUME]()
  }

  pause () {
    this[FLOWING] = false
  }

  get flowing () {
    return this[FLOWING]
  }

  [BUFFERPUSH] (chunk) {
    if (this[OBJECTMODE])
      this[BUFFERLENGTH] += 1
    else
      this[BUFFERLENGTH] += chunk.length
    return this.buffer.push(chunk)
  }

  [BUFFERSHIFT] () {
    if (this.buffer.length) {
      if (this[OBJECTMODE])
        this[BUFFERLENGTH] -= 1
      else
        this[BUFFERLENGTH] -= this.buffer.head.value.length
    }
    return this.buffer.shift()
  }

  [FLUSH] () {
    do {} while (this[FLUSHCHUNK](this[BUFFERSHIFT]()))

    if (!this.buffer.length && !this[EOF])
      this.emit('drain')
  }

  [FLUSHCHUNK] (chunk) {
    return chunk ? (this.emit('data', chunk), this.flowing) : false
  }

  pipe (dest, opts) {
    if (dest === process.stdout || dest === process.stderr)
      (opts = opts || {}).end = false
    const p = { dest: dest, opts: opts, ondrain: _ => this[RESUME]() }
    this.pipes.push(p)

    dest.on('drain', p.ondrain)
    this[RESUME]()
    return dest
  }

  addEventHandler (ev, fn) {
    return this.on(ev, fn)
  }

  on (ev, fn) {
    try {
      return super.on(ev, fn)
    } finally {
      if (ev === 'data' && !this.pipes.length && !this.flowing) {
        this[RESUME]()
      }
    }
  }

  get emittedEnd () {
    return this[EMITTED_END]
  }

  [MAYBE_EMIT_END] () {
    if (!this[EMITTED_END] && this.buffer.length === 0 && this[EOF]) {
      this.emit('end')
      this.emit('prefinish')
      this.emit('finish')
      if (this[CLOSED])
        this.emit('close')
    }
  }

  emit (ev, data) {
    if (ev === 'data') {
      if (!data)
        return

      if (this.pipes.length)
        this.pipes.forEach(p => p.dest.write(data) || this.pause())
    } else if (ev === 'end') {
      if (this[DECODER]) {
        data = this[DECODER].end()
        if (data) {
          this.pipes.forEach(p => p.dest.write(data))
          super.emit('data', data)
        }
      }
      this.pipes.forEach(p => {
        p.dest.removeListener('drain', p.ondrain)
        if (!p.opts || p.opts.end !== false)
          p.dest.end()
      })
      this[EMITTED_END] = true
      this.readable = false
    } else if (ev === 'close') {
      this[CLOSED] = true
      // don't emit close before 'end' and 'finish'
      if (!this[EMITTED_END])
        return
    }

    const args = new Array(arguments.length)
    args[0] = ev
    args[1] = data
    if (arguments.length > 2) {
      for (let i = 2; i < arguments.length; i++) {
        args[i] = arguments[i]
      }
    }

    try {
      return super.emit.apply(this, args)
    } finally {
      if (ev !== 'end')
        this[MAYBE_EMIT_END]()
    }
  }
}

module.exports = MiniPass


/***/ }),
/* 136 */
/***/ (function(module, exports) {

module.exports = require("events");

/***/ }),
/* 137 */
/***/ (function(module, exports, __webpack_require__) {

"use strict";

var Yallist = __webpack_require__(75)

Yallist.prototype[Symbol.iterator] = function* () {
  for (let walker = this.head; walker; walker = walker.next) {
    yield walker.value
  }
}


/***/ }),
/* 138 */
/***/ (function(module, exports) {

module.exports = require("string_decoder");

/***/ }),
/* 139 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_fs__ = __webpack_require__(5);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_fs___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_fs__);


function removeFile(filePath) {
  try {
    Object(__WEBPACK_IMPORTED_MODULE_0_fs__["unlinkSync"])(filePath);
    return true;
  } catch (e) {}
  return false;
}

/* harmony default export */ __webpack_exports__["a"] = (removeFile);

/***/ }),
/* 140 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__fast_object_js__ = __webpack_require__(1);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__util_create_options_js__ = __webpack_require__(2);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_path__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_path___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_path__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__util_keys_js__ = __webpack_require__(17);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__mkdirp_js__ = __webpack_require__(141);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__write_file_js__ = __webpack_require__(144);








let pendingWriteTimer = null;
const pendingWrites = new __WEBPACK_IMPORTED_MODULE_0__fast_object_js__["a" /* default */]();

function writeFileDefer(filePath, content, options, callback) {
  options = Object(__WEBPACK_IMPORTED_MODULE_1__util_create_options_js__["a" /* default */])(options);
  pendingWrites[filePath] = { callback, content, options };

  if (pendingWriteTimer !== null) {
    return;
  }

  pendingWriteTimer = setImmediate(function () {
    pendingWriteTimer = null;
    Object(__WEBPACK_IMPORTED_MODULE_3__util_keys_js__["a" /* default */])(pendingWrites).forEach(function (filePath) {
      const pending = pendingWrites[filePath];
      const callback = pending.callback;
      const options = pending.options;
      let success = false;

      if (Object(__WEBPACK_IMPORTED_MODULE_4__mkdirp_js__["a" /* default */])(Object(__WEBPACK_IMPORTED_MODULE_2_path__["dirname"])(filePath), options.scopePath)) {
        const content = typeof pending.content === "function" ? pending.content() : pending.content;

        success = Object(__WEBPACK_IMPORTED_MODULE_5__write_file_js__["a" /* default */])(filePath, content, options);
      }

      if (success) {
        delete pendingWrites[filePath];
      }

      if (typeof callback === "function") {
        callback(success);
      }
    });
  });
}

/* harmony default export */ __webpack_exports__["a"] = (writeFileDefer);

/***/ }),
/* 141 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_path__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_path___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_path__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__util_is_directory_js__ = __webpack_require__(142);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__mkdir_js__ = __webpack_require__(143);




function mkdirp(dirPath, scopePath) {
  const parentPath = Object(__WEBPACK_IMPORTED_MODULE_0_path__["dirname"])(dirPath);

  if (dirPath === parentPath || dirPath === scopePath) {
    return true;
  }

  if (mkdirp(parentPath, scopePath)) {
    return Object(__WEBPACK_IMPORTED_MODULE_1__util_is_directory_js__["a" /* default */])(dirPath) || Object(__WEBPACK_IMPORTED_MODULE_2__mkdir_js__["a" /* default */])(dirPath);
  }

  return false;
}

/* harmony default export */ __webpack_exports__["a"] = (mkdirp);

/***/ }),
/* 142 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__fs_stat_js__ = __webpack_require__(24);


function isDirectory(thePath) {
  return Object(__WEBPACK_IMPORTED_MODULE_0__fs_stat_js__["a" /* default */])(thePath) === 1;
}

/* harmony default export */ __webpack_exports__["a"] = (isDirectory);

/***/ }),
/* 143 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_fs__ = __webpack_require__(5);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_fs___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_fs__);


function mkdir(dirPath) {
  try {
    Object(__WEBPACK_IMPORTED_MODULE_0_fs__["mkdirSync"])(dirPath);
    return true;
  } catch (e) {}
  return false;
}

/* harmony default export */ __webpack_exports__["a"] = (mkdir);

/***/ }),
/* 144 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_fs__ = __webpack_require__(5);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_fs___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_fs__);


function writeFile(filePath, bufferOrString, options) {
  try {
    Object(__WEBPACK_IMPORTED_MODULE_0_fs__["writeFileSync"])(filePath, bufferOrString, options);
    return true;
  } catch (e) {}
  return false;
}

/* harmony default export */ __webpack_exports__["a"] = (writeFile);

/***/ }),
/* 145 */
/***/ (function(module, exports) {

module.exports = require("crypto");

/***/ }),
/* 146 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_path__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_path___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_path__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__path_extname_js__ = __webpack_require__(28);



function getCacheStateHash(filePath) {
  return Object(__WEBPACK_IMPORTED_MODULE_0_path__["basename"])(filePath, Object(__WEBPACK_IMPORTED_MODULE_1__path_extname_js__["a" /* default */])(filePath)).slice(-8);
}

/* harmony default export */ __webpack_exports__["a"] = (getCacheStateHash);

/***/ }),
/* 147 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_minizlib__ = __webpack_require__(74);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0_minizlib___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_0_minizlib__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__util_create_options_js__ = __webpack_require__(2);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_zlib__ = __webpack_require__(76);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_zlib___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_zlib__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__stream_to_buffer_js__ = __webpack_require__(77);






let useGunzipFastPath = true;

function gunzip(bufferOrString, options) {
  options = typeof options === "string" ? { encoding: options } : options;
  options = Object(__WEBPACK_IMPORTED_MODULE_1__util_create_options_js__["a" /* default */])(options);

  if (useGunzipFastPath) {
    try {
      return fastPathGunzip(bufferOrString, options);
    } catch (e) {
      useGunzipFastPath = false;
    }
  }
  return fallbackGunzip(bufferOrString, options);
}

function fallbackGunzip(bufferOrString, options) {
  const buffer = Object(__WEBPACK_IMPORTED_MODULE_2_zlib__["gunzipSync"])(bufferOrString, options);
  return options.encoding === "utf8" ? buffer.toString() : buffer;
}

function fastPathGunzip(bufferOrString, options) {
  const stream = new __WEBPACK_IMPORTED_MODULE_0_minizlib__["Gunzip"](options);

  if (options.encoding === "utf8") {
    let result = "";
    stream.on("data", function (chunk) {
      return result += chunk;
    }).end(bufferOrString);
    return result;
  }

  return Object(__WEBPACK_IMPORTED_MODULE_3__stream_to_buffer_js__["a" /* default */])(stream, bufferOrString);
}

/* harmony default export */ __webpack_exports__["a"] = (gunzip);

/***/ }),
/* 148 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__binding__ = __webpack_require__(8);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_semver__ = __webpack_require__(11);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_semver___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_semver__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_fs__ = __webpack_require__(5);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2_fs___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_2_fs__);




const fsBinding = __WEBPACK_IMPORTED_MODULE_0__binding__["a" /* default */].fs;
const getStatValues = fsBinding.getStatValues,
      stat = fsBinding.stat;

const useGetStatValues = typeof getStatValues === "function";

let statValues;
let useMtimeFastPath = typeof stat === "function" && Object(__WEBPACK_IMPORTED_MODULE_1_semver__["satisfies"])(process.version, "^6.10.1||>=7.7");

if (useMtimeFastPath) {
  statValues = useGetStatValues ? getStatValues.call(fsBinding) : new Float64Array(14);
}

function mtime(filePath) {
  if (useMtimeFastPath) {
    try {
      return fastPathMtime(filePath);
    } catch (_ref) {
      let code = _ref.code;

      if (code === "ENOENT") {
        return -1;
      }

      useMtimeFastPath = false;
    }
  }

  return fallbackMtime(filePath);
}

function fallbackMtime(filePath) {
  try {
    return Object(__WEBPACK_IMPORTED_MODULE_2_fs__["statSync"])(filePath).mtime.getTime();
  } catch (e) {}
  return -1;
}

function fastPathMtime(filePath) {
  // Used to speed up file stats. Modifies the `statValues` typed array,
  // with index 11 being the mtime milliseconds stamp. The speedup comes
  // from not creating Stat objects.
  if (useGetStatValues) {
    stat.call(fsBinding, filePath);
  } else {
    stat.call(fsBinding, filePath, statValues);
  }

  return statValues[11];
}

/* harmony default export */ __webpack_exports__["a"] = (mtime);

/***/ }),
/* 149 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__has_js__ = __webpack_require__(7);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__is_object_like_js__ = __webpack_require__(4);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__set_property_js__ = __webpack_require__(10);




const typeSym = Symbol.for("@std/esm:sourceType");

function setSourceType(exported, type) {
  if (!Object(__WEBPACK_IMPORTED_MODULE_1__is_object_like_js__["a" /* default */])(exported) || Object(__WEBPACK_IMPORTED_MODULE_0__has_js__["a" /* default */])(exported, "__esModule") && exported.__esModule === true) {
    return exported;
  }

  return Object(__WEBPACK_IMPORTED_MODULE_2__set_property_js__["a" /* default */])(exported, typeSym, {
    configurable: false,
    enumerable: false,
    value: type,
    writable: false
  });
}

/* harmony default export */ __webpack_exports__["a"] = (setSourceType);

/***/ }),
/* 150 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__pkg_info_js__ = __webpack_require__(15);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_repl__ = __webpack_require__(151);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1_repl___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_1_repl__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__runtime_js__ = __webpack_require__(64);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3__wrapper_js__ = __webpack_require__(39);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__util_attempt_js__ = __webpack_require__(67);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__caching_compiler_js__ = __webpack_require__(69);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__util_create_options_js__ = __webpack_require__(2);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__util_encode_id_js__ = __webpack_require__(78);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__env_js__ = __webpack_require__(43);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_9__util_get_cache_file_name_js__ = __webpack_require__(79);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_10__util_is_object_js__ = __webpack_require__(19);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_11__util_md5_js__ = __webpack_require__(80);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_12__root_module_js__ = __webpack_require__(59);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_13__util_wrap_js__ = __webpack_require__(14);
















function hook(vm) {
  const md5Hash = Object(__WEBPACK_IMPORTED_MODULE_11__util_md5_js__["a" /* default */])(Date.now()).slice(0, 3);
  const pkgInfo = __WEBPACK_IMPORTED_MODULE_0__pkg_info_js__["a" /* default */].get("");
  const runtimeAlias = Object(__WEBPACK_IMPORTED_MODULE_7__util_encode_id_js__["a" /* default */])("_" + md5Hash);

  function managerWrapper(manager, func, args) {
    const wrapped = __WEBPACK_IMPORTED_MODULE_3__wrapper_js__["a" /* default */].find(vm, "createScript", pkgInfo.range);
    return wrapped.call(this, manager, func, args);
  }

  function methodWrapper(manager, func, args) {
    function tryWrapper(func, args) {
      var _this = this;

      return Object(__WEBPACK_IMPORTED_MODULE_4__util_attempt_js__["a" /* default */])(function () {
        return func.apply(_this, args);
      }, manager, args[0]);
    }

    const code = args[0];

    const scriptOptions = Object(__WEBPACK_IMPORTED_MODULE_6__util_create_options_js__["a" /* default */])(args[1]);

    if (scriptOptions.produceCachedData === void 0) {
      scriptOptions.produceCachedData = true;
    }

    const cache = pkgInfo.cache;
    const cacheFileName = Object(__WEBPACK_IMPORTED_MODULE_9__util_get_cache_file_name_js__["a" /* default */])(null, code, pkgInfo);
    const cacheValue = cache[cacheFileName];

    let output;

    if (Object(__WEBPACK_IMPORTED_MODULE_10__util_is_object_js__["a" /* default */])(cacheValue)) {
      output = cacheValue.code;
      if (scriptOptions.produceCachedData === true && scriptOptions.cachedData === void 0 && cacheValue.data !== void 0) {
        scriptOptions.cachedData = cacheValue.data;
      }
    } else {
      const compilerOptions = {
        cacheFileName,
        pkgInfo,
        runtimeAlias,
        var: true
      };

      output = tryWrapper(__WEBPACK_IMPORTED_MODULE_5__caching_compiler_js__["a" /* default */].compile, [code, compilerOptions]).code;
    }

    output = '"use strict";var ' + runtimeAlias + "=" + runtimeAlias + "||[module.exports,module.exports=module.exports.entry.exports][0];" + output;

    const result = tryWrapper(func, [output, scriptOptions]);

    if (result.cachedDataProduced) {
      cache[cacheFileName].data = result.cachedData;
    }

    result.runInContext = Object(__WEBPACK_IMPORTED_MODULE_13__util_wrap_js__["a" /* default */])(result.runInContext, tryWrapper);
    result.runInThisContext = Object(__WEBPACK_IMPORTED_MODULE_13__util_wrap_js__["a" /* default */])(result.runInThisContext, tryWrapper);
    return result;
  }

  __WEBPACK_IMPORTED_MODULE_3__wrapper_js__["a" /* default */].manage(vm, "createScript", managerWrapper);
  __WEBPACK_IMPORTED_MODULE_3__wrapper_js__["a" /* default */].wrap(vm, "createScript", methodWrapper);

  const exported = Object.create(null);

  if (__WEBPACK_IMPORTED_MODULE_12__root_module_js__["a" /* default */].id === "<repl>") {
    __WEBPACK_IMPORTED_MODULE_2__runtime_js__["a" /* default */].enable(__WEBPACK_IMPORTED_MODULE_12__root_module_js__["a" /* default */], exported, pkgInfo.options);
    return;
  }

  const createContext = __WEBPACK_IMPORTED_MODULE_1_repl__["REPLServer"].prototype.createContext;


  if (__WEBPACK_IMPORTED_MODULE_8__env_js__["a" /* default */].preload && process.argv.length < 2 && typeof createContext === "function") {
    __WEBPACK_IMPORTED_MODULE_1_repl__["REPLServer"].prototype.createContext = function () {
      __WEBPACK_IMPORTED_MODULE_1_repl__["REPLServer"].prototype.createContext = createContext;
      const context = createContext.call(this);
      __WEBPACK_IMPORTED_MODULE_2__runtime_js__["a" /* default */].enable(context.module, exported, pkgInfo.options);
      return context;
    };
  }
}

/* harmony default export */ __webpack_exports__["a"] = (hook);

/***/ }),
/* 151 */
/***/ (function(module, exports) {

module.exports = require("repl");

/***/ }),
/* 152 */
/***/ (function(module, __webpack_exports__, __webpack_require__) {

"use strict";
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_0__module_js__ = __webpack_require__(22);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_1__pkg_info_js__ = __webpack_require__(15);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_2__builtin_modules_js__ = __webpack_require__(18);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_path__ = __webpack_require__(0);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_3_path___default = __webpack_require__.n(__WEBPACK_IMPORTED_MODULE_3_path__);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_4__util_is_object_like_js__ = __webpack_require__(4);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_5__util_keys_js__ = __webpack_require__(17);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_6__module_make_require_function_js__ = __webpack_require__(35);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_7__module_esm_load_js__ = __webpack_require__(37);
/* harmony import */ var __WEBPACK_IMPORTED_MODULE_8__module_esm_resolve_filename_js__ = __webpack_require__(38);











function hook(mod, options) {
  options = Object(__WEBPACK_IMPORTED_MODULE_4__util_is_object_like_js__["a" /* default */])(options) ? options : null;

  return Object(__WEBPACK_IMPORTED_MODULE_6__module_make_require_function_js__["a" /* default */])(mod, function (id) {
    if (id in __WEBPACK_IMPORTED_MODULE_2__builtin_modules_js__["a" /* default */]) {
      return __WEBPACK_IMPORTED_MODULE_2__builtin_modules_js__["a" /* default */][id].exports;
    }

    const filePath = Object(__WEBPACK_IMPORTED_MODULE_8__module_esm_resolve_filename_js__["a" /* default */])(id, mod, false, options);
    const pkgInfo = options === null ? __WEBPACK_IMPORTED_MODULE_1__pkg_info_js__["a" /* default */].get(Object(__WEBPACK_IMPORTED_MODULE_3_path__["dirname"])(filePath)) : null;
    const loadOptions = pkgInfo === null ? options : pkgInfo.options;

    const copy = new __WEBPACK_IMPORTED_MODULE_0__module_js__["a" /* default */](mod.id, mod.parent);
    const names = Object(__WEBPACK_IMPORTED_MODULE_5__util_keys_js__["a" /* default */])(mod);

    for (let _i = 0; _i < names.length; _i++) {
      const name = names[_i];
      if (name !== "constructor") {
        copy[name] = mod[name];
      }
    }

    return Object(__WEBPACK_IMPORTED_MODULE_7__module_esm_load_js__["a" /* default */])(filePath, copy, loadOptions).exports;
  });
}

/* harmony default export */ __webpack_exports__["a"] = (hook);

/***/ })
/******/ ])["default"];